/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, MsgBoxSimple, MenuBar } = w96.ui;
const { WindowSystem } = w96;
const { execCmd } = w96.sys;

class NoTronApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        const appWnd = this.createWindow({
            taskbar: true,
            icon: await Theme.getIconUrl("apps/notron", '16x16'),
            bodyClass: "notron-app",
            title: "noTRON Anti-Virus: Professional Deluxe Edition",
            initialHeight: 410,
            initialWidth: 505,
            body: `<div class="appbar"></div>
            <div class="container">
                <div class="progress-box">
                    <span>Operation in progress, please wait...</span>
                </div>
                <span class="htext">How may we help you today?</span> 
                <div class="nav-options">
                    <div class="option item-scan">
                        <div class="icon" style="background-image: url(${await Theme.getIconUrl("actions/search")});"></div>
                        <div class="text">
                            <span class="title">Perform Scan</span>
                            <span class="desc">Check your system for malware, viruses, etc.</span>
                        </div>
                    </div>
                    <div class="option close-active">
                        <div class="icon" style="background-image: url(${await Theme.getIconUrl("devices/memory")});"></div>
                        <div class="text">
                            <span class="title">Close all active apps</span>
                            <span class="desc">Free up computer memory by closing everything</span>
                        </div>
                    </div>
                    <div class="option clear-boot">
                        <div class="icon" style="background-image: url(${await Theme.getIconUrl("places/trash-full")});"></div>
                        <div class="text">
                            <span class="title">Clear boot items</span>
                            <span class="desc">Permanently remove all boot scripts/stylesheets.</span>
                        </div>
                    </div>
                    <div class="option del-win96">
                        <div class="icon" style="background-image: url(${await Theme.getIconUrl("objects/skull")});"></div>
                        <div class="text">
                            <span class="title">Delete Windows 96</span>
                            <span class="desc">Completely wipe your installation.</span>
                        </div>
                    </div>
                </div>
            </div>`
        }, true);

        const container = appWnd.getBodyContainer();

        const appBar = new MenuBar();
        
        appBar.addRoot("File", [
            { type: "normal", label: "Exit", onclick: ()=>{
                this.terminate();
            }}
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "About", onclick: ()=>{
                MsgBoxSimple.info("About noTRON AV PRO", '<span class="bold-noaa">noTRON AV Pro Deluxe Edition</span><br>Version 1.0<br>', "OK");
            }}
        ]);

        container.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        container.querySelector('.close-active').addEventListener('click', ()=>{
            this.setBusy(true);
            WindowSystem.closeAllWindows(false);
            this.setBusy(false);
        });

        container.querySelector('.clear-boot').addEventListener('click', ()=>{
            this.setBusy(true);
            
            MsgBoxSimple.confirm("Are you sure you want to do this?", async (v)=>{
                if(!v)
                    return this.setBusy(false);

                try {
                    await FS.rmdir("c:/system/boot");
                    await FS.mkdir("c:/system/boot");
                    await FS.mkdir("c:/system/boot/apps");
                    MsgBoxSimple.info("Done", "/system/boot has successfully been cleared.", "Thanks");
                } catch(e) {
                    MsgBoxSimple.error("Error", e.toString(), "OK");
                }

                this.setBusy(false);
            });
        });

        container.querySelector('.item-scan').addEventListener('click', async()=>{
            //this.setBusy(true);

            // Open the scan wizard
            execCmd("scanwiz", []);

            //this.setBusy(false);
        });

        container.querySelector('.del-win96').addEventListener('click', ()=>{
            this.setBusy(true);

            MsgBoxSimple.confirm("Are you sure? YOU WILL LOSE EVERYTHING WITHOUT RECOVERY.", async (v)=>{
                if(!v)
                    return this.setBusy(false);

                try {
                    for(let v of (await FS.readdir("C:/"))) {
                        try {
                            if((await FS.filetype(v)) == 0)
                                await FS.rm(v);
                            else
                                await FS.rmdir(v);
                        } catch(e) {
                            console.error("Failed to delete: " + v);
                        }
                    }
                    MsgBoxSimple.info("Done", "System has been wiped, reboot will occur in 5 seconds.", "Thanks");
                    setTimeout(()=>document.location.reload(), 5000);
                } catch(e) {
                    MsgBoxSimple.error("Error", e.toString(), "OK");
                }

                this.setBusy(false);
            });
        });

        appWnd.show();
        this.appWnd = appWnd;
    }

    setBusy(is) {
        if(is)
            this.appWnd.getBodyContainer().querySelector('.container').classList.add('busy');
        else
            this.appWnd.getBodyContainer().querySelector('.container').classList.remove('busy');
    }
}