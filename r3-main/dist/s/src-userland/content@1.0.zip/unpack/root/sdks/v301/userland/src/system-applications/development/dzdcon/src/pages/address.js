/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "address",
    content: `
        <div class="container">
            <div>
                Please enter the address of your DevConnector server.<br><br>
                It should be displayed by your server instance upon starting.<br><br>
                When ready, press "Next" to begin a connection test.
                <br><br>
            </div>
            <div>
                <span>Address:</span><br>
                <input type="text" class="w96-textbox address-box">
            </div>
        </div>
    `,
    onrender: (app, contentEl)=>{
        // Called upon rendering
        /** @type {HTMLInputElement} */
        const addrBox = contentEl.querySelector('input');

        addrBox.value = installState.dcAddress;

        addrBox.addEventListener('input', (e) => {
            installState.dcAddress = e.target.value;
        });
    },
    buttons: [
        {
            cls: "next",
            enabled: true,
            onclick: (app)=> app.renderPage("ctest")
        },
        {
            cls: "back",
            enabled: true,
            onclick: (app)=> app.renderPage("intro")
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});