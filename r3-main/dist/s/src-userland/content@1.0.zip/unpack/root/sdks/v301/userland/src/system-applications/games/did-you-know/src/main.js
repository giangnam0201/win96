/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { rand } = w96.util;
const { MsgBoxSimple, SaveFileDialog, Theme } = w96.ui;

const facts = [
    "Your internet connection is working fine; No one replies to your e-mails because there is no one left.",
    "You can keep your Facebook memes on Facebook.",
    "You can use Find to locate your real father.\n\nBut I will save you the trouble, Windows 96 is your real father.",
    "You can use Windows Explorer to explore ideas too disturbing for normal humans to fathom.\nIf you start to go mad, run ScanDisk.",
    "You can delete c:/system to force Windows 96 to update.",
    "Windows 96 comes bundled with 4 default wallpapers.",
    "The magic number for JPEG is 0xff 0xd8 0xff.",
    "Your tweets do not have to be political.",
    "You can wipe your entire hard drive by clearing the application data.",
    "You do not need to use JQuery in your web projects.",
    "You can upload pictures of cats using the Uploader tool.",
    "You can delete the trash.",
    "Margaret Thatcher is still dead.",
    "You should seek help from the Windows 96 wiki so we can stop dealing with your stupid questions.",
    "Bill Gates full name is William Henry Gates III.",
    "Upgrading your internet speed will increase the download speed of Windows 96 updates.",
    "You can use common sense to figure out most of Windows 96.",
    "You can turn off your computer to reduce your electricity bill.",
    "We have a Discord server where you can report bugs and make suggestions (link on desktop).",
    "This copy of Windows is not genuine.",
    "GET OUT OF MY HEAD GET OUT OF MY HEAD GET OUT OF MY HEAD GET OUT OF MY HEAD GET OUT OF MY HEAD GET OUT OF MY HEAD GET OUT OF MY HEAD",
    "Internet Exploder can only show pages which allow themselves to be iframed and/or loaded by other webpages.",
    "You can store real files on Windows 96.",
    "Make regular backups of your data, we are not responsible if we destroy your important things with a crappy update!",
    "Do not install malicious javascripts, your browser may likely crash and you'll go mad.",
    "You cannot write any data to W:/, trust me.",
    "Do not delete c:/system, it will cause your system to perform a blue screen.",
    "We have no tip for today. Go outside and play ball, maybe watch a movie, or just sit there and do nothing.",
    "Unlike some other operating systems, we will never force you to update. Of course there might be negative implications for doing so, but that choice and responsibility rests in your hands.",
    "You can create a theme by creating a CSS file in c:/system/boot, which will override any loaded CSS in your current environment.",
    "You can change your current theme in Settings > Look and feel > Theme",
    "Ensure your applications use a consistent UI. Some operating systems don't do this, but this is what lets your users use your application without direct prior knowledge of it.",
    "The Wiki has some history about Windows 96 itself, check it out if you're interested!"
]

class DYKApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(argv.includes("--export")) {
            new SaveFileDialog("c:/user", [".json"], async (v)=>{
                if(v && (v.trim() != ""))
                    await FS.writestr(v, JSON.stringify(facts));
            }).show();
            return;
        }

        this._init();
    }


    async _init() {
        this.wnd = MsgBoxSimple.info("Tip", `<span class="bold-noaa">Did you know...</span><br><br><span class="fact"></span>`, "OK");
        this.wnd.dlg.setSize(405, 155);

        const wndIcon = this.wnd.dlg.wndObject.querySelector(".icon");
        wndIcon.className = "icon";
        wndIcon.style.backgroundImage = "url(" + await Theme.getIconUrl("apps/tips") + ")";

        const questionBtn = document.createElement("button");
        questionBtn.classList.add("w96-button");
        questionBtn.innerText = "?";
        questionBtn.onclick = ()=>this.generateTip();
        this.wnd.dlg.wndObject.querySelector(".buttons").prepend(questionBtn);

        this.wnd.dlg.onshown = ()=>{
            this.wnd.dlg.center();
            this.generateTip();
        }
    }

    async generateTip() {
        if(await FS.exists("c:/user/appdata/Tips/tips.json")) {
            FS.readstr("c:/user/appdata/Tips/tips.json").then((text)=>{
                const parsedFacts = JSON.parse(text);
                this.wnd.dlg.wndObject.querySelector(".fact").innerText = parsedFacts[rand(0, parsedFacts.length)];
            });
        }
        else this.wnd.dlg.wndObject.querySelector(".fact").innerText = facts[rand(0, facts.length)];
    }

    ontermination() {
        super.ontermination();
        
    }
}