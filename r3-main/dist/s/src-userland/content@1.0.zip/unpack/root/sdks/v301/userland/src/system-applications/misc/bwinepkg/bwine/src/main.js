/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

$$Include("./conredir.js")

/*
BoxedWine Application.

BoxedWine (C) boxedwine.org
BoxedWine for Win96 (C) windows96.net
*/

const { Theme, DialogCreator, MsgBoxSimple } = w96.ui;

// Write-back LocalStorage implementation
// A better implementation was planned but I don't know right now to be honest.

const WB_PATH = "c:/user/appdata/bWINE/Drive_D";
let fs_data = new Map();

class FakeLocalStorage {
    constructor() {}

    async init() {
        if(await FS.exists(WB_PATH))
            fs_data = JSON.parse(await FS.readstr(WB_PATH), (key, value) => {
                if (typeof value === 'object' && value !== null) {
                    if (value.type === 'Map') {
                        return new Map(value.value);
                    }
                }
                return value;
            });
    }

    async flush() {
        await FS.writestr(WB_PATH, JSON.stringify(fs_data, (key, value) => {
            if (value instanceof Map) {
                return {
                    type: 'Map',
                    value: Array.from(value.entries()),
                };
            } else {
                return value;
            }
        }));
    }

    getItem(key) {
        const sk = new String(key);

        if(fs_data.has(sk))
            return fs_data.get(sk);
        else return null;
    }

    key(i) {
        if (arguments.length === 0)
            throw new Error("Storage Failure");
        
        const arr = Array.from(fs_data.keys())
        return arr[i];
    }

    setItem(key, value) {
        fs_data.set(new String(key), new String(value));
    }

    removeItem(key) {
        fs_data.delete(new String(key));
    }

    get length() {
        return fs_data.size;
    }

    clear() {
        fs_data = new Map();
    }
}

/**
 * Default configuration values.
 */
const DEFAULT_CONFIG = {
    net: {
        ver_repo: "https://packages.windows96.net/main/dist/w/wine/versions"
    },
    wine: {
        version: "wine31"
    },
    emulator: {
        cpu: "",
        video: {
            bpp: 32,
            frameSkip: 0,
            resolution: "800x600"
        },
        sound: true,
        showDebugConsole: false
    },
    vdisks: []
}

/**
 * Main app class.
 */
class BoxedWineApplication extends WApplication {
    constructor() {
        super();
        this.blobsToUnload = [];
        this.wbPersist = new FakeLocalStorage(); // Writeback persist storage
        this.debugCon = null;
    }

    async mkblob(path) {
        const u = URL.createObjectURL(await FS.toBlob(path));
        this.blobsToUnload.push(u);
        return u;
    }
    
    async main(argv) {
        super.main(argv);

        // Setup FS
        if(!(await FS.exists("c:/user/appdata/bWINE")))
            await FS.mkdir("c:/user/appdata/bWINE");

        if(!(await FS.exists("c:/user/appdata/bWINE/ToWine")))
            await FS.mkdir("c:/user/appdata/bWINE/ToWine");

        // Show first boot dialog if needed
        if(!(await FS.exists("c:/user/appdata/bWINE/.first_boot"))) {
            await alert(`Welcome to Wine for Windows 96 (bWINE).<br>
<br>
Since this is your first time running bWINE, here are some important things you need to know:<br><br>
 - It will be slow, since BoxedWine (the backend) is emulating Wine through a Linux emulator.<br>
 - Wine 5.0 will esepcially take its time to boot.<br>
 - Different versions of Wine are available through the version selector.<br>
 - bWINE is currently experimental. A number of features will be missing.<br>
 - Take general Wine-isms into account (the usual problems with Wine under Linux)`, {icon:"info"}).wait();
            await FS.touch("c:/user/appdata/bWINE/.first_boot");
        }

        // Read config and create it if it doesnt exist.
        if(await FS.exists("c:/user/appdata/bWINE/config.json")) {
            this.config = {
                ...DEFAULT_CONFIG,
                ...JSON.parse(await FS.readstr("c:/user/appdata/bWINE/config.json"))
            }
        } else {
            this.config = { ... DEFAULT_CONFIG };
            await FS.writestr("c:/user/appdata/bWINE/config.json", JSON.stringify(this.config, null, 4));
        }

        // Check command line arguments

        if(argv.includes("--manage-versions"))
            return (await include("c:/local/bwine/scripts/version-mgr.js")).init(this);
        else if(argv.includes("--about"))
            return DialogCreator.create({
                title: "About bWINE",
                body: `<span class="bold-noaa">bWINE</span><br>Version 1.0<br><br>Uses BoxedWine, which can be found at <a href="#" onclick="w96.sys.execCmd('iexploder', ['http://boxedwine.org'])">boxedwine.org</a><br>
                Also uses WINE, which can be found at <a href="#" onclick="w96.sys.execCmd('iexploder', ['https://winehq.org'])">winehq.org</a>`,
                icon: "info" 
            });

        // Fetch versions and save download URL
        const statusUi = MsgBoxSimple.idleProgress("bWINE Init", "Fetching version information...");

        const v_resp = await fetch(this.config.net.ver_repo + "/index.json");
        const v_available = await v_resp.json();

        statusUi.closeDialog();

        const v_verObj = v_available.find(x => x.id == this.config.wine.version);

        // Check if config specified version exists.
        if(!v_verObj) {
            await alert(`Wine version in config not found. Press OK to close bWINE.`, { icon: "error" }).wait();
            return;
        }

        // Init writeback localStorage FS
        await this.wbPersist.init();
        await this.wbPersist.flush(); // Create the file

        // Parse the resolution
        let res = { w: 800, h: 600 };

        if(this.config.emulator.video.resolution) {
            const s = this.config.emulator.video.resolution.split('x');
            res.w = parseInt(s[0]);
            res.h = parseInt(s[1]) + 20;
        }

        // Initialize Main UI

        const mainwnd = this.createWindow({
            title: "WINE",
            icon: Theme.getIconUrl("exec", "small"),
            initialHeight: res.h,
            initialWidth: res.w,
            body: `<iframe></iframe>
            <style>
                .boxed-wine-app>iframe { border: none; height: 100%; width: 100%; }
            </style>`,
            bodyClass: "boxed-wine-app",
            controlBoxStyle: "WS_CBX_MINCLOSE",
            resizable: false,
            center: true,
            taskbar: true
        }, true); // true specifies that this is an app window (main window)
        
        const body = mainwnd.getBodyContainer();
        const appFrame = body.querySelector('iframe');

        appFrame.src = await this.mkblob("c:/local/bwine/res/frame.html");
        mainwnd.setWindowIcon(await this.mkblob("c:/local/bwine/res/icon.png"));

        appFrame.onload = async ()=>{
            appFrame.contentDocument.onclick = ()=>appFrame.focus();
            appFrame.contentWindow.wquit = ()=>mainwnd.close();

            // Load ZIP
            // appFrame.contentWindow.zipUrl = await this.mkblob("c:/local/bwine/versions/default.zip"); // TODO allow change
            // Program name

            // Assign console if desired
            if(this.config.emulator.showDebugConsole) {
                const cdr = new ConsoleRedirector();
                await cdr.init("WINE Console", await this.mkblob("c:/local/bwine/res/icon.png"));
                appFrame.contentWindow.console = cdr;
                this.debugCon = cdr;
            }

            appFrame.contentWindow.bwineCfg = this.config;
            appFrame.contentWindow.verBase = this.config.net.ver_repo;
            appFrame.contentWindow.zipName = v_verObj.file;
            appFrame.contentWindow.wndSetSize = (w, h)=>mainwnd.setSize(w, h);
            appFrame.contentWindow.urlParams = "p=" + ((argv[1] == null) ? v_verObj.defaultShell : argv[1]) + "&app=bwine.zip";
            appFrame.contentWindow.writebackFS = new Proxy(this.wbPersist, {
                set: (obj, prop, value)=> {
                    if (FakeLocalStorage.prototype.hasOwnProperty(prop)) {
                        this.wbPersist[prop] = value;
                    } else {
                        this.wbPersist.setItem(prop, value);
                    }
                    return true
                },
                get: (target, name) => {
                    if (FakeLocalStorage.prototype.hasOwnProperty(name)) {
                        return this.wbPersist[name];
                    }
                    
                    if (fs_data.has(name)) {
                        return this.wbPersist.getItem(name);
                    }
                }
            });

            const SCRIPTS = [
                "c:/local/bwine/scripts/browserfs.boxedwine.js",
                "c:/local/bwine/scripts/jszip.min.js",
                "c:/local/bwine/scripts/boxedwine-shell.js"
            ];

            const aDoc = appFrame.contentDocument;

            for(let script of SCRIPTS) {
                const scriptEl = aDoc.createElement("script");
                scriptEl.src = await this.mkblob(script);
                aDoc.body.appendChild(scriptEl);
            }

            // Modify the main script a little to inject the WASM blob
            const wasmBlob = await this.mkblob("c:/local/bwine/bin/bwine.wasm");
            let mainScript = await FS.readstr("c:/local/bwine/scripts/boxedwine.js");
            mainScript = mainScript.replace(/\%BWINE_WASM_FILE\%/g, wasmBlob);

            const scriptEl = document.createElement('script');
            scriptEl.async = true;
            scriptEl.innerText = mainScript;
            aDoc.body.appendChild(scriptEl);
        };

        mainwnd.show();
    }

    ontermination() {
        super.ontermination();

        for(let b of this.blobsToUnload)
            URL.revokeObjectURL(b);

        if(this.debugCon) {
            this.debugCon.tInt.stopHost();
            this.debugCon = null;
        }
    }
}