/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme } = w96.ui;
const { WindowParams } = w96;

const SERVER = "https://wiki96.sys42.net";

class Wiki96Application extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow();
    }


    async _createWindow() {
        var params = new WindowParams();
        params.title = "Wiki96";
        params.initialWidth = 1000;
        params.initialHeight = 600;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<iframe src="${SERVER}"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('wiki96-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("objects/help-book", '16x16'));

        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }
}