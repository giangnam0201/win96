/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple } = w96.ui;

class WPA_Application extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow();
    }

    _createWindow() {
        if(window.notGenuine) {
            MsgBoxSimple.error("License Expired", "Your Windows license is expired, please purchase a new license from our store.", "OK").setSize(350, 110).dlg.center();
            return;
        }

        MsgBoxSimple.confirm("For the low low price of FREE, you can activate Windows 96 today!\n\nWant to proceed?", (v)=>{
            if(v) {
                this.terminate();
                MsgBoxSimple.error("Activation Error", "This copy of Windows is not genuine.", "OK");
                // Set bg to black and other fun stuff
                document.querySelector(".user-desktop").style.background = "black";
                const not_genuine = document.createElement('div');
                not_genuine.classList.add('troll-not-genuine');
                not_genuine.innerHTML = `<span class="left">This copy of Windows is not genuine</span>
                <span class="right">This copy of Windows is not genuine</span>
                <span class="bleft">This copy of Windows is not genuine</span>
                <span class="bright">This copy of Windows is not genuine</span>`;
                document.body.appendChild(not_genuine);

                const movingText = document.createElement('div');
                movingText.innerText = "This copy of Windows is not genuine";
                movingText.classList.add('troll-not-genuine');

                let inc_x = 1;
                let inc_y = 1;

                function render() {
                    const bounds = movingText.getBoundingClientRect();
                    movingText.style.top = `${bounds.top + inc_y}px`;
                    movingText.style.left = `${bounds.top + inc_x}px`;

                    if(bounds.y > window.innerHeight)
                        inc_y = -1;
                    else if(inc_y < 0)
                        inc_y = 1;

                    if(bounds.x > window.innerWidth)
                        inc_x = -1;
                    else if(inc_x < 0)
                        inc_x = 1;

                    requestAnimationFrame(render);
                }

                render();

                document.body.appendChild(movingText);

                deregisterApp("explorer");
                deregisterApp("textpad");
                deregisterApp("dyk");
                
                registerApp("explorer", [], (args)=>{
                    MsgBoxSimple.error("Error", "This app is disabled because you didn't register your copy.", "Damn");
                });

                registerApp("textpad", [], (args)=>{
                    MsgBoxSimple.error("Error", "This app is disabled because you didn't register your copy.", "Damn");
                });

                registerApp("dyk", [], (args)=>{
                    MsgBoxSimple.info("Pro Tip", "You can end this hell of unregistered windows if you restart via start menu.", ":O");
                });

                document.body.oncontextmenu = (e)=>{
                    e.preventDefault();
                    MsgBoxSimple.error("Error", "Please register your copy of Windows to continue using Windows 96 uninterrupted.", "Damn").dlg.setPosition(e.x, e.y);
                }

                const stEl = document.createElement('style');
                stEl.innerText = `.w96_sm_logo .container .text::after {
                    content: 'Windows 96 (UNREGISTERED)';
                }
                
                .shell-icon .icon-image {
                    background: url(system/resource/themes/default/icons/error.png) !important;
                }`;
                document.body.appendChild(stEl);

                setTimeout(()=>{
                    MsgBoxSimple.error("Error", "Color display is only available for genuine Windows 96.", ":(");
                    document.body.style.filter = "grayscale(1)";
                }, 2000);

                setInterval(()=>{
                    MsgBoxSimple.error("Error", "Failed to load DLL - You didn't register your copy of Windows.", "Damn").dlg.randomizePosition();
                }, 10000);

                window.notGenuine = true;
            }
        });
    }
}