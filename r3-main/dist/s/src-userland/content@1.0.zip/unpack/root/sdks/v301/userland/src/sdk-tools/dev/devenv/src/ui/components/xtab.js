/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

class ExtendedTabControl extends UIComponent {
    constructor() {
        super();

        this.createdTabs = 0;
        this.activePage = -1;
        this.pages = [];
        this.sharedPageSources = [];

        this.uiComponent = document.createElement('div');
        this.uiComponent.classList.add('wde-xtab-control');

        // Create pages container
        const pagesCntEl = document.createElement('div');
        pagesCntEl.classList.add('pages');
        this.pagesCntEl = pagesCntEl;
        this.uiComponent.appendChild(pagesCntEl);

        // Create content container
        const contentCntEl = document.createElement('div');
        contentCntEl.classList.add('content');
        this.contentCntEl = contentCntEl;
        this.uiComponent.appendChild(contentCntEl);
    }

    /**
     * Hides all pages.
     */
    hideAllPages() {
        const pages = this.contentCntEl.querySelectorAll(".page");

        for(let page of pages)
            page.style.display = "none";
    }

    /**
     * Adds a page.
     * @param {*} options Page options
     */
    addPage(options = {}) {
        const params = {
            ...{
                type: "normal", // Choice: "normal" : "templated"
                persist: true, // Whether to redraw contents on tab activate. This option will keep the tab page peristent
                closeable: true,
                label: "New Tab",
                icon: null,
                pageSource: null, // Page source to use
                ondraw: async()=>{},
                onclose: async()=>{},
                id: this.createdTabs++
            },
            ...options
        }

        // Create page button
        const pageBtn = document.createElement('div');
        pageBtn.classList.add('tab');

        // Create icon if needed
        if(params.icon) {
            const iconEl = document.createElement('div');
            iconEl.classList.add('icon');
            iconEl.style.backgroundImage = `url(${params.icon})`;
            pageBtn.appendChild(iconEl);
        }

        // Create text label
        if(params.label) {
            const labelEl = document.createElement('div');
            labelEl.classList.add('name');
            labelEl.textContent = params.label;
            pageBtn.appendChild(labelEl);
        }

        // Create close button
        if(params.label) {
            const closeBtn = document.createElement('div');
            closeBtn.classList.add('close');

            closeBtn.addEventListener('click', async(e)=>{
                e.stopPropagation();
                await params.onclose();
                this.closeTab(params.id);
            });

            pageBtn.appendChild(closeBtn);
        }

        // Add event
        pageBtn.addEventListener('click', ()=>{
            this.activate(params.id);
        });

        pageBtn.classList.add(`i-${params.id}`);
        
        this.pagesCntEl.appendChild(pageBtn);

        // Add page to pages registry
        this.pages.push(params);

        return params.id;
    }

    /**
     * Closes the specified tab.
     * @param {number} id The ID of the tab to close. 
     */
    closeTab(id) {
        const pageIndex = this.pages.findIndex(x => x.id == id);
        const page = this.pages[pageIndex];

        if(!page)
            throw new Error("Page not found.");

        // Remove content page element
        const contentPageEl = this.contentCntEl.querySelector(`.i-${page.id}`);
        
        if(contentPageEl)
            contentPageEl.remove();

        // Remove tab
        const tabPageEl = this.pagesCntEl.querySelector(`.i-${page.id}`);

        if(tabPageEl)
            tabPageEl.remove();

        // Finally, remove page from registry
        this.pages.splice(pageIndex, 1);
    }

    /**
     * Activates a tab with the specified ID.
     * @param {number} id The ID of the tab to activate.
     */
    async activate(id) {
        const page = this.pages.find(x => x.id == id);

        if(!page)
            throw new Error("Page not found.");

        // Unactivate all tabs
        for(let e of this.pagesCntEl.children)
            if(e.classList.contains('active'))
                e.classList.remove('active');

        // Hide all pages
        this.hideAllPages();

        // Remove non persistent pages
        for(let p of this.contentCntEl.children)
            if(!p.classList.contains("ps"))
                p.remove();

        // Check if persistent page has page registered
        // If yes, switch to that page
        // If not, create page and draw
        
        let contentPageEl = this.contentCntEl.querySelector(`.i-${page.id}`);

        if(!contentPageEl) {
            contentPageEl = document.createElement('div');
            contentPageEl.classList.add('page', `i-${page.id}`);
            await page.ondraw(contentPageEl);
            this.contentCntEl.appendChild(contentPageEl);

            if(page.persist)
                contentPageEl.classList.add('ps');
        }
        else
            contentPageEl.style.display = "";

        // Activate tab element
        const tabEl = this.pagesCntEl.querySelector(`.i-${page.id}`);
        tabEl.classList.add('active');
    }
}