/*
Sample GUI App Template
Copyright (C) Author 2023.

< Shorthand license may be added here >
*/

const { Theme } = w96.ui;

/**
 * The app class.
 */
class GUIApplication extends WApplication {
    /**
     * Constructs a new GUIApplication instance.
     */
    constructor() {
        super();
    }

    /**
     * Program entry point.
     * @param {string[]} argv The program arguments.
     * @returns {number} Exit code.
     */
    async main(argv) {
        await super.main(argv);

        // Create a new main window
        const mainwnd = this.createWindow({
            title: "My Window",
            initialHeight: 400,
            initialWidth: 400,
            center: true,
            taskbar: true,
            icon: await Theme.getIconUrl("mime/executable", '16x16'),
            bodyClass: "my-window-app"
        }, true);

        // Set some content
        const body = mainwnd.getBodyContainer();
        body.appendChild(new Text("Hello, world!"));

        // Show main window
        mainwnd.show();
    }

    /**
     * Program cleanup function.
     * 
     * Called on program exit.
     */
    async onterminate() {
        await super.onterminate();

        // Cleanup code
    }
}

