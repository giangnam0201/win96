/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Adds the volume path.
 * @param {TabControl} tabc The tab control.
 * @param {String} path The path to the volume.
 */
function addVolumeTab(tabc, path) {
    tabc.addPage("Volume", (e) => {
        e.classList.add("tab-volume");

        // Get FS info
        const dp = FSUtil.deconstructFullPath(path);
        const fso = FS.get(dp.prefix);

        if(!fso)
            return; // Cannot get FS info somehow?

        appendFields(e, [
            { name: "Driver Name", value: fso.driverName },
            { name: "Features", value: (fso.features.length > 0) ? fso.features.join(', ') : "(no special features)" },
            { name: "Label", value: fso.volumeLabel }
        ]);
    });
}