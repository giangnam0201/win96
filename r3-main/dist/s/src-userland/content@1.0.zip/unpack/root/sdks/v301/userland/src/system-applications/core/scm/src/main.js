/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

$$Include("./include/eresource.js")
$$Include("./include/util.js")
$$Include("./include/dialogs.js")

const { Theme, MenuBar, DialogCreator } = w96.ui;
const { ToolBar } = w96.ui.components;
const { sysConf: SCM } = w96;

/*
System Configuration Manager.

Copyright (C) windows96.net 2023. All rights reserved.
*/

class SCMApp extends WApplication {
    constructor() {
        super();
        this.currentPath = "";
        this.state = {
            toolsObjectMenuItems: []
        };
    }

    /**
     * Program entry point.
     */
    async main(argv) {
        await super.main(argv);

        // Show warning dialog
        if (!SCM.get("Software/SCM/UI/userWarningShown")) {
            let result;

            // Show user warning
            const dlg = DialogCreator.confirm("The System Configuration Manager (SCM) is a system tool that has the potential to completely damage your system if used incorrectly!<br><br>Are you sure you want to continue?", {
                title: "SCM",
                icon: "warning"
            }, (v) => result = v);

            await dlg.wait();

            if (result) {
                SCM.setAndSync("Software/SCM/UI/userWarningShown", true);
            }
            else {
                this.terminate();
                return;
            }
        }

        // Create main window
        const mainwnd = this.createWindow({
            title: "<config root> - System Configuration Manager",
            icon: await Theme.getIconUrl("apps/registry", '16x16'),
            body: `<div class="appbar"></div>
            <div class="toolbar"></div>
            <div class="container">
                <div class="item-view w96-inset">

                </div>
                <div class="preview w96-inset"></div>
            </div>
            <footer class="w96-footer">
                <div class="cell">
                    (none)
                </div>
            </footer>
            <style>
                ${StyleCSS.Main}
            </style>`,
            bodyClass: "scm-app",
            initialHeight: 449,
            initialWidth: 641,
            taskbar: true
        }, true);

        // Get body
        const body = mainwnd.getBodyContainer();

        // Create appbar
        const appBar = new MenuBar();

        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: () => this.terminate()
            }
        ]);

        appBar.addRoot("Tools", [
            {
                type: "submenu",
                label: "Object...",
                items: this.state.toolsObjectMenuItems = [
                    {
                        id: "fromJson",
                        type: "normal",
                        label: "From JSON",
                        icon: await Theme.getIconUrl("actions/from-json", '16x16'),
                        onclick: () => uiNewValue(this, "insert-json")
                    },
                    {
                        type: "separator"
                    },
                    {
                        id: "toJson",
                        type: "normal",
                        label: "To JSON",
                        icon: await Theme.getIconUrl("actions/to-json", '16x16'),
                        onclick: () => DialogCreator.fieldset([
                            { type: "text", value: "JSON Data" },
                            { type: "textbox", multiline: true, value: JSON.stringify(SCM.get(`${this.currentPath}/${this.selectedIcon.getAttribute("name")}`)), attr: [{ name: "readonly", value: "" }] }
                        ], {
                            title: `JSON for ${this.selectedIcon.getAttribute("name")}`,
                            buttons: [
                                {
                                    "id": "ok",
                                    "text": "OK",
                                    "action": "$close"
                                }
                            ]
                        })
                    },
                    {
                        id: "toString",
                        type: "normal",
                        label: "To String",
                        icon: await Theme.getIconUrl("actions/to-string", '16x16'),
                        onclick: () => DialogCreator.fieldset([
                            { type: "text", value: "toString() Data" },
                            { type: "textbox", multiline: true, value: new String(SCM.get(`${this.currentPath}/${this.selectedIcon.getAttribute("name")}`)), attr: [{ name: "readonly", value: "" }] }
                        ], {
                            title: `toString() for ${this.selectedIcon.getAttribute("name")}`,
                            buttons: [
                                {
                                    "id": "ok",
                                    "text": "OK",
                                    "action": "$close"
                                }
                            ]
                        })
                    }
                ]
            }
        ], false);

        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About SCM...",
                onclick: async () => DialogCreator.alert(`<span class="bold-noaa">System Configuration Manager</span><br>Version 1.0<br><br>Copyright (C) Windows 96 Team 2023.`, { icon: await Theme.getIconUrl('apps/registry', '32x32'), title: "About SCM" })
            }
        ]);

        body.querySelector(".appbar").replaceWith(appBar.getMenuDiv());

        // Add toolbar
        const toolbar = new ToolBar();

        toolbar.addItem({
            name: "newKey",
            text: "New Key",
            imageUrl: await Theme.getIconUrl("places/folder", '24x24'),
            onclick: () => uiNewKey(this, this.currentPath)
        });

        toolbar.addItem({
            name: "newValue",
            text: "New Value",
            imageUrl: await Theme.getIconUrl("mime/bin-data", '24x24'),
            onclick: () => uiNewValue(this, "new-value")
        });

        toolbar.addSeparator();

        toolbar.addItem({
            name: "up",
            text: "Up",
            imageUrl: await Theme.getIconUrl("actions/up", '24x24'),
            onclick: () => {
                if (this.currentPath.includes("/"))
                    this.navigate(this.currentPath.substring(0, this.currentPath.lastIndexOf('/')));
                else
                    this.navigate("");
            }
        });

        toolbar.addItem({
            name: "delete",
            text: "Delete",
            imageUrl: await Theme.getIconUrl("actions/delete", '24x24'),
            onclick: () => {
                if (this.selectedIcon)
                    uiDelete(this, this.currentPath + "/" + this.selectedIcon.getAttribute("name"))
            }
        });

        body.querySelector(".toolbar").replaceWith(toolbar.getElement());

        mainwnd.onshown = () => {
            this.refreshView();
        }

        // Setup itemview
        const itemView = mainwnd.getBodyContainer().querySelector('.item-view');

        itemView.addEventListener('click', (e) => {
            // Deselect items
            if (e.target != itemView) return;

            itemView.querySelectorAll(".selected").forEach((v) => v.classList.remove('selected'));
            this.setPreviewText("");
            this.selectedIcon = null;
            this.updateMbar();
        });

        mainwnd.show();
        this.mainwnd = mainwnd;
        this.toolbar = toolbar;
    }

    /**
     * Disables all items in the specified item group.
     */
    __disableAllItems(a, filter = []) {
        for (let i of a)
            if (!filter.includes(i.id || ""))
                i.disabled = true;
            else
                i.disabled = false;
    }

    /**
     * Enables all items in the specified item group.
     */
    __enableAllItems(a, filter = []) {
        for (let i of a)
            if (!filter.includes(i.id || ""))
                i.disabled = false;
            else
                i.disabled = true;
    }

    /**
     * Updates the menu bar.
     */
    updateMbar() {
        // Reset mbar items
        this.__enableAllItems(this.state.toolsObjectMenuItems);

        // SCM root
        if (this.currentPath == "") {
            this.__disableAllItems(this.state.toolsObjectMenuItems);
            return;
        }

        // Check for item specific stuff
        if (!this.selectedIcon)
            this.__disableAllItems(this.state.toolsObjectMenuItems, ["fromJson"]);
    }

    /**
     * Updates toolbar status.
     */
    updateToolbar() {
        this.toolbar.resetItemStates();

        if (this.currentPath == "") {
            // Disable buttons for SCM root
            this.toolbar.setDisabled("newKey", true);
            this.toolbar.setDisabled("newValue", true);
            this.toolbar.setDisabled("up", true);
            this.toolbar.setDisabled("delete", true);
        }
    }

    /**
     * Creates an icon.
     */
    createIcon(icon, label) {
        const itemView = this.mainwnd.getBodyContainer().querySelector('.item-view');

        const iconEl = document.createElement('div');
        iconEl.classList.add('shell-icon');
        iconEl.setAttribute("name", label);
        iconEl.style.display = "inline-flex";
        iconEl.style.position = "relative";
        iconEl.style.flexDirection = "column";
        iconEl.addEventListener('click', () => {
            this.selectedIcon = iconEl;
            itemView.querySelectorAll(".selected").forEach((v) => v.classList.remove('selected'));
            iconEl.classList.add('selected');
            this.updateMbar();
        });

        const iconImageEl = document.createElement('div');
        iconImageEl.classList.add('icon-image');
        iconImageEl.style.backgroundImage = `url(${icon})`;
        iconEl.appendChild(iconImageEl);

        const iconTextEl = document.createElement('div');
        iconTextEl.classList.add('icon-text');
        iconTextEl.textContent = label;
        iconEl.appendChild(iconTextEl);
        return iconEl;
    }

    /**
     * Sets the preview text.
     */
    setPreviewText(text) {
        const previewPane = this.mainwnd.getBodyContainer().querySelector('.preview');
        previewPane.textContent = text; // We must allow HTML formatting
    }

    /**
     * Navigates to the specified path.
     * @param {String} path The path to navigate to.
     */
    async navigate(path) {
        this.setPreviewText("");
        this.selectedIcon = null;
        const items = SCM.ls(path);
        /** @type {HTMLDivElement} */
        const itemView = this.mainwnd.getBodyContainer().querySelector('.item-view');

        // Remove previous items
        while (itemView.firstChild)
            itemView.removeChild(itemView.firstChild);

        // Add items
        let keyEls = []; // "Dirs"
        let valueEls = []; // "Files"

        for (let i of items) {
            let icon;
            let iconName;
            let description = "";
            let type;
            let obj;

            switch (i.type) {
                case "root":
                    icon = this.createIcon(await Theme.getIconUrl("places/folder-locked", '32x32'), i.name);
                    icon.addEventListener('click', () => this.setPreviewText(SCM.getIndex(i.name).description));
                    keyEls.push(icon);
                    icon.addEventListener('dblclick', () => this.navigate(i.name));

                    break;

                case "key":
                    obj = SCM.get(path + "/" + i.name);

                    if (obj instanceof Array) {
                        description = "Type: Array"
                        iconName = "objects/folder-array";
                    } else {
                        description = "Type: Key/Object";
                        iconName = "places/folder";
                    }

                    icon = this.createIcon(await Theme.getIconUrl(iconName, '32x32'), i.name);
                    keyEls.push(icon);
                    icon.addEventListener('dblclick', () => this.navigate(this.currentPath + "/" + i.name));
                    icon.addEventListener('click', () => this.setPreviewText(description));
                    break;

                case "value":
                    try {
                        obj = SCM.get(path + "/" + i.name);
                    } catch (e) {
                        obj = null; // Set to null
                    }

                    type = typeof obj;

                    switch (type) {
                        default:
                            iconName = "mime/bin-data";
                            description = "Type: Unknown";
                            break;
                        case "function":
                            if (isClass(obj)) {
                                description = "Type: Class";
                                iconName = "objects/object-class";
                                // Add double click for class
                            } else if (isAsyncFunction(obj)) {
                                description = "Type: Asynchronous Function";
                                iconName = "objects/fn-async";
                            } else if (i.name == "toString") {
                                let objTstr;

                                try {
                                    objTstr = obj();
                                } catch (e) {
                                    objTstr = "<toString() failure>";
                                }

                                description = `Type: ToString function\nLength: ${objTstr.length}\nValue: ${(objTstr.length > 200) ? '<String truncated>' : objTstr}`;
                                iconName = "objects/fn-tostring";
                            } else {
                                description = "Type: Function";
                                iconName = "objects/bin-data-exec";
                            }
                            break;
                        case "string":
                            iconName = "mime/str-data";
                            description = `Type: String\nLength: ${obj.length}\nValue: ${(obj.length > 200) ? '<String truncated>' : obj}`;
                            break;
                        case "number":
                            iconName = "objects/numbers";
                            description = `Value: ${obj}`;
                            break;
                        case "boolean":
                            iconName = "objects/object-bool";
                            description = `Value: ${obj}`;
                            break;
                        case "object":
                            if (obj !== null) {
                                break;
                            }

                            iconName = "objects/object-null";
                            description = `Value: Null`;
                            break;
                        case "undefined":
                            iconName = "objects/object-null-2";
                            description = `Value: Undefined`;
                            break;
                    }

                    try {
                        icon = this.createIcon(await Theme.getIconUrl(iconName, '32x32'), i.name);
                        valueEls.push(icon);

                        if (isClass(obj))
                            icon.addEventListener('dblclick', () => this.navigate(this.currentPath + "/" + i.name));

                        icon.addEventListener('click', () => this.setPreviewText(description));
                        icon.addEventListener('dblclick', () => {
                            switch(type) {
                                case "object":
                                case "boolean":
                                case "number":
                                case "string":
                                    uiNewValue(this, "edit-value", i.name)
                                    break;
                            }
                        });
                    } catch (e) {
                        // Oops
                    }
                    break;
            }
        }

        // Append items
        for (let k of keyEls)
            itemView.appendChild(k);

        for (let v of valueEls)
            itemView.appendChild(v);

        // Sort function
        keyEls.sort(alphaSortFn);
        valueEls.sort(alphaSortFn);

        // Move icons into place
        const sortFn = (iconEl) => {
            iconEl.style.marginRight = "3px";
            iconEl.style.marginBottom = "19px";
        }

        keyEls.forEach(sortFn);
        valueEls.forEach(sortFn);

        // Cleanup
        keyEls = null;
        valueEls = null;

        this.currentPath = path;
        this.mainwnd.setTitle(`${(this.currentPath == "") ? "<config root>" : FSUtil.fname(this.currentPath)} - System Configuration Manager`);
        this.mainwnd.getBodyContainer().querySelector("footer .cell").textContent = (this.currentPath == "") ? "<config root>" : this.currentPath;
        this.updateToolbar();
        this.updateMbar();
    }

    /**
     * Refreshes the view.
     */
    async refreshView() {
        await this.navigate(this.currentPath);
    }

    /**
     * Executes on app termination.
     */
    async ontermination() {
        await super.ontermination();
        this.mainwnd = null;
        this.toolbar = null;
    }
}