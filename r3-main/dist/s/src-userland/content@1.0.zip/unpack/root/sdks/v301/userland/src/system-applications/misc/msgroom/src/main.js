/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, MenuBar, MsgBoxSimple, DialogCreator } = w96.ui;
const { sideloadZip } = w96.util;
const { execCmd } = w96.sys;

const THEME_PATH_BASE = "c:/user/appdata/MsgRoom/themes";

class Win96ChatApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        this.config = {
            currentTheme: null,
            disableWin96Detection: false
        };

        if(!(await FS.exists("C:/user/appdata/MsgRoom")))
            await FS.mkdir("C:/user/appdata/MsgRoom");

        if(!(await FS.exists("C:/user/appdata/MsgRoom/config.json")))
            await FS.writestr("C:/user/appdata/MsgRoom/config.json", JSON.stringify(this.config, null, 4));

        this.config = {
            ...this.config,
            ...JSON.parse(await FS.readstr("C:/user/appdata/MsgRoom/config.json"))
        }

        if(!(await FS.exists("C:/user/appdata/MsgRoom/themes"))) {
            await FS.mkdir("C:/user/appdata/MsgRoom/themes");

            const idleProgress = MsgBoxSimple.idleProgress("MsgRoom", "Loading default themes...");

            try {
                await sideloadZip("/system/data/msgroom/themes_default.zip");
            } catch(e) {
                DialogCreator.create({
                    icon: "warning",
                    body: "Error fetching default themes!<br><br>Please check your internet connection or contact the developers."
                });
            }

            idleProgress.closeDialog();
        }

        this._createWindow(argv);
    }

    async applyTheme(name) {
        // Apply theme from msgroom dir
        const CSS_PATH = THEME_PATH_BASE + "/" + name + ".css";

        if(!(await FS.exists(CSS_PATH))) {
            DialogCreator.create({
                icon: "warning",
                body: "Theme does not exist."
            });

            return;
        }

        const cssContent = await FS.readstr(CSS_PATH);

        this.appFrame.contentWindow.postMessage({
            op: "wui-css-set",
            css: cssContent
        }, this.CHAT_URL);

        if(this.config.currentTheme != name) {
            // Write changed theme
            this.config.currentTheme = name;
            await FS.writestr("C:/user/appdata/MsgRoom/config.json", JSON.stringify(this.config, null, 4));
        }
    }

    /**
     * Reads the themes.
     */
    async readThemesMenu() {
        const items = [];

        (await FS.readdir(THEME_PATH_BASE)).forEach((v)=>{
            if(!v.endsWith(".css"))
                return;

            const fn = FSUtil.fname(v);
            const themeName = fn.substring(0, fn.length - 4);

            items.push({
                type: "normal",
                label: themeName,
                onclick: ()=>this.applyTheme(themeName)
            });
        });

        return [...items,
            { type: "separator" },
            {
                type: "normal",
                label: "Open themes directory",
                onclick: ()=>{
                    execCmd("explorer", [THEME_PATH_BASE]);
                }
            }
        ];
    }

    async _createWindow(argv) {
        let CHAT_URL = "https://devel.windows96.net:4096/"; // do something about this pls

        if(argv.includes("--devel-local"))
            CHAT_URL = "http://127.0.0.1:4096/";
        else if(argv.includes("--devel-local"))
            CHAT_URL = "https://devel.windows96.net:4096/";

        argv.forEach((v, i, a)=>{
            if((v == "--server") && (!((i+1) >= a.length)))
                CHAT_URL = a[i+1];

        });

        this.CHAT_URL = CHAT_URL;

        const mainwnd = this.createWindow({
            title: "MsgRoom",
            initialWidth: 640,
            initialHeight: 441,
            taskbar: true,
            body: `<div class="appbar"></div><iframe src="${CHAT_URL}" allow="clipboard-write"></iframe>`,
            bodyClass: "win96chat-app",
            icon: await Theme.getIconUrl("apps/chat", '16x16'),
            iframeFix: true
        }, true);

        const body = mainwnd.getBodyContainer();
        const appFrame = body.querySelector("iframe");

        // Create menu bar
        const appBar = new MenuBar();

        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.mainwnd.close()
            }
        ]);

        appBar.addRoot("Session", [
            {
                type: "submenu",
                label: "Themes",
                removeIconPrespace: true,
                items: await this.readThemesMenu()
            },
            {
                type: "normal",
                label: "Change Nick",
                onclick: ()=>MsgBoxSimple.prompt("Set Nickname", "Enter a new nickname", "anonymoose", (v)=>{
                    if((v == null) || (v.trim() == "")) return;
                    appFrame.contentWindow.postMessage({
                        op: "wui-nick-change",
                        args: {
                            value: v
                        },
                    }, CHAT_URL);
                })
            }
        ]);

        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "View Help",
                onclick: ()=>{
                    appFrame.contentWindow.postMessage({
                        op: "wui-print-help",
                        args: {}
                    }, CHAT_URL);
                }
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "About",
                onclick: async()=>{
                    const aboutWnd = this.createWindow({
                        title: "About MsgRoom",
                        controlBoxStyle: "WS_CBX_CLOSE",
                        initialHeight: 165,
                        initialWidth: 276,
                        taskbar: false,
                        bodyClass: "msgroom-about-dlg",
                        body: `<div class="icon" style="background-image: url(${await Theme.getIconUrl('apps/chat', '32x32')})"></div>
                        <div class="p2">
                            <div class="title">MsgRoom</div>
                            <div class="subtext">Social messaging chatroom<br>
                            Version 1.0<br>
                            <br>
                            Copyright (C) windows96.net 2023.
                            </div>
                            <div class="buttons">
                                <button class="w96-button close">OK</button>
                            </div>
                        </div>`,
                        center: true,
                        resizable: false
                    }, false);

                    aboutWnd.show();
                    aboutWnd.getBodyContainer().querySelector('.close').addEventListener('click', ()=>aboutWnd.close());
                }
            }
        ]);

        body.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        appFrame.onload = ()=> {
            if(this.config.currentTheme)
                this.applyTheme(this.config.currentTheme);

            appFrame.contentWindow.postMessage({
                op: "w96-app-init",
                args: {
                    pid: this.appId,
                    disableWin96Detection: this.config.disableWin96Detection
                }
            }, CHAT_URL);
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }
}