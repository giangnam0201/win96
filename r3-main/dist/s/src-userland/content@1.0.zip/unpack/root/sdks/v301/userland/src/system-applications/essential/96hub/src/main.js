/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, DialogCreator, UI, Theme } = w96.ui;

/**
 * 96Hub applicaton class.
 */
class HubApplication extends WApplication {
    constructor() {
        super();

        this.currentPage = "";

        this.mainwnd = this.createWindow({
            title: "96Hub",
            bodyClass: "hub-app",
            windowClass: "hub-wnd",
            taskbar: true,
            body: `
                <div class="top">
                    <div class="brand">
                        <div class="logo">
                            <div class="icon"></div>
                            <div class="title">96HUB</div>
                        </div>
                        <div class="subtext">
                            The hub for all things Windows 96
                        </div>
                    </div>
                </div>
                <div class="grad-line"></div>
                <div class="content">
                    <div class="left">

                    </div>
                    <div class="right">

                    </div>
                </div>
                <div class="bottom">
                    <button class="w96-button exit">Exit</button>
                </div>
            `,
            initialWidth: 680,
            initialHeight: 480,
            center: true,
            resizable: false,
            controlBoxStyle: "WS_CBX_MINCLOSE"
        });

        Theme.getIconUrl("apps/96hub", "16x16").then((v)=>this.mainwnd.setWindowIcon(v));

        const body = this.mainwnd.getBodyContainer();

        body.querySelector("button.exit").addEventListener('click', ()=>this.terminate());
    }

    /**
     * Opens a hub page.
     * @param {String} id The ID of the page to open.
     */
    async openPage(id) {
        // Make UI busy
        const body = this.mainwnd.getBodyContainer();
        body.classList.add('busy');

        // Find page config
        const page = this.config.pages.find(x => x.id == id);

        if(!page) {
            body.classList.remove('busy');
            
            DialogCreator.create({
                title: "Fatal Error",
                icon: "error",
                body: "Page definition not found."
            });

            return;
        }

        let pageText;
        // Download the page
        try {
            const pageReq = await fetch(page.location);
            pageText = await pageReq.text();
        } catch(e) {
            body.classList.remove('busy');
            
            DialogCreator.create({
                title: "Fatal Error",
                icon: "error",
                body: "Unable to download the requested page."
            });

            return;
        }

        // Render the page
        const pageContentEl = body.querySelector(".content>.right");

        while(pageContentEl.firstChild)
            pageContentEl.removeChild(pageContentEl.firstChild);

        pageContentEl.innerHTML = pageText;

        // Create controls
        pageContentEl.querySelectorAll(".expand-img").forEach((v)=>{
            let originalWidth = v.style.width;

            v.addEventListener('click', ()=>{
                if(v.style.width !== originalWidth)
                    v.style.width = originalWidth;
                else
                    v.style.width = '';    
            });
        });

        pageContentEl.querySelectorAll(".nav-link").forEach((v)=>{
            const type = v.getAttribute("type");

            switch(type) {
                case "app":
                    v.addEventListener('click', ()=>{
                        w96.sys.execCmd(v.getAttribute("app-name"), []);
                    });
                    break;
                case "page":
                    v.addEventListener('click', ()=>{
                        this.openPage(v.getAttribute("page-name"));
                    });
                    break;
            }
        });

        pageContentEl.querySelectorAll(".w96-button.info-wnd").forEach((v)=>{
            const infPath = v.getAttribute("info-path");
            
            if((infPath == null) || (infPath.trim() == ""))
                return;
            
            v.addEventListener('click', async()=>{
                const infoWnd = this.createWindow({
                    title: "Information",
                    initialHeight: 400,
                    initialWidth: 400,
                    controlBoxStyle: "WS_CBX_CLOSE",
                    resizable: false,
                    taskbar: false,
                    center: true,
                    bodyClass: "hub-app-info-wnd",
                    body: `<textarea class="w96-textbox" readonly></textarea>
                    <div class="buttons">
                        <button class="w96-button btnok">OK</button>
                    </div>`
                });

                const body = infoWnd.getBodyContainer();
                
                body.querySelector('textarea').value = await (await fetch(infPath)).text();
                body.querySelector(".btnok").addEventListener('click', ()=>infoWnd.close());

                infoWnd.show();
            });
        });

        body.classList.remove('busy');
        this.currentPage = id;
    }

    /**
     * Main entry point.
     * @param {String[]} argv Arguments
     */
    async main(argv) {
        super.main(argv);

        if(document.body.querySelectorAll(".hub-wnd").length > 1) {
            alert("Only one instance may be running!", { icon: "error" });
            this.terminate();
        }

        const body = this.mainwnd.getBodyContainer();
        body.querySelector(".brand>.logo>.icon").style.backgroundImage = `url(${await Theme.getIconUrl("apps/96hub", "32x32")})`;

        // Add loading box

        const idp = MsgBoxSimple.idleProgress("96Hub", "Loading data, please wait...");

        try {
            const req = await fetch("https://etc.windows96.net/96hub/config.json");
            this.config = await req.json();

            const sidebar = body.querySelector(".content>.left");

            // Populate sidebar
            for(let menu of this.config.sidebar) {
                // Create header
                const headerEl = document.createElement('div');
                headerEl.className = "header";
                headerEl.textContent = menu.name;
                sidebar.appendChild(headerEl);

                // Create list for items
                const itemsEl = document.createElement('div');
                itemsEl.className = "list";
                
                // Add items
                for(let item of menu.items) {
                    const mItemEl = document.createElement('div');
                    mItemEl.className = "item";
                    mItemEl.textContent = item.name;
                    // TODO set target
                    
                    switch(item.target.type) {
                        case "page":
                            mItemEl.addEventListener('click', ()=>{
                                sidebar.querySelectorAll(".selected").forEach((v)=>{
                                    v.classList.remove('selected');
                                });

                                mItemEl.classList.add('selected');
                                this.openPage(item.target.location);
                            });
                            break;
                    }

                    // Add item to list
                    itemsEl.appendChild(mItemEl);
                }

                sidebar.appendChild(itemsEl);
            }
        } catch(e) {
            DialogCreator.create({
                title: "Fatal Error",
                body: "Unable to fetch current 96Hub data."
            });
            
            this.terminate();
        }

        idp.closeDialog();

        // Show start page
        this.openPage(this.config.startPage);

        this.mainwnd.show();
    }
}