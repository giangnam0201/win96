/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const shell36 = w96.ipc.findIpcEQ("shell36");

/**
 * Gets an Xdg Icon url.
 * @param {*} xdgItem The Xdg item to work on.
 */
async function constructXdgIcon(xdgItem) {
    if((!CL_SETTINGS.loadXdgIcons) || (xdgItem.Icon == ""))
        return await Theme.getIconUrl("mime/executable", '16x16');

    let mime;

    switch(xdgItem.IconType) {
        default:
            return await Theme.getIconUrl("mime/executable", '16x16');
        case "png":
            mime = "image/png";
            break;
        case "jpg":
            mime = "image/jpeg";
            break;
    }

    let blob = new Blob([xdgItem.IconData], { type: mime });
    const dataURI = await w96.util.blobToDataURI(blob);
    blob = null;

    return dataURI;
}

/**
 * Shows the run box for a client.
 * @param {*} client The client to create a run box for.
 * @param {X11Application} app The app instance.
 */
async function showRunBox(client, app) {
    const runWnd = app.createWindow({
        title: "Run",
        initialHeight: 157,
        initialWidth: 341,
        resizable: false,
        bodyClass: "dlg-run-box",
        controlBoxStyle: "WS_CBX_CLOSE",
        center: true
    }, false);

    const body = runWnd.getBodyContainer();
    body.innerHTML = `
    <div class="exp">
        <div class="icon" style="background: url(${await Theme.getIconUrl("misc/run")})"></div>
        <div class="text">
            Type the name of a program and X11/Xpra will open it for you on "${client.address}".
        </div>
    </div>
    <div class="pbox">
        <div class="text">Open: </div>
        <input type="text" class="w96-textbox cmd">
    </div>
    <div class="buttons">
        <button class="w96-button ok">OK</button>
        <button class="w96-button cancel">Cancel</button>
        <button class="w96-button browse" disabled>Browse...</button>
    </div>
    `;

    const commandBox = body.querySelector('.w96-textbox');

    /**
     * Executes the command.
     */
    function execute() {
        client.client.start_command("Run", commandBox.value, "False");
        runWnd.close();
        w96.evt.shell.emit('start-close');
    }

    // Set events
    body.querySelector('button.ok').addEventListener('click', ()=>execute());

    commandBox.addEventListener('keydown', (e)=>{
        if(e.key == "Enter")
            execute();
    });

    body.querySelector('button.cancel').addEventListener('click', ()=>runWnd.close());

    runWnd.show();
}

/**
 * Registers or updates Xdg items in the start menu.
 * @param {X11Application} app The app instance.
 */
async function updateXdgStartMenu(app) {
    // Nothing to do.
    if(!CL_SETTINGS.registerStartMenuItem)
        return;

    const clients = app.activeClients;

    // Root item to add to the start menu
    const X11RootMenu = {
        name: "X11",
        type: "dir-menu",
        icon: "places/folder-x11",
        items: []
    };
this
    // Craft the menu
    for(let client of clients) {
        let rootMenuItems = [];

        // Create a root menu for this client if there are more present
        // Otherwise use the X11 one
        if(clients.length == 1)
            rootMenuItems = X11RootMenu.items;
        else {
            X11RootMenu.items.push({
                type: "submenu",
                label: client.address,
                icon: await Theme.getIconUrl("devices/computer", '16x16'),
                items: []
            });

            rootMenuItems = X11RootMenu.items[X11RootMenu.items.length - 1].items;
        }

        if(!client.client.xdg_menu)
            return; // Nothing to add

        // Pre: Add some control items
        rootMenuItems.push({
            type: "submenu",
            label: "Client Control",
            icon: await Theme.getIconUrl("places/folder", '16x16'),
            items: [
                {
                    type: "normal",
                    label: "Disconnect",
                    icon: await Theme.getIconUrl("status/no", '16x16'),
                    onclick: ()=> { app.disconnect(client); w96.evt.shell.emit('start-close'); }
                },
                { type: "separator" },
                {
                    type: "normal",
                    label: "Run Command",
                    icon: await Theme.getIconUrl("apps/prompt", '16x16'),
                    onclick: ()=>{ showRunBox(client, app); w96.evt.shell.emit('start-close'); }
                }
            ]
        });

        rootMenuItems.push({ type: "separator" });

        // Process Xdg menu
        const xdgMenu = client.client.xdg_menu;
        const menuObjects = Object.keys(xdgMenu);
        
        for(let k of menuObjects) {
            // Create folder
            let folderItem = {
                type: "submenu",
                label: xdgMenu[k].Name,
                icon: await Theme.getIconUrl("places/folder", '16x16'),
                items: []
            };

            // Process items in menu
            const subMenu = xdgMenu[k];

            for(let subK of Object.keys(subMenu.Entries)) {
                const xdgItem = subMenu.Entries[subK];
                
                const targetItem = {
                    type: "normal",
                    label: xdgItem.Name.trim(),
                    icon: await constructXdgIcon(xdgItem),
                    onclick: ()=> {
                        w96.evt.shell.emit('start-close');
                        const command = xdgItem.Exec.replace(/%[FUfu]/g, "");
                        client.client.start_command(xdgItem.Name, command, "False");
                    }
                }

                folderItem.items.push(targetItem);
            }

            rootMenuItems.push(folderItem);
        }
    }

    // Update menu
    // Get IPC
    const startMenuItems = { ... JSON.parse(JSON.stringify(w96.sysConf.get("Software/Shell36/StartMenu"))) };

    if(!shell36)
        return; // We are not using shell36.

    // Insert new root menu
    startMenuItems.items.splice(1, 0, X11RootMenu);

    // Update the menu
    shell36.emit('start-update', startMenuItems);
}

/**
 * Restores the original system menu.
 */
function restoreOriginalMenu() {
    shell36.emit('start-update', w96.sysConf.get("Software/Shell36/StartMenu"));
}