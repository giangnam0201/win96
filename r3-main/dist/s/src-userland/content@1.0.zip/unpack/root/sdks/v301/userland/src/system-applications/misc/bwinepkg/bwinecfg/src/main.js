/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, DialogCreator } = w96.ui;
const { TabControl, GroupBox, RadioBox, CheckBox, ListBox } = w96.ui.components;

/** Valid BPP values */
const VALID_BPP = [8, 16, 24, 32];

/** Reserved drive letters */
const RESERVED_LETTERS = ["C", "D", "E", "Z"];

/** The default configuration */
const DEFAULT_CONFIG = {
    net: {
        ver_repo: "https://packages.windows96.net/main/dist/w/wine/versions"
    },
    wine: {
        version: "wine31"
    },
    emulator: {
        cpu: "",
        video: {
            bpp: 32,
            frameSkip: 0,
            resolution: "800x600"
        },
        sound: true,
        showDebugConsole: false
    },
    vdisks: []
}

/*
VDisks specification:
[
    {
        "letter": "a"
        "type": "zip"|"cdrom"|"local",
        "location": ""
    }
]
*/

/**
 * Enumerates all available drive letters based on the current configuration.
 */
function enumerateAvailableLetters(config) {
    const availableLetters = [];
    const vdiskLetters = config.vdisks.map(x=>x.letter.toUpperCase());

    for(let x = 65; x < 91; x++) {
        const letter = String.fromCharCode(x);
        
        if(RESERVED_LETTERS.includes(letter))
            continue;

        if(vdiskLetters.includes(letter))
            continue;

        availableLetters.push(letter);
    }

    return availableLetters;
}

/**
 * Reloads the virtual disks list.
 */
function reloadvDisks(cfg, vdisksLbox, tab) {
    const removeButton = tab.querySelector("button.remove");
    let processed = 0;

    vdisksLbox.clear();

    for(let vdisk of cfg.vdisks) {
        if((vdisk.letter == null) || (vdisk.type == null) || (vdisk.location == null))
            continue;

        const vl = `(${vdisk.letter.toUpperCase()}: [${vdisk.type.toUpperCase()}]) ${vdisk.location}`;
        vdisksLbox.addItem(vl, new String(cfg.vdisks.indexOf(vdisk)));
        processed++;
    }

    if(processed > 0) {
        vdisksLbox.selectItem("0");
        removeButton.disabled = false;
    }
    else
        removeButton.disabled = true;
}

class BoxedWineCfgApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * Application entry point.
     */
    async main(argv) {
        await super.main(argv);
        const style = await include(`C:/local/bwine/res/settings.css`);

        // Setup defaults if they do not exist
        if(!(await FS.exists("c:/user/appdata/bWINE")))
            await FS.mkdir("c:/user/appdata/bWINE");

        if(!(await FS.exists("c:/user/appdata/bWINE/ToWine")))
            await FS.mkdir("c:/user/appdata/bWINE/ToWine");

        // Read config and create it if it doesnt exist.
        if(await FS.exists("c:/user/appdata/bWINE/config.json")) {
            this.config = {
                ...DEFAULT_CONFIG,
                ...JSON.parse(await FS.readstr("c:/user/appdata/bWINE/config.json"))
            }
        } else {
            this.config = { ... DEFAULT_CONFIG };
            await FS.writestr("c:/user/appdata/bWINE/config.json", JSON.stringify(this.config, null, 4));
        }

        // Setup UI
        const mainwnd = this.createWindow({
            title: "bWINE Settings",
            initialWidth: 370,
            initialHeight: 443,
            resizable: false,
            controlBoxStyle: "WS_CBX_CLOSE",
            bodyClass: "bwine-settings-app",
            icon: await Theme.getIconUrl("c:/local/bwine/res/icon.png"),
            body: `<style>${style}</style>
            <div class="tabc"></div>
            <div class="buttons">
                <button class="w96-button apply">Apply</button>
                <button class="w96-button cancel">Cancel</button>
                <button class="w96-button ok">OK</button>
            </div>`,
            center: true,
            taskbar: true,
            mobResize: true
        }, true);

        const body = mainwnd.getBodyContainer();
        body.classList.add('applet-base');

        const tabControl = new TabControl();

        // Emulation options
        tabControl.openPage(tabControl.addPage('Emulation', async(e)=>{
            e.style.padding = "10px";
            e.style.boxSizing = "border-box";
            e.innerHTML = `
                <div class="icon-box">
                    <div class="icon" style="background-image: url(${await Theme.getIconUrl("c:/local/bwine/res/icon.png")});"></div>
                    <div class="text">
                        You may change the emulation settings below.<br>
                        <br>
                        Please note that incorrect values will cause bWINE to not boot.
                    </div>
                </div>
                <div class="grpbx1"></div>
                <div class="grpbx2"></div>
                <div class="grpbx3"></div>
            `;

            // Setup box 1

            const grpbx1 = new GroupBox({
                title: "Processor (CPU)",
                body: ``
            });

            const gE1 = grpbx1.getElement().querySelector('.content');

            gE1.appendChild(new RadioBox([
                {
                    label: "Automatic",
                    onselect: ()=>this.config.emulator.cpu = "",
                    selected: this.config.emulator.cpu == ""
                },
                {
                    label: "Pentium II",
                    onselect: ()=>this.config.emulator.cpu = "p2",
                    selected: this.config.emulator.cpu == "p2"
                },
                {
                    label: "Pentium III",
                    onselect: ()=>this.config.emulator.cpu = "p3",
                    selected: this.config.emulator.cpu == "p3"
                }
            ]).getElement());

            e.querySelector(".grpbx1").replaceWith(grpbx1.getElement());

            // Setup box 2

            const grpbx2 = new GroupBox({
                title: "Video Settings",
                body: `<div class="field bpp">
                    <span class="label">Bits-per-pixel (BPP)</span>
                    <select class="w96-textbox value">
                        ${VALID_BPP.map(x=>`<option value="${x}"${(this.config.emulator.video.bpp == x) ? 'selected' : ''}>${x}</option>`).join('')}
                    </select>
                </div>
                
                <div class="field frameskip">
                    <span class="label">Frameskip</span>
                    <input class="w96-textbox value" value="${this.config.emulator.video.frameSkip}">
                </div>
                
                <div class="field resolution">
                    <span class="label">Resolution</span>
                    <input class="w96-textbox value" value="${this.config.emulator.video.resolution}">
                </div>`
            });

            const gE2 = grpbx2.getElement().querySelector('.content');
            /** @type {HTMLSelectElement} */
            const bppFieldValue = gE2.querySelector(".field.bpp>.value");

            bppFieldValue.addEventListener('change', (e)=>{
                const bpp = parseInt(bppFieldValue.options[bppFieldValue.selectedIndex].value);
                this.config.emulator.video.bpp = bpp;
            });

            const frameSkipFieldValue = gE2.querySelector(".field.frameskip>.value");

            frameSkipFieldValue.addEventListener('change', (e)=>{
                const frameSkip = parseInt(frameSkipFieldValue.value);
                
                if(frameSkip == NaN) {
                    this.config.emulator.video.frameSkip = 0;
                    frameSkipFieldValue.value = 0;
                }
                else
                    this.config.emulator.video.frameSkip = frameSkip;
            });

            const resolutionFieldValue = gE2.querySelector(".field.resolution>.value");

            resolutionFieldValue.addEventListener('change', (e)=>{
                this.config.emulator.video.resolution = resolutionFieldValue.value;
            });

            e.querySelector(".grpbx2").replaceWith(grpbx2.getElement());

            // Setup box 3
            const grpbx3 = new GroupBox({
                title: "Other",
                body: ``
            });

            const gE3 = grpbx3.getElement().querySelector('.content');

            gE3.appendChild(new CheckBox({
                label: "Enable Sound",
                checked: this.config.emulator.sound,
                onchange: (e)=>this.config.emulator.sound = e.checked,
                displayAsBlock: true
            }).getElement());

            gE3.appendChild(new CheckBox({
                label: "Show Debug Console",
                checked: this.config.emulator.showDebugConsole,
                onchange: (e)=>this.config.emulator.showDebugConsole = e.checked,
                displayAsBlock: true
            }).getElement());

            e.querySelector(".grpbx3").replaceWith(grpbx3.getElement());
        }));

        // Filesystem options
        tabControl.addPage('File System', async(e)=>{
            e.style.padding = "10px";
            e.style.boxSizing = "border-box";
            e.innerHTML = `
                <div class="icon-box">
                    <div class="icon" style="background-image: url(${await Theme.getIconUrl("devices/hdd")});"></div>
                    <div class="text">
                        This section allows you to manage virtual drives.<br><br>Please note that system drives are not listed here.
                    </div>
                </div>
                <div class="vdbox">
                    <div class="listbox"></div>
                    <div class="controls">
                        <button class="w96-button add">Add</button>
                        <button class="w96-button remove" disabled>Remove</button>
                    </div>
                </div>
            `;

            // Iterate through VDisks
            const vdisksLbox = new ListBox();
            reloadvDisks(this.config, vdisksLbox, e);
            e.querySelector(".listbox").replaceWith(vdisksLbox.getElement());

            // Set events
            const addButton = e.querySelector(".w96-button.add");
            addButton.addEventListener('click', async ()=>{
                addButton.disabled = true;
                const availableLetters = enumerateAvailableLetters(this.config);

                const dlgWindow = this.createWindow({
                    title: "Create New Virtual Drive",
                    initialHeight: 210,
                    initialWidth: 320,
                    body: `
                        <div class="content">
                            <div class="field type">
                                <div class="title">Type</div>
                                <select class="w96-textbox">
                                    <option value="local">Local Mapping</option>
                                </select>
                            </div>

                            <div class="field letter">
                                <div class="title">Drive Letter</div>
                                <select class="w96-textbox">
                                    ${availableLetters.map(x=>`<option value="${x}">${x}:</option>`).join('')}
                                </select>
                            </div>

                            <div class="field path">
                                <div class="title">Path</div>
                                <input class="w96-textbox" type="text" placeholder="C:/example">
                            </div>
                        </div>
                        <div class="buttons">
                            <button class="w96-button cancel">Cancel</button>
                            <button class="w96-button ok">OK</button>
                        </div>
                    `,
                    bodyClass: "create-nvd-dlg",
                    taskbar: false,
                    controlBoxStyle: "WS_CBX_CLOSE",
                    resizable: false,
                    center: true
                }, false);

                const dlgBody = dlgWindow.getBodyContainer();
                
                dlgBody.querySelector(".cancel").addEventListener('click', ()=>dlgWindow.close());

                dlgBody.querySelector(".ok").addEventListener('click', async ()=>{
                    const letter = availableLetters[dlgBody.querySelector(".letter>select").selectedIndex];
                    const path = dlgBody.querySelector(".path>input").value;
                    const type = ["local"][dlgBody.querySelector(".type>select").selectedIndex];

                    if((!await FS.exists(path)) || (await FS.isFile(path))) {
                        DialogCreator.create({
                            icon: "error",
                            body: "The specified directory does not exist.",
                            title: "Error"
                        });

                        return;
                    }

                    this.config.vdisks.push({
                        letter,
                        location: path,
                        type
                    });

                    reloadvDisks(this.config, vdisksLbox, e);

                    dlgWindow.close();
                });

                dlgWindow.show();

                await dlgWindow.wait();
                addButton.disabled = false;
            });

            e.querySelector(".w96-button.remove").addEventListener('click', ()=>{
                if(vdisksLbox.selectedItem) {
                    this.config.vdisks.splice(parseInt(vdisksLbox.selectedItem), 1);
                    reloadvDisks(this.config, vdisksLbox, e);
                }
            });
        });

        // Version options
        tabControl.addPage('Version', async(e)=>{
            e.style.padding = "10px";
            e.style.boxSizing = "border-box";
            e.innerHTML = `
                <div class="icon-box">
                    <div class="icon" style="background-image: url(${await Theme.getIconUrl("c:/local/bwine/res/icon.png")});"></div>
                    <div class="text">
                        Here you can select a Wine version appropriate for your use case.<br>
                        <br>
                        It is advised to stick with the default Wine version if you are unsure.
                    </div>
                </div>
                <button style="float: right" class="w96-button">Open Version Manager</button>
            `;

            e.querySelector('button').addEventListener('click', ()=>{
                w96.sys.execCmd("bwine", ["--manage-versions"]);
            });
        });

        body.querySelector(".tabc").replaceWith(tabControl.getElement());
        body.querySelector("button.apply").addEventListener('click', ()=>this.applySettings());
        body.querySelector("button.cancel").addEventListener('click', ()=>mainwnd.close());
        body.querySelector("button.ok").addEventListener('click', ()=>{
            this.applySettings();
            mainwnd.close();
        });

        mainwnd.show();
    }

    /**
     * Applies the current settings.
     */
    applySettings() {
        FS.writestr("c:/user/appdata/bWINE/config.json", JSON.stringify(this.config, null, 4));
    }
}