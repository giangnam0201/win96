/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

let smConfig = { ...START_MENU_CONFIG }; // TODO allow this to be changed
let isStartOpen = false;

/**
 * Opens the start menu.
 */
function startOpen() {
    if(isStartOpen)
        return;

    const startMenuEl = document.createElement("div");
    startMenuEl.classList.add('shell36-start-menu', 'oc-event-exempt');
    startMenuEl.style.bottom = `${Theme.uiVars.taskbarHeight - 3}px`;
    
    // Create sidebar
    const sidebar = document.createElement('div');
    sidebar.classList.add('sidebar');
    sidebar.textContent = smConfig.text;
    startMenuEl.appendChild(sidebar);

    // Create item container
    const itemContainer = document.createElement('div');
    itemContainer.classList.add("item-container");

    // Setup the items
    for(let i of smConfig.items) {
        if(i.type == "separator") {
            const separatorEl = document.createElement('div');
            separatorEl.classList.add("w96-ui-inset-separator");
            itemContainer.appendChild(separatorEl);
            continue;
        }

        const itemEl = document.createElement('div');
        itemEl.classList.add("item");

        // Create icon
        const iconEl = document.createElement('div');
        iconEl.classList.add('icon');

        Theme.getIconUrl(i.icon, '24x24').then((v)=>{
            if(iconEl)
                iconEl.style.backgroundImage = `url(${v})`;
        });

        itemEl.appendChild(iconEl);

        // Create text
        const textEl = document.createElement('div');
        textEl.classList.add('text');
        textEl.textContent = i.name;
        itemEl.appendChild(textEl);

        // Assign events
        if(i.command) {
            itemEl.addEventListener('click', ()=>{
                startClose();
    
                const a = ArgParser.parse(i.command);
                const c = a[0];
                a.shift();
    
                execCmd(c, a);
            });
        }
        
        // Command and dir menu are not mutually exclusive.
        if(i.type == "dir-menu") {
            itemEl.classList.add('sub');
            
            itemEl.addEventListener('mouseenter', async(e)=>{
                if(itemEl.classList.contains('active'))
                    return; // Do not regen menu if its already active

                // Deselect other items
                document.querySelectorAll(".shell36-start-menu .active").forEach((v)=>v.classList.remove('active'));

                // Select this one
                itemEl.classList.add('active');

                // Destroy other menus if they exist
                document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());

                // Spawn the menu
                const bounds = itemEl.getBoundingClientRect();
                let items;

                if(i.path != null)
                    items = await folder2ContextMenu(i.path, (i.dirEntryIcon != null) ? i.dirEntryIcon : undefined);
                else
                    items = i.items || [];
                
                // There is a chance the user closed the start menu
                if(!isStartOpen)
                    return;

                // Destroy other menus if they exist, which can be caused due to an asynchronous wait
                document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());

                const ctxm = new ContextMenu(items);
                ctxm.renderMenu(bounds.right, bounds.top);
            });
        } else  {
            // For normal items
            itemEl.addEventListener('mouseenter', async(e)=>{
                // Deselect other items
                document.querySelectorAll(".shell36-start-menu .active").forEach((v)=>v.classList.remove('active'));

                // Destroy other menus if they exist
                document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());
            });
        }

        // Add the item to the start menu.
        itemContainer.appendChild(itemEl);
    }

    // Ensure any roots from any app bars are deselected
    document.querySelectorAll(".w96-menubar>.root-item.selected").forEach((v)=>v.classList.remove('selected'));

    // Append the start menu and show it as a result
    startMenuEl.appendChild(itemContainer);
    gfxEl.appendChild(startMenuEl);
    isStartOpen = true;

    // Emit start open event
    w96.evt.shell.emit('start-opened', startMenuEl);
}

/**
 * Closes the start menu.
 */
function startClose() {
    const startMenu = document.querySelector(".shell36-start-menu");

    if(startMenu)
        startMenu.remove();

    // Check for start button state
    const sbutton = document.querySelector(".start_button.sb-active");
    
    if(sbutton)
        sbutton.classList.remove("sb-active");

    isStartOpen = false;

    // Emit start close event
    w96.evt.shell.emit('start-closed');
}

/**
 * Toggles the start menu.
 */
function startToggle() {
    if(startIsOpen())
        startClose();
    else
        startOpen();
}

/**
 * Returns whether the start menu is open.
 */
function startIsOpen() {
    return isStartOpen;
}

/**
 * Shell start menu.
 */
const StartMenu = {
    open: startOpen,
    close: startClose,
    toggle: startToggle,
    isOpen: startIsOpen
}