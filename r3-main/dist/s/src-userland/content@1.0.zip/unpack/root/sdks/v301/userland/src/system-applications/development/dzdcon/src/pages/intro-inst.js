/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "intro-inst",
    content: `
        <div class="container">
            <div>
                This installation is currently utilizing Dazzle DevConnector.<br><br>
                What would you like to do?<br><br>
            </div>
            <div class="icon-opt-select">
                <div class="option full">
                    <button class="w96-button btn reconfig"></button>
                    <div class="text">
                        <span class="title bold-noaa">Reconfigure DevConnector</span>
                        <span class="explanation">Rerun the wizard for DevConnector.</span>
                    </div>
                </div>

                <div class="option lite">
                    <button class="w96-button btn start-service"></button>
                    <div class="text">
                        <span class="title bold-noaa">Start Service</span>
                        <span class="explanation">Manually start the DevConnector service.</span>
                    </div>
                </div>
            </div>
        </div>
    `,
    onrender: async (app, contentEl)=>{
        const checkSvcRunning = ()=> {
            if(wmem.dz) {
                DialogCreator.create({
                    body: "The Dazzle DevConnector service is still running!<br><br>Please shut it down, then run this setup program again.",
                    title: "Dazzle DevConnector",
                    icon: "error"
                });

                return true;
            }

            return false;
        }

        // Called upon rendering
        const serviceBtn = contentEl.querySelector(".btn.start-service");
        serviceBtn.style.backgroundImage = `url(${await Theme.getIconUrl("mime/executable", '32x32')})`;
        serviceBtn.addEventListener('click', async ()=>{
            execCmd("dzdsvc", []);
        });

        // Reconfig btn
        const reconfigBtn = contentEl.querySelector(".btn.reconfig");
        reconfigBtn.style.backgroundImage = `url(/system/resource/app/dzdcon/dz32.png)`;
        reconfigBtn.addEventListener('click', async ()=>{
            if(checkSvcRunning())
                return;

            app.renderPage("intro");
        });
    },
    buttons: [
        {
            cls: "next",
            enabled: false,
            onclick: (app)=> {}
        },
        {
            cls: "back",
            enabled: false
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});