/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { util, sys } = w96;

class MigrationApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * The main entry point
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        await super.main(argv);

        // CHECK FOR V2 ...
        if (localStorage['social_mv.lock'] !== '1') return;
        if (!await FS.exists('C:/system/boot/apps')) return;
        // then ...

        // First get a terminal to show outputs.
        let consoleHost = await util.requestTerminal("v3 Setup Tasks", null, true);
        let term = consoleHost.terminal;

        // 0. Show a preparing message before ifsck is run
        term.writeln("Windows 96 is upgrading your system to v3 ...");

        await util.wait(1400);
        term.writeln("");

        // 1. Run ifsck to fix fs
        await sys.execCmd("ifsck", ["C:/"], { term, cwd: 'C:/' });

        let pathCount = 0;
        let oldWindir = null;
        while (!oldWindir) {
            let pathName = `C:/windows.old.v2${pathCount === 0 ? "" : "-" + pathCount.toString().padStart(3, "0")}`;
            if (!await FS.exists(pathName)) {
                oldWindir = pathName.substring(3);
            }else pathCount++;
        }

        // 2. Migrate the system.
        await util.wait(1400);
        term.write("Your files are being migrated to " + oldWindir + " ...");

        // This is undocumented behavior. It is the internal code of mvdir, modified slightly.
        // This is ok, however, since this runs in a known environment (The indexxedbfs)

        let rootFS = FS.get('C:');
        let fileCount = 0;

        rootFS._pushFtableRecord('/' + oldWindir, 0, 1, false);

        const fsysNodes = Object.keys(rootFS._fileTable);

        await fsysNodes.aForEach(async (path)=>{
            console.log(path);

            // Sanity checks
            if(rootFS._fileTable[path] == undefined) return;
            if ([
              '/',
              '/.gitkeep',
              '/system/local/bin/oobe'
            ].includes(path)) return;
            if (path.startsWith("/windows.old")) return;

            if (path.startsWith("/")) {
                const targetPath = '/' + oldWindir + path;

                if(await rootFS.isFile(path)) {
                    rootFS._pushFtableRecord(targetPath, rootFS._fileTable[path].length, 0, false);
                    rootFS._fileTable[targetPath].recordId = rootFS._fileTable[path].recordId;
                } else
                rootFS._pushFtableRecord(targetPath, 0, 1, false);
                rootFS._fileTable[path] = undefined;

                fileCount++;
                return;
            }
        });


        rootFS._pushFtableRecord('/system', 0, 1, false);
        rootFS._pushFtableRecord('/system/local', 0, 1, false);
        rootFS._pushFtableRecord('/system/local/bin', 0, 1, false);

        rootFS._pushFtableRecord('/user', 0, 1, false);
        rootFS._pushFtableRecord('/user/desktop', 0, 1, false);

        rootFS.updateWatch(oldWindir);
        await rootFS._sync();

        await FS.writestr(`C:/${oldWindir}/.meta`, JSON.stringify({
            description: 'A backup of your v2 data when you upgraded to v3 on ' + (new Date()).toString()
        }, null, 4));

        await FS.writestr("C:/user/desktop/Old v2 Installation.link", JSON.stringify({
            icon: "W:/system/resource/icons/win96/32x32/devices/computer-alt.png",
            action: `C:/${oldWindir}`
        }));

        term.writeln(` ${fileCount} files moved\n`);
        term.writeln(`Migration finished.`);

        // 3. Pause
        await util.wait(1400);
        //await term.pause();

        // 4. Quit terminal and exit the app
        consoleHost.stopHost();
        this.terminate();
    }
}