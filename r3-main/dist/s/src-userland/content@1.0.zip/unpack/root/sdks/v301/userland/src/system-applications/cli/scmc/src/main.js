/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { sysConf: SCM } = w96;
const { argParser } = w96.util;

// Terminal reference
let term = this.boxedEnv.term;

/**
 * Dies.
 * @param {String} msg Message.
 * @param {Number} code Exit code.
 */
function die(msg, code = 1) {
    term.println(`\u001b[31m${msg}\u001b[0m`);
    return code;
}

// Command registry
let commandRegistry = [
    { name: "dump", exec: cmd_Dump, usage: " <path> [-o <output_file>] - Dump SCM object." },
    { name: "import", exec: cmd_Import, usage: " <path> - Import dumped file." },
    { name: "ls", exec: cmd_LS, usage: " [path] [-s <sort_mode R/K/V (def: RKV)>] [-t <type filter>] - Lists the contents of the specified path." },
    { name: "shell", exec: cmd_Shell, usage: " - Launch interactive shell." },
    { name: "status", exec: cmd_Status, usage: " - View current system configuration status." }
]

// Commands to import
$$Include("./commands/shell.js")
$$Include("./commands/import.js")
$$Include("./commands/ls.js")
$$Include("./commands/dump.js")
$$Include("./commands/status.js")

// SCMC app
class SCMCApp extends WApplication {
    constructor() {
        super();
    }

    /**
     * Main entry point.
     * @param {String[]} argv The arguments to pass.
     */
    async main(argv) {
        await super.main(argv);

        if(!term)
            return;

        argv.shift();

        // Display help
        if((argv[0] == null) || (argv.includes("--help"))) {
            term.writeln(`\u001b[36mSystem Configuration Manager (SCM) Command-Line Interface.
Copyright (C) SYS36.NET 2023.\u001b[0m

Usage: scmc <command> [arguments]

Commands:
    ${commandRegistry.map(x => `${x.name}${x.usage}`).join("\n    ")}\n`);

            return 0;
        }

        const cmd = commandRegistry.find(x => x.name == argv[0]);

        if(!cmd) {
            term.println("Error: command not found.");
            return 1;
        }
        else
            return await cmd.exec(this, argv) ?? 0;
    }
}