/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme } = w96.ui;

class PumkinGameApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow();
    }

    async _createWindow() {
        var params = new WindowParams();
        params.title = "Pumkin World";
        params.initialWidth = 485;
        params.initialHeight = 400;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<iframe src="/system/apps/pumkin"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('eyeframe-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/pumkin", '16x16'));

        const appFrame = mainwnd.wndObject.querySelector("iframe");

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }
}