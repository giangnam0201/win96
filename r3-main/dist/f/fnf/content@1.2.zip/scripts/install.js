// Ran upon package installation
