/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

app program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

app program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with app program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates the control tab.
 * @param {TabControl} tabc Tab controller.
 * @param {X11Application} app The app instance.
 */
function createControlTab(tabc, app) {
    tabc.openPage(tabc.addPage("Control", (e) => {
        e.innerHTML = `<div class="pg-content">
            <div class="explanation">
                Welcome to the Windows 96 X11/Xpra client.<br><br>
                Using app client, you can connect to a remote Xpra instance and run your X11 apps here.
                <br><br>
            </div>

            <div class="connect">
                <div class="connectbox"></div>
            </div>

            <div class="controls">
                <div class="grpbox"></div>
            </div>
        </div>`;

        // Add connect box
        const connBox = new GroupBox({
            title: "Connect to Host",
            body: `
                <div class="addr-field">
                    <div class="name">Address:</div>
                    <input type="text" class="w96-textbox addr">
                    <div class="sep">:</div>
                    <input type="text" class="w96-textbox port">
                </div>

                <button class="w96-button connect">Connect</button>
                <button class="w96-button shortcut">Make Shortcut...</button>
            `
        });

        const connBoxEl = connBox.getElement();
        e.querySelector(".connectbox").replaceWith(connBoxEl);

        // Add connect events
        connBoxEl.querySelector(".connect").addEventListener('click', ()=>{
            const address = connBoxEl.querySelector("input.addr").value;
            const port = parseInt(connBoxEl.querySelector("input.port").value);

            if(!app.uiValidateAddress(address, port))
                return;

            // Connect to client
            app.createXpraSession(address, port);
        });

        // Shortcut button
        connBoxEl.querySelector(".shortcut").addEventListener('click', ()=>{
            const address = connBoxEl.querySelector("input.addr").value;
            const port = parseInt(connBoxEl.querySelector("input.port").value);

            if ((Number.isNaN(port)) || (port < 0) || (port > 65535))
                return;
            else if((address == ""))
                return;

            // Create shortcut object
            const obj = {
                icon: "apps/x11",
                action: `x11 connect ${address}:${port}`
            };

            // Write file
            FS.writestr(`C:/user/desktop/Client-${address}.link`, JSON.stringify(obj));

            alert(`A shortcut for "${address}:${port}" has been placed on the desktop`, {
                title: "X11/Xpra Client",
                icon: "info"
            });
        });

        // Add controller box
        const ctrlBox = new GroupBox({
            title: "Control",
            body: `
                <div class="controls">
                    <div class="item">
                        <button class="w96-button discon-all">Disconnect All</button>
                        <div class="descript">
                            Disconnects all currently connected clients.
                        </div>
                    </div>

                    <div class="item">
                        <button class="w96-button shutdown">Shut Down</button>
                        <div class="descript">
                            Shuts down all X11 clients and closes app controller.
                        </div>
                    </div>
                </div>
            `
        });

        const ctrlBoxEl = ctrlBox.getElement();

        ctrlBoxEl.querySelector(".discon-all").addEventListener('click', ()=>app.disconnectAll());
        ctrlBoxEl.querySelector(".shutdown").addEventListener('click', ()=>app.appWindow.close());

        e.querySelector(".grpbox").replaceWith(ctrlBoxEl);
    }));
}