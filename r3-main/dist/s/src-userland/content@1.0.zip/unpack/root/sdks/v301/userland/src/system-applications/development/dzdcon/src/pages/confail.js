/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "confail",
    content: `
        <div class="container">
            <div>
                Connection test failed!<br><br>
                If this error keeps persisting, you can try the following:<br>
                <ul>
                    <li>Check if the address was entered correctly.</li>
                    <br>
                    <li>Check if the origin specified in the DevConnector config file matches the origin of the current Windows 96 instance.</li>
                </ul>
                <br>Press "Back" to go back to the address input step.
            </div>
        </div>
    `,
    onrender: (app, contentEl)=>{},
    buttons: [
        {
            cls: "next",
            enabled: false,
            onclick: (app)=> {}
        },
        {
            cls: "back",
            enabled: true,
            onclick: (app)=> app.renderPage("address")
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});