/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { mutex } = w96;
const { loadlibAsync } = w96.sys.loader;
const { inspect } = w96.util;

// Easy ref
const term = this.boxedEnv.term;

if(!term)
    return;

const X11C_VER = "1.0.0";
const XPRA_KNOWN_VER = "4.4.5";

// Location of xpra files
const X11_PREFIX = '/system/libraries/extern/xpra/';

// Libraries we must load
const X11_LIBS = [
    'lib/brotli_decode',
    'lib/detect-zoom',
    'lib/jquery.ba-throttle-debounce',
    'lib/lz4',
    'Utilities',
    'Keycodes',
    'Protocol',
    'Window',
    'Constants',
    'MediaSourceUtil',
    'OffscreenDecodeWorkerHelper',
    'Client'
];

/**
 * The template for a terminal application.
 */
class X11CApplication extends WApplication {
    constructor() {
        super();
        this.mutex = null;
        this._waitCb = null;
        this.master_close = false;
    }

    /**
     * Shows help.
     * @param {string[]} argv Program arguments.
     */
    showHelp(argv) {
        if(argv[2] == null) {
            term.println(`Usage: x11c <command> [arguments]
Commands:
    connect <address:port> - Connects to the specified endpoint (e.g. 192.168.1.100:10000).
    help [command]         - Views this help page.
    version                - Gets the X11c version.\n`);
                return;
        }
        
        // Help switcher
        switch(argv[2]) {
            case "connect":
                term.println(`Command help for \`connect <address:port>\`:
Description: Connects to an Xpra session.

Flags:
    --allow-sharing - Allow session sharing.

Examples:
    x11c connect 192.168.1.100:10000
    x11c connect 10.10.242.153:9600 --allow-sharing\n`);
                break;
            default:
                term.printError(`No additional help available for command \`${argv[2]}\`.`);
                break;
        }
    }

    /**
     * Load the required xpra libraries.
     */
    async loadLibs() {
        if(typeof XpraClient !== 'undefined')
            return; // We do not need to load libraries

        // Show some progress
        term.println("Loading Xpra libraries...");

        for (let lib of X11_LIBS) {
            term.println(`LoadLib: ${lib}`);
            await loadlibAsync(X11_PREFIX + lib + '.js');
        }

        term.println("Loading complete!");
    }

    /**
     * Connects to the specified address.
     * @param {string} argv Program arguments.
     */
    async connect(argv) {
        const address = argv[2];

        if((address == null) || (address.trim() == ""))
            return void term.printError("Error: no address specified.");

        const epSplit = address.split(':');
        const host = epSplit[0];

        if(epSplit.length !== 2)
            return void term.printError("Error: invalid address specified");
        else if(host == "")
            return void term.printError("Error: invalid host specified.");
        
        // Check port
        const port = epSplit[1];

        if ((Number.isNaN(port)) || (port < 0) || (port > 65535))
            return void term.printError("Error: invalid port specified.");

        // Check mutex
        if(mutex.find(`xpra::${address}`) != null)
            return void term.printError("Error: connection is already active elsewhere!");

        // Load libs if needed
        await this.loadLibs();

        // Start connection
        term.println(`Contacting ${address}...`);
        
        // Create client
        this.mutex = mutex.create(`xpra::${address}`);
        const client = new XpraClient("maingfx");
        client.host = host;
        client.port = `${port}`;
        client.sharing = argv.includes("--allow-sharing");
        client.init();

        // Hook this
        client.callback_close = (msg) => {
            if(this.master_close) return;

            term.printError(msg);
            return this.terminate();
        }

        // Wait for connection
        await new Promise((resolve, reject) => {
            let timeoutNeeded = true;

            client.on_connect = () =>{
                timeoutNeeded = false;
                resolve();
            };

            // Connect
            client.connect();

            // Set the timeout
            setTimeout(()=>{
                if(timeoutNeeded)
                    reject("Connection timeout.");
            }, 10000);
        });

        term.println("Connection established.");

        // Make local reference
        this.client = client;

        // Start cleanup process when waitcb called.
        let running = true;
        
        while(running) {
            let str = await term.prompt(`x11c> `, true);
            
            const moncmd = str.split(' ');

            switch(moncmd[0]) {
                default:
                    term.println("error: unrecognized command.");
                    break;
                case "dump":
                    term.println(inspect(client, {depth: 1, colors: true}));
                    break;
                case "exit":
                case "quit":
                    term.println("Closing connection...");
                    this.master_close = true;
                    running = false;
                    this.terminate();
                    break;
            }
        }
    }

    /**
     * Program entry point.
     * @param {string[]} argv Arguments.
     */
    async main(argv) {
        await super.main(argv);

        term.println("\u001b[36mX11 Xpra Console Client.");
        term.println("Copyright (C) Windows96.net 2023.\u001b[0m\n");
        
        if(argv[1] == null) {
            term.printError("No command specified. Run x11c with `help` to view command help.");
            return;
        }

        // Process commands
        switch(argv[1]) {
            default:
                term.printError("Command not recognized.");
                break;
            case "connect":
                await this.connect(argv);
                break;
            case "help":
                this.showHelp(argv);
                break;
            case "version":
                term.println(`X11c version: ${X11C_VER}\nXpra Known Good version: ${XPRA_KNOWN_VER}\n`);
                break;
        }
    }

    /**
     * Free resources.
     */
    async ontermination() {
        await super.ontermination();

        if(this.mutex)
            mutex.release(this.mutex);

        this.client.reconnect = false;
        this.client.close();
        this.client = null;
        mutex.release(this.mutex);
    }
}