/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { DialogCreator, MenuBar, Theme, OpenFileDialog } = w96.ui;

class MDViewApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(argv[1] == null) {
            new OpenFileDialog("c:/", ["md", "MD"], (fn)=>{
                if(!fn) {
                    this.terminate();
                    return;
                }
                this._createWindow(fn);
            }).show();
            return;
        }

        this._createWindow(argv[1]);
    }

    async _createWindow(fn) {
        const mainwnd = this.createWindow({
            initialWidth: 470,
            initialHeight: 400,
            title: FSUtil.fname(fn) + " - MD Viewer",
            taskbar: true,
            body: `<div class="appbar"></div>
            <div class="mdview-container"></div>`,
            icon: await Theme.getIconUrl("apps/mdview", '16x16')
        }, true);

        const body = mainwnd.getBodyContainer();

        const appBar = new MenuBar();

        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        body.querySelector(".appbar").replaceWith(appBar.getMenuDiv());

        const converter = new showdown.Converter();
        const mdContainer = body.querySelector(".mdview-container");

        try {
            const text = await FS.readstr(fn);
            mdContainer.innerHTML = converter.makeHtml(text);
        } catch(e) {
            mdContainer.textContent = '<Unable to load document>';

            DialogCreator.create({
                body: "Unable to load file.",
                icon: "Error",
                title: "MD Viewer"
            });
        }

        mainwnd.show();
    }
}