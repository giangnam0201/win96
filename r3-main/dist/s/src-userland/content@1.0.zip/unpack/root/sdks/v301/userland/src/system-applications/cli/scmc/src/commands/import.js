/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Import command.
 * @param {SCMCApp} app App instance.
 * @param {String[]} argv Program arguments.
 */
async function cmd_Import(app, argv) {
    argv.shift();

    // If no arg specified.
    if(!argv[0])
        return die("Error: no path specified.");

    const path = FSUtil.resolvePath(current.cwd, argv[0]);

    if(!await FS.exists(path))
        return die("Error: file does not exist.");

    const dumpObj = JSON.parse(await FS.readstr(path));

    if((!dumpObj.scmRestoreInfo) || (!dumpObj.scmRestoreInfo.path))
        return die("Error: not a valid SCM dump.");

    // Dump
    term.println("Restoring...");
    await SCM.setAndSync(dumpObj.scmRestoreInfo.path, dumpObj.dumpData);
    term.println("Restoration complete!");
}