/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Shows the internet options window.
 * @param {InternetEApplication} app The app instance.
 */
function showInternetOptionsWnd(app) {
    const wnd = app.createWindow({
        title: "Internet Options",
        bodyClass: "applet-base",
        body: `<div class="tabc"></div>
        <div class="buttons">
            <button class="w96-button apply" disabled>Apply</button>
            <button class="w96-button cancel">Cancel</button>
            <button class="w96-button ok">OK</button>
        </div>`,
        icon: null,
        initialWidth: 406,
        initialHeight: 452,
        controlBoxStyle: "WS_CBX_CLOSE",
        resizable: false,
        taskbar: false
    }, false);

    // Config state
    const configState = {
        ...CONFIG,
        ...app.config
    }

    // Setup window
    const body = wnd.getBodyContainer();
    body.classList.add("wnd-ie-inet-options");

    const tabControl = new TabControl();

    tabControl.openPage(tabControl.addPage("General", async(e)=>{
        e.style.padding = "10px";
        e.style.boxSizing = "border-box";
        e.innerHTML = `<div class="grpbx1"></div>
        <div class="grpbx2"></div>`;

        // Homepage group box
        const grpbx1 = new GroupBox({
            title: "Home page",
            body: `<div class="icon-box hp">
                        <div class="icon" style="background-image: url(${await Theme.getIconUrl("misc/homepage")});"></div>
                        <div class="text">
                            <div>You can change which page to use for your home page.</div>
                            <div class="addr-box"><span>Address: </span> <input type="text" class="w96-textbox"></div>

                            <div class="ic-buttons">
                                <button class="w96-button hp-current">Use Current</button>
                                <button class="w96-button hp-default">Use Default</button>
                                <button class="w96-button hp-blank">Use Blank</button>
                            </div>
                        </div>
                    </div>`
        });

        const gboxEl1 = grpbx1.getElement();

        // Setup home page buttons
        const hpInput = gboxEl1.querySelector(".hp input");
        gboxEl1.querySelector(".hp-current").addEventListener('click', ()=>{
            hpInput.value = app.lastUrl;
            configState.homepage = hpInput.value;
        });
        
        gboxEl1.querySelector(".hp-default").addEventListener('click', ()=>{
            hpInput.value = CONFIG.homepage;
            configState.homepage = hpInput.value;
        });

        gboxEl1.querySelector(".hp-blank").addEventListener('click', ()=>{
            hpInput.value = "about:blank";
            configState.homepage = hpInput.value;
        });

        hpInput.value = configState.homepage;

        // Setup history buttons
        const grpbx2 = new GroupBox({
            title: "History",
            body: `<div class="icon-box hist">
                <div class="icon" style="background-image: url(${await Theme.getIconUrl("misc/history")});"></div>
                <div class="text">
                    <div>InternetE keeps track of which sites you have visited.<br><br>
                    To clear this history, click the button below.</div>

                    <div class="ic-buttons">
                        <button class="w96-button hist-clean">Clear History</button>
                    </div>
                </div>
            </div>`
        });

        const gboxEl2 = grpbx2.getElement();
        gboxEl2.querySelector(".hist-clean").addEventListener('click', ()=>app.clearHistory());

        // Replace all group boxes
        e.querySelector(".grpbx1").replaceWith(gboxEl1);
        e.querySelector(".grpbx2").replaceWith(gboxEl2);
    }));

    // tabControl.addPage("Advanced", (e)=>{
    //     e.style.padding = "10px";
    //     e.style.boxSizing = "border-box";
    //     e.innerHTML = `TODO`;
    // });

    body.querySelector(".tabc").replaceWith(tabControl.getElement());
    body.querySelector("button.cancel").addEventListener('click', ()=>wnd.close());
    body.querySelector("button.ok").addEventListener('click', ()=>{
        app.config = {
            ...app.config,
            ...configState
        };

        app.commitCurrentConfiguration();
        wnd.close();
    });

    wnd.show();

    return wnd;
}