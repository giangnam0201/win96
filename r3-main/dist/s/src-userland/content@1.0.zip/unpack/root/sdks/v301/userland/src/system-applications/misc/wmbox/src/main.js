/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { DialogCreator, Theme, MenuBar } = w96.ui;
const { TabControl, ListBox, GroupBox } = w96.ui.components;
const { execFile } = w96.sys;
const { escapeHtml, DomUtils } = w96.util;

const VERSION = "1.0";
const RESOURCE_ROOT = "/system/resource/app/wmbox";

const VM_DEFAULT_ICONS = [
    "/system/resource/app/wmbox/icons/generic.png",
    "/system/resource/app/wmbox/icons/linux.png",
    "/system/resource/app/wmbox/icons/windows.png"
];

const VM_SAVE_DIR = "C:/user/appdata/WMBox/VMs";

function createAttachment(name, icon) {
    const atEl = DomUtils.mkElement("div", ["attachment"]);
    atEl.innerHTML = `<div class="icon" style="background-image: url(${icon})"></div><div class="text">${escapeHtml(name)}</div>`
    return atEl;
}

class WMBoxApplication extends WApplication {
    constructor() {
        super();

        this.config = {};
        this.selectedVM = null;
    }

    /**
     * Populates the VM view.
     * @param {ListBox} listView The list view to use.
     */
    async populateVMView(listView) {
        for(let vmDir of await FS.readdir(VM_SAVE_DIR)) {
            const configPath = vmDir + "/config.wmx";

            if(!await FS.exists(configPath))
                continue;


            try {
                // Read the WMX for metadata information
                const wmx = JSON.parse(await FS.readstr(configPath));

                wmx.vmDir = vmDir;

                const listItem = listView.addItem("", configPath);
                const icon = DomUtils.mkElement("div", ["icon"]);

                if(wmx.meta.icon)
                    icon.style.backgroundImage = `url(/system/resource/app/wmbox/icons/${wmx.meta.icon}.png)`;

                const label = DomUtils.mkElement("div", ["label"]);
                label.textContent = wmx.meta.name || "<corrupted wmx meta>";

                listItem.appendChild(icon);
                listItem.appendChild(label);

                listItem.addEventListener('click', ()=>{
                    this.selectedVM = {
                        vmDir,
                        wmx,
                        configPath
                    };

                    this.populateInfoPanel(this.selectedVM);
                });
            } catch(e) {
                console.error(e);
                continue;
            }
        }
    }

    /**
     * Populates the info panel
     * @param {{
     *     wmx: {},
     *     configPath: String
     *     vmDir: String
     * }} e Arguments.
     */
    populateInfoPanel(e) {
        const wmx = e.wmx;

        // Clear the previous info panel
        const body = this.mainwnd.getBodyContainer();
        const infoPanel = body.querySelector('.vm-view>.overview');

        while(infoPanel.firstChild)
            infoPanel.removeChild(infoPanel.firstChild);

        // Create title box
        const titleBox = DomUtils.mkElement("div", ["title-box"]);

        titleBox.innerHTML = `
            <div class="icon" style="background-image: url(/system/resource/app/wmbox/icons/${escapeHtml(wmx.meta.icon)}.png)"></div><div class="title"><span class="bold-noaa">${escapeHtml(wmx.meta.name || "<corrupted VM>")}</span></div>
        `;

        infoPanel.appendChild(titleBox);

        // Create two sided panel interface
        const twoPanel = DomUtils.mkElement("div", ["ts-container"]);

        twoPanel.innerHTML = `
            <div class="p1">
                <div class="actions">
                    <button class="w96-button start">Start</button>
                    <button class="w96-button vm-settings">VM Settings</button>
                </div>
                <div class="attachments"></div>
            </div>
            <div class="p2">
                <div class="preview-container">
                    <div class="preview-box">
                        <div class="preview"></div>
                    </div>
                </div>
            </div>
        `;

        // Query VM attachments

        const attachmentsGBox = new GroupBox({
            title: "Attachments",
            body: ""
        });

        const atElement = attachmentsGBox.getElement();
        const atContents = atElement.querySelector(".content");
        atContents.classList.add('attachments-gbx');

        switch(wmx.backend) {
            case "v86": // Add default attachments
                atContents.appendChild(createAttachment("Pentium III compatible CPU", `${RESOURCE_ROOT}/icons/16x16/cpu.png`));

                if(wmx.vga) {
                    atContents.appendChild(createAttachment(`SVGA Video Card (${(wmx.vga.memory_size / 1024 / 1024).toFixed(0)} MB)`, `${RESOURCE_ROOT}/icons/16x16/expansion.png`));
                }

                for(let atch of wmx.attachments) {
                    if(atch.type == "keyboard")
                        atContents.appendChild(createAttachment("PS/2 Keyboard", `${RESOURCE_ROOT}/icons/16x16/keyboard.png`));
                    else if(atch.type == "mouse")
                        atContents.appendChild(createAttachment("PS/2 Mouse", `${RESOURCE_ROOT}/icons/16x16/mouse.png`));
                    else if(atch.type == "cdrom")
                        atContents.appendChild(createAttachment("IDE CD/DVD Drive", `${RESOURCE_ROOT}/icons/16x16/cddvd.png`));
                }

                break;
        }

        // Create attachments
        const ramSize = `${(wmx.memory_size > 1048576) ? ((wmx.memory_size / 1024 / 1024).toFixed(0) + " MB") : ((wmx.memory_size / 1024 ).toFixed(0) + " KB")} RAM`;
        atContents.appendChild(createAttachment(ramSize, `${RESOURCE_ROOT}/icons/16x16/ram.png`))

        // Assign events
        twoPanel.querySelector("button.start").addEventListener('click', ()=>{
            execFile(wmx.vmDir + "/config.wmx");
        });

        twoPanel.querySelector("button.vm-settings").addEventListener('click', ()=>{
            this.showVMSettingsWnd(wmx.vmDir);
        });

        // Append attachments panel

        twoPanel.querySelector('.attachments').replaceWith(atElement);

        infoPanel.appendChild(twoPanel);
    }

    /**
     * Shows a VM settings window.
     * @param {String} vmDir The VM directory to view settings for.
     */
    async showVMSettingsWnd(vmDir) {
        // Read the WMX file
        const wmx = JSON.parse(await FS.readstr(vmDir + "/config.wmx"));

        const vmsWnd = this.createWindow({
            title: "VM Settings for \"" + wmx.meta.name + "\"",
            initialWidth: 530,
            initialHeight: 420,
            center: true,
            bodyClass: "wmbox-vm-settings-dlg",
            body: `<div class="tabc"></div>
            <div class="buttons">
                <button class="w96-button btn-ok">OK</button>
                <button class="w96-button btn-cancel">Cancel</button>
            </div>`,
            controlBoxStyle: "WS_CBX_MINCLOSE",
            resizable: false,
            taskbar: false
        });

        const body = vmsWnd.getBodyContainer();

        const tabc = new TabControl();

        tabc.openPage(tabc.addPage("General", (e)=>{
            e.innerHTML = "interweb fart";
        }));

        body.querySelector(".tabc").replaceWith(tabc.getElement());

        vmsWnd.show();
    }

    async main(argv) {
        super.main(argv);

        if(!await FS.exists(VM_SAVE_DIR))
            await FS.mkdir(VM_SAVE_DIR);

        if(!await FS.exists("C:/user/appdata/WMBox/config.json"))
            await FS.writestr("C:/user/appdata/WMBox/config.json", JSON.stringify(this.config, null, 4));
        else
            this.config = {
                ...this.config,
                ...JSON.parse(await FS.readstr("C:/user/appdata/WMBox/config.json"))
            };

        const mainwnd = this.createWindow({
            title: "WMBox",
            bodyClass: "wmbox-app",
            initialHeight: 530,
            initialWidth: 750,
            taskbar: true,
            icon: await Theme.getIconUrl("apps/wmbox", '16x16'),
            resizable: true,
            body: `<div class="appbar"></div>
            <div class="vm-view">
                <div class="path-pane">
                    <!-- TODO replace with list box with VM list -->
                </div>
                <div class="overview">

                </div>
            </div>
            <footer class="w96-footer">
                WMBox (ver ${VERSION}) | 0 VMs present
            </footer>`,
            mobResize: true
        }, true);

        const body = mainwnd.getBodyContainer();

        const appBar = new MenuBar();

        appBar.addRoot("File", [
            {
                label: "Settings",
                onclick: ()=>{},
                type: "normal"
            },
            {
                type: "separator"
            },
            {
                label: "Exit",
                onclick: ()=>this.terminate(),
                type: "normal"
            }
        ]);

        appBar.addRoot("VM", [
            {
                label: "Create New",
                onclick: ()=>{},
                type: "normal"
            },
            {
                label: "Import",
                onclick: ()=>{},
                type: "normal"
            },
            {
                type: "separator"
            },
            {
                label: "Start",
                type: "normal",
                onclick: ()=>{
                    if(this.selectedVM)
                        execFile(this.selectedVM.vmDir + "/config.wmx");
                }
            },
            {
                type: "separator"
            },
            {
                label: "Settings",
                type: "normal",
                onclick: ()=>{
                    if(this.selectedVM)
                        this.showVMSettingsWnd(this.selectedVM.vmDir);
                }
            }
        ]);

        appBar.addRoot("Help", [
            {
                label: "Help Topics",
                onclick: ()=>{},
                type: "normal"
            },
            {
                type: "separator"
            },
            {
                label: "Third Party Credits",
                onclick: ()=>execFile("W:/system/apps/wmbox/docs/thirdparty.txt"),
                type: "normal"
            },
            {
                label: "About WMBox",
                onclick: ()=>DialogCreator.create({
                    title: "About WMBox",
                    body: "WMBox emulation program v1.0.<br><br>Copyright (C) Windows 96 Team 2023.",
                    icon: "info"
                }),
                type: "normal"
            }
        ]);

        body.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        const vmBox = new ListBox();

        await this.populateVMView(vmBox);

        vmBox.uiComponent.classList.add('path-pane');
        body.querySelector('.path-pane').replaceWith(vmBox.getElement());

        mainwnd.show();
        this.mainwnd = mainwnd;
    }

    ontermination() {
        super.ontermination();
    }
}