/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, OpenFileDialog } = w96.ui;
const { getMimetypeFromPath } = w96.util;

/**
 * The standard image viewer for Windows 96.
 */
class ImgViewerApplication extends WApplication {
    constructor() {
        super();
        this.scale = 1;
    }

    /**
     * Main entry point.
     * @param {String[]} argv Program arguments.
     */
    async main(argv) {
        await super.main(argv);
        
        if(argv[1] == null) {
            new OpenFileDialog("c:/", ["png", "jpg", "svg"], (fn)=>{
                if(!fn) {
                    this.terminate();
                    return;
                }

                this._createWindow(fn);
            }).show();

            return;
        }

        await this._createWindow(argv[1]);
    }

    /**
     * Creates the viewer window.
     * @param {String} fn The file name to use.
     */
    async _createWindow(fn) {
        // Transform to blob url
        const imgBlob = new Blob([await FS.readbin(fn)], { type: getMimetypeFromPath(fn) });
        this.blobUrl = URL.createObjectURL(imgBlob);

        // Create the main window.
        const mainwnd = this.createWindow({
            initialWidth: 540,
            initialHeight: 460,
            title: FSUtil.fname(fn) + " - Image Viewer",
            bodyClass: "imgviewer-app",
            body: `<div class="image-container" style="background-image: url(${this.blobUrl})"></div>
            <div class="controls">
                <button class="w96-button zoom"></button>
                <button class="w96-button center"></button>
                <button class="w96-button view-pixelated"></button>
                <button class="w96-button view-quality"></button>
                <button class="w96-button bg">BG</button>
            </div>`,
            taskbar: true,
            icon: await Theme.getIconUrl("mime/image-png", '16x16')
        }, true);

        // Set events

        const htmlContainer = mainwnd.getBodyContainer();
        const imageContainer = htmlContainer.querySelector('.image-container');
        const zoomBtn = htmlContainer.querySelector('.w96-button.zoom');
        const centerBtn = htmlContainer.querySelector('.w96-button.center');
        const bgBtn = htmlContainer.querySelector('.w96-button.bg');

        zoomBtn.onclick = () => {
            imageContainer.classList.remove('centered');
            this.resetScale();
        }

        centerBtn.onclick = () => {
            imageContainer.classList.add('centered');
            this.resetScale();
        }

        bgBtn.onclick = async function() {
            const desktopConfig = JSON.parse(await FS.readstr("c:/system/config/desktop.json"));
            const bg = fn;
            desktopConfig.background.type = "local";
            desktopConfig.background.bg = bg;
            await w96.evt.shell.emit('config-modify', desktopConfig);
        }

        htmlContainer.querySelector('.w96-button.view-pixelated').addEventListener('click', ()=>{
            imageContainer.classList.add('pixelated');
        });

        htmlContainer.querySelector('.w96-button.view-quality').addEventListener('click', ()=>{
            imageContainer.classList.remove('pixelated');
        });

        // Zoom wheel
        imageContainer.addEventListener('wheel', (e)=>{
            if(!imageContainer.classList.contains("centered"))
                return;

            const scrollModifier = (e.deltaY / 100) * -1; // Scroll inversion

            if(!(((this.scale + scrollModifier) > 10) || ((this.scale + scrollModifier) < 1)))
                this.scale += scrollModifier;

            imageContainer.style.transform = `scale(${this.scale})`;
        });

        this.imageContainer = imageContainer;
        
        // Start the app
        mainwnd.show();
        await mainwnd.wait(); // Wait for window closure.   
    }

    /**
     * Resets the zoom scale.
     */
    resetScale() {
        this.scale = 1;
        this.imageContainer.style.transform = "";
    }

    /**
     * On app exit.
     */
    ontermination() {
        super.ontermination();

        // Unregister image blob
        URL.revokeObjectURL(this.blobUrl);
    }
}