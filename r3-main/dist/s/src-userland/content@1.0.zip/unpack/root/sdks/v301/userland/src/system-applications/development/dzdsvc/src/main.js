/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme } = w96.ui;
const { DialogCreator } = w96.ui;
const { wmem, sysConf: SCM } = w96;
const { NotifyIcon, Taskbar } = w96.shell;
const { execCmd, rel: OSRelease } = w96.sys;
const { TabControl } = w96.ui.components;

// Socket statistics
const sockStats = {
    fileOps: 0,
    sockOps: 0
}

$$Include("./ui/appDeliveryToast.js")
$$Include("./ui/statusWindow.js")
$$Include("./events.js")

let socket;
let prgmFinishCallback;

class DZDSvcApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * Entry point.
     * @param {string[]} argv Arguments.
     */
    async main(argv) {
        super.main(argv);
        
        if(wmem.dz) {
            DialogCreator.alert("The DevConnector service is already running.", {
                icon: "warning",
                title: "DevConnector Service"
            });

            this.terminate();
            return;
        } else if(SCM.get("Software/DevConnector/dcAddress") == null) {
            this.die("Invalid configuration - please rerun the DevConnector wizard.");
            return;
        }

        // Setup the tray icon
        await this.setupTrayIcon();

        // Listen to socket
        await this.beginSockListen();

        // We are running
        wmem.dz = true;

        // Wait until program signals exit.
        await new Promise((resolve)=>prgmFinishCallback = resolve);
        wmem.dz = false;
        this.terminate();
    }

    /**
     * Sets up the tray icon.
     */
    async setupTrayIcon() {
        this.trayIcon = new NotifyIcon({
            iconUrl: "/system/resource/app/dzdcon/dz-tray-busy.png",
            onclick: ()=>{
                if(statusBox)
                    closeStatusBox();
                else
                    showStatusBox(this);
            }
        });

        Taskbar.registerNotifyIcon(this.trayIcon);
    }

    /**
     * Begins to listen for socket events.
     */
    async beginSockListen() {
        try {
            socket = io(SCM.get("Software/DevConnector/dcAddress"));

            this.trayIcon.setIcon("/system/resource/app/dzdcon/dz-tray-busy.png");
            
            socket.on('ct_pong', () => {
                // Send to connection success page
                console.log("DC Socket success!");
                this.trayIcon.setIcon("/system/resource/app/dzdcon/dz-tray-success.png");
                setupSocketEvents(io, socket);
            });

            socket.emit('ct_ping');

            // Handle connection error
            socket.on('connect_error', (err) => {
                console.error(err);
                socket.close();
                socket = null;
                this.handleSocketError();
            });
        } catch(e) {
            // Go to connection failed
            console.error(e);
            socket.close();
            socket = null;
            this.handleSocketError();
        }
    }

    /**
     * Handles socket errors.
     */
    handleSocketError() {
        console.log("DC Socket failure!");
        this.trayIcon.setIcon("/system/resource/app/dzdcon/dz-tray-error.png");
    }

    /**
     * Exits with the specified message.
     * @param {String} message The message to display on exit.
     */
    die(message) {
        DialogCreator.alert(message, {
            icon: "error",
            title: "DevConnector Service"
        });

        this.terminate();
    }

    /**
     * Disconnects from the socket.
     */
    disconnectSocket() {
        if(this.trayIcon)
            this.trayIcon.setIcon("/system/resource/app/dzdcon/dz-tray-error.png");

        if(socket)
            socket.close();

        socket = null;
    }

    // On termination
    async ontermination() {
        await super.ontermination();

        closeStatusBox();
        this.disconnectSocket();

        if(this.trayIcon) {
            this.trayIcon.notifyEl.remove();
            this.trayIcon = null;
        }

        if(statusWnd)
            statusWnd.close();

        statusWnd = null;
    }
}