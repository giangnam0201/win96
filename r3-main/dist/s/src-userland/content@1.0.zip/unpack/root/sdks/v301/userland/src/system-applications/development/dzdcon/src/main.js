/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { GroupBox, CheckBox } = w96.ui.components;
const { sysConf: SCM, wmem } = w96;
const { execCmd } = w96.sys;
const { Theme } = w96.ui;
const { DialogCreator } = w96.ui;

const dzdcPages = [];

// Installation properties
// This is the data that will be processed at the end of this wizard.
const installState = {
    /**
     * DevConnector address.
     */
    dcAddress: "localhost:1904",

    /**
     * Whether to start the DevConnector on startup.
     */
    dcStartup: true
}

$$Include("./pages/intro.js")
$$Include("./pages/intro-inst.js")
$$Include("./pages/address.js")
$$Include("./pages/ctest.js")
$$Include("./pages/confail.js")
$$Include("./pages/congood.js")
$$Include("./pages/dcsettings.js")
$$Include("./pages/setup-finish.js")

// TODO display different UI (repair, uninstall) type UI for isntances which have dc already setup

class DZDConApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * Entry point.
     * @param {string[]} argv Arguments.
     */
    async main(argv) {
        super.main(argv);
        await this._createWindow();
    }

    /**
     * Renders a page.
     */
    async renderPage(name) {
        const page = dzdcPages.find(x => x.name == name);

        if(!page)
            throw new Error(`Cannot find page named "${name}"`);

        // Clear content
        const contentEl = this.body.querySelector('.content');
        contentEl.className = "content";

        while(contentEl.firstChild)
            contentEl.removeChild(contentEl.firstChild);

        // Set content and button states
        contentEl.innerHTML = page.content;

        for(let button of page.buttons) {
            const btnEl = this.body.querySelector(`.buttons .${button.cls}`);

            if(btnEl) {
                btnEl.disabled = !button.enabled;

                if(button.onclick)
                    btnEl.onclick = (e)=>button.onclick(this, e);
            }
        }

        // Call the render function
        await page.onrender(this, contentEl);
        contentEl.classList.add(name);
    }

    /**
     * Creates the main interface.
     */
    async _createWindow() {
        // Create the window
        const wnd = this.createWindow({
            title: "Dazzle DevConnector",
            bodyClass: "dzdc-app",
            body: `
                <div class="header"></div>
                <div class="content"></div>
                <div class="buttons">
                    <button class="w96-button back">Back</button>
                    <button class="w96-button next">Next</button>
                    <button class="w96-button cancel">Cancel</button>
                </div>
            `,
            initialHeight: 381,
            initialWidth: 500,
            controlBoxStyle: "WS_CBX_CLOSE",
            taskbar: false,
            center: true,
            resizable: false
        }, true);

        /** @type {HTMLDivElement} */
        const body = wnd.getBodyContainer();
        this.body = body;

        // Assign some events
        /** @type {HTMLButtonElement} */
        const cancelBtn = body.querySelector('button.cancel');

        cancelBtn.addEventListener('click', () => {
            body.classList.add('busy');

            DialogCreator.confirm("Are you sure you want to quit?", {
                icon: "warning",
                title: "DevConnector Wizard"
            }, (value) => {
                body.classList.remove('busy');
                
                // Quit the dev connector
                if(value) {
                    wnd.close();
                }
            });
        });

        wnd.show();

        // Check if DC is already setup
        // Otherwise show setup intro page

        if(SCM.get("Software/DevConnector/dcAddress"))
            await this.renderPage("intro-inst");
        else
            await this.renderPage("intro");
    }

    /**
     * On app exit.
     */
    async ontermination() {
        super.ontermination();
        this.body = null;
    }
}