/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { OpenFileDialog, DialogCreator, Theme } = w96.ui;
const { RadioBox } = w96.ui.components;
const { WizardBaseApplication } = w96.app.templates;

class BackupManagerApp extends WizardBaseApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        // Custom intro page
        const noRestore = argv.includes('--no-restore');

        const introPage = this.findPage("intro");
        introPage.titleText = "Welcome to the Backup Wizard";
        introPage.graphic = "/system/resource/app/backup/graphic.png";
        introPage.body = "This wizard will help you create or restore a Windows 96 backup.<br><br>Please note that all applications must be closed for the best results.<br><br>The OS may freeze during the backup (do not panic, it is normal).";
        introPage.buttons[1].onclick = ()=>this.openPage(noRestore ? "backup" : "backup-select", []);

        // Variable for radio box
        let radioActSelect = "backup";

        // Backup option selection page
        this.pages.push({
            id: "backup-select",
            type: "page",
            body: `Select an action:
                <div class="w96-radiobox">
                    <div class="option">
                        <input type="radio" name="bopt" value="opt1">
                        <label for="opt1" class="text">Create system backup.</label>
                    </div>
                    <div class="option">
                        <input type="radio" name="bopt" value="opt2">
                        <label for="opt2" class="text">Restore from backup ZIP.</label>
                    </div>
                </div>`,
            graphic: "/system/resource/app/backup/graphic-top.png",
            titleText: "What would you like to do?",
            description: "You can backup your system or restore from one.",
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("intro", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{
                        if(radioActSelect == "backup")
                            this.openPage("backup", []);
                        else
                            this.openPage("restore", []);
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{
                const opts = new RadioBox([
                    {
                        label: "Create system backup.",
                        id: "backup",
                        onselect: ()=>{ radioActSelect = "backup"; },
                        selected: true
                    },
                    {
                        label: "Restore from ZIP archive.",
                        id: "restore",
                        onselect: ()=>{ radioActSelect = "restore"; },
                        selected: false
                    }
                ]);

                page.querySelector('.w96-radiobox').replaceWith(opts.getElement());
            }
        });

        // Backup page
        this.pages.push({
            id: "backup",
            type: "page",
            body: `
                <div>
                    To begin the backup, press the next button. When the backup is complete, you will receive a locally generated download button with your data as a ZIP file.<br><br>
                    Please note that your OS may lag/freeze/slow down because of heavy file system activity.<br><br>
                    It is recommended to close all applications to avoid data corruption.<br><br>Please save your work, you will not be able to close the backup process once its running!
                </div>
            `,
            graphic: "/system/resource/app/backup/graphic-top.png",
            titleText: "Begin the backup",
            description: `Read the information below carefully.`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("backup-select", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{
                        localStorage.setItem("backup_mode_reboot", "true");
                        document.location.reload();
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{}
        });

        // Restore page
        this.pages.push({
            id: "restore",
            type: "page",
            body: `
                <div>
                    To restore your system, please select a ZIP file below.<br><br>
                    When this is done, click Next to restore your system.<br><br>
                    Do not interrupt the restore process, you may likely make your installation unusable or corrupt.<br><br>
                </div>
                <div class="path-box">
                    <input class="w96-textbox path">
                    <button class="w96-button browse">Browse...</button>
                </div>
            `,
            graphic: "/system/resource/aPP/backup/graphic-top.png",
            titleText: "Restore from a backup",
            description: `Upload your ZIP file to begin the restore process`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("backup-select", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: async ()=>{
                        const restoreZIP = this.mainwnd.getBodyContainer().querySelector('input').value;

                        if(!(await FS.exists(restoreZIP))) {
                            DialogCreator.alert("The specified ZIP file does not exist.");
                            return;
                        }

                        localStorage.setItem("restore_image", restoreZIP);
                        document.location.reload();
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{
                const input = page.querySelector("input");
                input.setAttribute("style", "width: 100%; box-sizing: border-box; margin-bottom: 10px;");

                page.querySelector("button.browse").addEventListener('click', ()=>{
                    new OpenFileDialog("c:/", [".zip", ".ZIP"], (v)=>{
                        if((v != null) && (v.trim() != "")) {
                            page.querySelector('input').value = v;
                        }
                    }).show();
                });
            }
        });

        this.openPage("intro", []);
        this.mainwnd.setTitle("Backup Wizard");
        this.mainwnd.setWindowIcon(await Theme.getIconUrl("apps/backupmgr", '16x16'));
    }
}