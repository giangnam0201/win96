/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Default desktop configuration.
 */
const DESKTOP_CONFIG_DEFAULT = {
    /**
     * Background properties.
     */
    background: {
        /** @type {"local"|"url"|"fs"} */
        type: "local", // Can also be 'url' or 'fs'
        /**
         * The background to be used in the current desktop session.
         */
        bg: "c:/system/wallpapers/default.jpg"
    },
    misc: {
        /**
         * Whether to hook the keyboard META key (Windows key, CMD key, etc.).
         */
        hookMetaKeys: false
    }
}

/**
 * Default start menu configuration.
 */
const START_MENU_CONFIG = {
    text: "Windows 96",
    items: [
        {
            name: "Programs",
            type: "dir-menu",
            path: "C:/system/programs",
            command: "explorer C:/system/programs",
            icon: "places/folder-programs",
            dirEntryIcon: "places/folder-prgm"
        },
        {
            name: "Documents",
            type: "dir-menu",
            path: "C:/user/documents",
            command: "explorer C:/user/documents",
            icon: "places/documents"
        },
        {
            name: "Settings",
            type: "normal",
            command: "ctrl",
            icon: "apps/settings"
        },
        {
            type: "separator"
        },
        {
            name: "Device Config",
            type: "normal",
            command: "ctrl --cpl devcfg",
            icon: "apps/touchcfg"
        },
        {
            name: "Help",
            type: "normal",
            command: "internete https://w96.wiki",
            icon: "objects/help-book"
        },
        {
            name: "Run",
            type: "normal",
            command: "run",
            icon: "apps/run"
        },
        {
            type: "separator"
        },
        {
            name: "Reboot",
            type: "normal",
            command: "reboot",
            icon: "apps/shutdown"
        },
        {
            name: "Reset",
            type: "normal",
            command: "resetwiz",
            icon: "apps/reinstall"
        },
        {
            type: "separator"
        },
        {
            name: "About",
            type: "normal",
            command: "about-ui",
            icon: "apps/about"
        }
    ]
}
