/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { wait, sizeFmt } = w96.util;
const { IFileSystem, RemoteReadOnlyFileSystem } = w96.fstype;
const { FSFeatures, WindowParams, sysConf: SCM } = w96;
const { ContextMenu, MsgBoxSimple, MenuBar, Theme, DialogCreator } = w96.ui;
const { ToolBar, TabControl, FSView, ExplorerAddressBar, GroupBox, ListBox } = w96.ui.components;
const { DirMetadataReader, execFile, execCmd, renderBSOD } = w96.sys;

$$Include("./components/toolbar.js")
$$Include("./dialogs/properties/tabs/volume.js")
$$Include("./dialogs/properties/tabs/program.js")
$$Include("./dialogs/properties/dialog.js")

var uiLayouts = {
    main: ``
};

const READ_ONLY_CMDS_INVAL = [
    "cut",
    "copy",
    "paste",
    "delete",
    "rename",
    "mklink",
    "mkdir",
    "mkfile"
];

const SYSTEM_DRIVES = [
    "C:/",
    "W:/"
];

class ExplorerApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        argv.shift(); //App name is not relevant for this program

        // Show properties window.
        if((argv[0] == "--prop") && (await FS.exists(argv[1]))) {
            showPropertiesDialog(this, argv[1]);
            this.terminate();
            return;
        }

        var targetPath = (argv[0] != null) ? argv[0] : "computer://";
        if (targetPath !== 'computer://')
            targetPath = targetPath[0].toUpperCase() + targetPath.substring(1);

        if(!await FS.exists(targetPath))
            targetPath = "computer://";

        const params = new WindowParams();
        params.resizable = false;
        //params.title = targetPath + " - Explorer";
        if(targetPath == "computer://")
            params.title = "Computer";
        else
            params.title = (targetPath.length == 3) ? targetPath : FSUtil.fname(targetPath);

        params.initialWidth = 570;
        params.initialHeight = 480;
        params.resizable = true;

        const mainwnd = this.createWindow(params, true);
        mainwnd.useIcon = true;
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setWindowIcon(await Theme.getIconUrl('apps/explorer', '16x16'));
        mainwnd.setControlBoxStyle('WS_CBX_MINMAXCLOSE');
        mainwnd.setHtml(uiLayouts.main);

        this.mainwnd = mainwnd;

        /**
         * Explorer options
         */

        this.options = {
            showSidebar: true,
            showHiddenFiles: false,
            metaLookup: true,
            specialPaths: [
                "c:/system/temp"
            ],
            compactToolbar: false
        };

        try {
            if(!SCM.get("Software/Explorer/Configuration"))
                await SCM.setAndSync("Software/Explorer/Configuration", this.options);
            else
                this.options = SCM.get("Software/Explorer/Configuration");
        } catch(e) {
            if (!w96.isRecovery) MsgBoxSimple.warning("Oops", "There was an error loading the configuration file. Please rectify it.", "OK");
        }

        const appBar = new MenuBar();

        appBar.addRoot("File", [
            { type: "normal", label: "Create Directory", onclick: ()=>{
                this._ui_newDir();
            } },
            { type: "normal", label: "Create File", onclick: ()=>{
                this._ui_newFile();
            } },
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{
                this.terminate();
            } }
        ]);

        appBar.addRoot("View", [
            { type: "normal", label: "Refresh", onclick: ()=>{
                this.refresh();
            } }
        ]);

        appBar.addRoot("Go", [
            { type: "normal", icon: await Theme.getIconUrl("devices/computer", '16x16'), label: "Computer", onclick: ()=>{ this.navigate("computer://"); } },
            { type: "separator" },
            { type: "normal", icon: await Theme.getIconUrl("places/folder", '16x16'), label: "Home", onclick: ()=>{ this.navigate("c:/user"); } },
            { type: "normal", icon: await Theme.getIconUrl("places/desktop", '16x16'), label: "Desktop", onclick: ()=>{ this.navigate("c:/user/desktop"); } },
            { type: "normal", icon: await Theme.getIconUrl("places/documents", '16x16'), label: "Documents", onclick: ()=>{ this.navigate("c:/user/documents"); } },
            { type: "separator" },
            { type: "normal", icon: await Theme.getIconUrl("places/folder", '16x16'), label: "Boot Folder", onclick: ()=>{ this.navigate("c:/system/boot"); } },
            { type: "normal", icon: await Theme.getIconUrl("devices/hdd", '16x16'), label: "System Drive", onclick: ()=>{ this.navigate("c:/"); } },
            { type: "normal", icon: await Theme.getIconUrl("places/trash", '16x16'), label: "Trash", onclick: ()=>{ this.navigate("c:/trash"); } }
        ]);

        // a bit annoying I think
        const mountsSubMenu = [
            {
                type: "normal", label: "Read-only FS", onclick: ()=>{
                    MsgBoxSimple.prompt("Mount Read-only File System", "Enter the ROFS URL below.", "", async(v)=>{
                        if((!v) || (v.trim() == ""))
                            return;

                        try {
                            const rfs = new RemoteReadOnlyFileSystem(FS.nextLetter(), v);
                            await FS.mount(rfs);
                        } catch(e) {
                            MsgBoxSimple.error("Mount Failure", "Failed to mount specified image.", "OK");
                        }
                    });
                }
            }
        ];

        const toolsBar = [
            { type: "normal", label: "Upload", onclick: ()=>{
                if(this.currentPath == "computer://")
                    return;

                const uParams = new WindowParams();
                uParams.initialHeight = 150;
                uParams.initialWidth = 300;
                uParams.title = "Upload File";
                uParams.resizable = false;

                const uWnd = this.createWindow(uParams, false);
                uWnd.registerWindow();
                uWnd.setControlBoxStyle("WS_CBX_CLOSE");

                const body = uWnd.getBodyContainer();
                body.classList.add('uploader-app');
                body.innerHTML = `Choose files below and press "Start" to upload them.<br><br>The uploaded files will be saved to this folder.
                <br><br>
                <input type="file" class="w96-textbox" multiple=""><br>
                <button class="w96-button start">Start</button>`;

                const startButton = body.querySelector(".start");
                const fileInput = body.querySelector("input");

                startButton.onclick = async()=> {
                    startButton.disabled = true;

                    const mbx = MsgBoxSimple.idleProgress("Upload in progress", "The selected files are being saved, please wait...");
                    mbx.show();

                    for(let x = 0; x < fileInput.files.length; x++) {
                        const file = fileInput.files.item(x);
                        const target = ((this.currentPath.length == 3) ? this.currentPath : this.currentPath + "/") + file.name;
                        console.log("Writing " + target);
                        const arr = new Uint8Array(await file.arrayBuffer());
                        await FS.writebin(target, arr);
                    }

                    setTimeout(()=>{
                        startButton.disabled = false;
                        mbx.closeDialog();
                        this.navigate(this.currentPath, true);
                    }, 250);
                }

                uWnd.show();
                uWnd.center();
            } },
            {
                type: "separator"
            },
            {
                type: "submenu",
                label: "Mount",
                removeIconPrespace: true,
                items: mountsSubMenu
            }
        ];

        /*
        TODO: Find way to check if p3fs app exists
        if (!zpv.app_blacklist.p3fs){
            mountsSubMenu.push({ type: "normal", label: "P3 FS", onclick: ()=>{
                execCmd('p3fs', ["--connect"]);
            }});
        }
        */
        mountsSubMenu.push({ type: "normal", label: "P3 FS", onclick: ()=>{
            execCmd('p3fs', ["--connect"]);
        }});

        appBar.addRoot("Tools", toolsBar);

        appBar.addRoot("Help", [
            { type: "normal", label: "About File Explorer", onclick: ()=>{
                alert(`<span class="bold-noaa">File Explorer</span><br>Version 1.2<br>`, {
                    title: "About File Explorer",
                    icon: "info"
                });
            } }
        ]);

        this.appBar = appBar;

        // Create footer
        const footer = document.createElement('div');
        footer.classList.add('w96-footer');

        this.infoFooter = document.createElement('div');
        this.infoFooter.innerText = "0 items";
        this.infoFooter.classList.add('cell');
        footer.appendChild(this.infoFooter);

        this.fsv = new FSView("c:/", true);
        this.fsv.init();
        this.fsv.uiComponent.style.width = params.initialWidth + 'px';
        this.fsv.uiComponent.style.height = params.initialHeight + 'px';
        this.fsv.setSize('100%', '100%');

        const navBar = new ExplorerAddressBar({ compactToolbar: this.options.compactToolbar });
        navBar.navigate = (...args) => this.navigate(...args);
        navBar.fsv = this.fsv;

        this.pathBar = navBar.input;
        this.pathBar.value = targetPath;

        let toolBar;
        if(!this.options.compactToolbar) {
            toolBar = new ExplorerToolbar({
                delete: true,
                properties: true,
                iconMap: {
                    up: await Theme.getIconUrl('actions/up', '24x24'),
                    back: await Theme.getIconUrl('actions/back', '24x24'),
                    forward: await Theme.getIconUrl('actions/forward', '24x24'),
                    cut: await Theme.getIconUrl('actions/cut', '24x24'),
                    copy: await Theme.getIconUrl('actions/copy', '24x24'),
                    paste: await Theme.getIconUrl('actions/paste', '24x24'),
                    delete: await Theme.getIconUrl('actions/delete', '24x24'),
                    properties: await Theme.getIconUrl('actions/properties', '24x24')
                }
            });
            
            toolBar.fsv = this.fsv;
            toolBar.navigate = (...args) => this.navigate(...args);
            toolBar.ondelete = (...args) => this._ui_delete(...args);
            toolBar.onproperties = (...args) => showPropertiesDialog(this, ...args);
            this.toolBar = toolBar;
        }

        (function(fsv, _cls) {
            mainwnd.ondarkenelements = function() {
                fsv.uiComponent.querySelectorAll('.shell-icon.selected').forEach((v)=>{
                    v.classList.add('inactive');
                });
            }

            mainwnd.onlightenelements = function() {
                fsv.uiComponent.querySelectorAll('.shell-icon.inactive').forEach((v)=>{
                    v.classList.remove('inactive');
                });

                fsv.uiComponent.focus();
            }

            fsv.uiComponent.oncontextmenu = function(e) {
                var parEl = e.target;

                while(!parEl.classList.contains('exp-file-view')) {
                    if(parEl.classList.contains("shell-icon"))
                        return;

                    parEl = parEl.parentNode;
                }

                e.preventDefault();
                fsv.deselectAllIcons();

                // TODO: make efficient and combine to function where ent type is selected
                let emptyCtxmItems = [
                    {
                        type: "normal",
                        label: "Create Directory",
                        class: "mkdir",
                        onclick: function() {
                            _cls._ui_newDir();
                        }
                    },
                    {
                        type: "normal",
                        label: "Create File",
                        class: "mkfile",
                        onclick: function() {
                            _cls._ui_newFile();
                        }
                    },
                    {
                        type: "separator"
                    },
                    {
                        type: "normal",
                        label: "Paste",
                        class: "paste",
                        disabled: true,
                        onclick: function() {
                            fsv.performClipboard("paste");
                        }
                    },
                    {
                        type: "separator"
                    },
                    {
                        type: "normal",
                        label: "Refresh",
                        class: "refresh",
                        onclick: function() {
                            if (fsv.fsPath == "computer://")
                                return;
                            _cls.navigate(_cls.currentPath, true, false);
                        }
                    }
                ];

                document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());
                const fp = FSUtil.deconstructFullPath(fsv.fsPath);

                // Check clipboard for items
                // If there are items, enable paste item
                if(fsv.fsPath == "computer://") {
                    emptyCtxmItems = [
                        {
                            type: "normal",
                            label: "Refresh",
                            class: "refresh",
                            onclick: function() {
                                _cls.refresh();
                            }
                        }
                    ]
                } else {
                    if(w96.wmem.clipboard && (w96.wmem.clipboard.items.length > 0))
                        emptyCtxmItems.find(x=>x['class'] == "paste").disabled = false;

                    if(FS.get(fp.prefix).features.includes(FSFeatures.readOnly)) {
                        for(let i of emptyCtxmItems)
                            if(READ_ONLY_CMDS_INVAL.includes(i['class']))
                                i.disabled = true;
                    }
                }

                const emptyCtxMenu = new ContextMenu(emptyCtxmItems);
                emptyCtxMenu.renderMenu(e.x, e.y);
            }
        })(this.fsv, this);

        /** @type {HTMLDivElement} */
        const wContainer = mainwnd.wndObject.querySelector(".window-html-content");
        wContainer.classList.add("wexplorer-app");
        let barsContainer = document.createElement('div');
        barsContainer.classList.add('w96-ui-inset');

        barsContainer.appendChild(appBar.getMenuDiv());
        if(!this.options.compactToolbar) {
            barsContainer.appendChild(this.toolBar.getElement());
        }
        barsContainer.appendChild(navBar.getElement());
        wContainer.appendChild(barsContainer);

        // Create combo container with info sidebar
        // Have toggle to turn it off
        // TODO find a way to use this switch

        this.fsv.options.showHiddenFiles = this.options.showHiddenFiles;
        this.fsv.options.metaLookup = this.options.metaLookup;

        if(this.options.showSidebar) {
            const viewBox = document.createElement('div');
            viewBox.classList.add('view-box');

            const fileBoxEl = document.createElement('div');
            fileBoxEl.classList.add('file-box');

            const infoSidebar = document.createElement('div');
            infoSidebar.classList.add('sidebar');

            const iconEl = document.createElement('div');
            iconEl.classList.add('icon');

            const nameEl = document.createElement('div');
            nameEl.classList.add('name');

            const lineEl = document.createElement('div');
            lineEl.classList.add('line');

            const descEl = document.createElement('div');
            descEl.classList.add('desc');

            fileBoxEl.appendChild(iconEl);
            fileBoxEl.appendChild(nameEl);
            fileBoxEl.appendChild(lineEl);
            fileBoxEl.appendChild(descEl);

            infoSidebar.appendChild(fileBoxEl);

            viewBox.appendChild(infoSidebar);
            viewBox.appendChild(this.fsv.getElement());
            wContainer.appendChild(viewBox);
        }
        else
            wContainer.appendChild(this.fsv.getElement());

        wContainer.appendChild(footer);

        this.fsv.onitemdblclick = async (el)=>{
            const ent_type = parseInt(el.getAttribute("ent"), 10);
            switch(ent_type) {
                case 0:
                    execFile.call({ _cachedFiletype: ent_type }, el.getAttribute("path")).catch((e)=>{
                        MsgBoxSimple.error("Error", e, "OK");
                        console.error(e);
                    });
                    break;
                case 1: case 2:
                    this.fsv.deselectAllIcons();
                    this.navigate(el.getAttribute("path"));
                    break;
            }
        }

        this.fsv.ondropfinish = ()=>{
            this.navigate(this.currentPath, true);
            this.mainwnd.activate();
        }

        this.fsv.onrefreshneeded = ()=>this.refresh();

        mainwnd.onshown = ()=>{
            /* this.fsv.navigate(targetPath, (ents) => this._navComplete(ents));
            this.currentPath = targetPath; */
            this.navigate(targetPath, false);
        }

        mainwnd.onclose = ()=> {
            // Save window size
            // TODO
        }

        this._ui_wc = wContainer;

        // Start the app
        mainwnd.show();

        // Assign some keyboard events to make teh file experience a little nicer
        // This is not working for some reason.

        this.fsv.uiComponent.addEventListener('keydown', (e)=>{
            if(!this.mainwnd.isActive())
                return; // Do not process key events if window is inactive

            if(e.key == "Delete") {
                e.preventDefault();
                e.stopPropagation();

                const selectedIcon = this.fsv.uiComponent.querySelector('.shell-icon.selected');

                if(!selectedIcon)
                    return;

                const path = selectedIcon.getAttribute("path");
                const ent = selectedIcon.getAttribute("ent");

                if(ent == "2")
                    return;

                this._ui_delete(path, ent);
            }
        });

        this._ui_delete_busy = false; // State variable - we need this so there is no double delete

        let refreshCompleted = true;

        this.fsv.onclipboard = async()=>{
            // There is a possibility the clipboard pasting is happening from a closed window
            // So we check it

            if(this.mainwnd.wndObject && refreshCompleted) {
                refreshCompleted = false;

                if(this.refresh)
                    await this.refresh();

                await wait(10);
                this.mainwnd.activate();
                refreshCompleted = true;
            }
        }

        /**
         * Store the cb as a separate function
         * so it can be unregistered later.
         */
        //w96.evt.ui.on('reload-desktop', ()=>this._reloadCb);
        // What is this for even? Lole!
    }

    _reloadCb() {
        this.refresh();
    }

    /**
     * Navigation complete callback.
     * @param {String[]} ents Retrieved FS entity (dirs/files) list.
     */
    _navComplete(ents) {
        this.infoFooter.innerText = (ents.length == 1) ? "1 item" : `${ents.length} items`;
        // Set context menu handlers
        this.fsv.uiComponent.querySelectorAll(".shell-icon").forEach((iconEl)=>{
            if(this.options.specialPaths.includes(this.currentPath.toLowerCase()))
                iconEl.classList.add('special');

            iconEl.oncontextmenu = (e)=> {
                // Get rid of other menus
                document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());
                this.mainwnd.activate();
                const iconElType = iconEl.getAttribute("ent");
                const iconElPath = iconEl.getAttribute("path");

                let ctxmItems;

                if(this.currentPath == "computer://") {
                    ctxmItems = [
                        {
                            type: "normal",
                            label: "Unmount",
                            class: "unmount",
                            onclick: async()=>{
                                const body = this.mainwnd.getBodyContainer();
                                body.classList.add('busy');

                                try {
                                    await FS.umount(iconElPath.substring(0, 2));
                                } catch(e) {
                                    console.error(e);
                                }

                                body.classList.remove('busy');
                                this.refresh();
                            }
                        },
                        {
                            type: "normal",
                            label: "Make Link",
                            class: "mklink",
                            onclick: async()=>{
                                const linkObj = {
                                    action: iconElPath
                                };

                                await FS.writestr(`C:/user/desktop/Link to (${iconElPath[0]}).link`, JSON.stringify(linkObj));

                                DialogCreator.alert("A shortcut icon has been placed on your desktop.", {
                                    icon: "info"
                                });
                            }
                        },
                        {
                            type: "separator"
                        },
                        {
                            type: "normal",
                            label: "Properties",
                            onclick: ()=>showPropertiesDialog(this, iconElPath)
                        }
                    ];

                    // Disable unmounting for system drives.

                    for(let i of ctxmItems)
                        if(SYSTEM_DRIVES.includes(iconElPath.toUpperCase()) && (i['class'] == "unmount"))
                            i.disabled = true;
                } else {
                    ctxmItems = [
                        { type: "normal", label: "Open", onclick: ()=> {
                            iconEl.ondblclick(e);
                        } },
                        { type: "normal", label: "Open with...", class: "openwith", onclick: () => {
                            execCmd('openwith', [iconElPath]);
                        } },
                        { type: "normal", label: "Download", class: "download", onclick: ()=> {
                            if(iconElType == "1") {
                                MsgBoxSimple.error("Error", "Not implemented", "OK");
                                return;
                            }

                            FSUtil.downloadFile(iconElPath);
                        } },
                        { type: "separator" },
                        {
                            type: "normal",
                            label: "Cut",
                            class: "cut",
                            onclick: async ()=> {
                                this.fsv.performClipboard("cut");
                            }
                        },
                        {
                            type: "normal",
                            label: "Copy",
                            onclick: async ()=> {
                                this.fsv.performClipboard("copy");
                            }
                        },
                        { type: "separator" },
                        {
                            type: "normal",
                            label: "Make Link",
                            class: "mklink",
                            onclick: async ()=> {
                                const linkObj = {
                                    action: iconElPath
                                }

                                const fn = FSUtil.fname(iconElPath);
                                let target = ((this.currentPath.length == 3) ? this.currentPath : this.currentPath + "/") + `Link to ${fn}.link`;

                                if(fn.endsWith(".link")) {
                                    target = ((this.currentPath.length == 3) ? this.currentPath : this.currentPath + "/") + `Copy of ${fn}`;
                                    await FS.cpfile(iconElPath, target);
                                } else
                                    await FS.writestr(target, JSON.stringify(linkObj));

                                this.refresh();
                            }
                        },
                        { type: "normal", label: "Rename", class: "rename", onclick: async ()=> {
                            MsgBoxSimple.prompt("Rename", "Enter the new name of the entry.", FSUtil.fname(iconElPath), async(val)=> {
                                if(val == null)
                                    return;

                                await FS.rename(iconElPath, val);
                                this.navigate(this.currentPath, true);
                            });
                            // TODO
                        } },
                        {
                            type: "normal",
                            label: "Delete",
                            class: "delete",
                            onclick: async ()=> {
                                this._ui_delete(iconElPath, iconElType);
                            }
                        },
                        { type: "separator"},
                        { type: "normal", label: "Properties", onclick: ()=> {
                            showPropertiesDialog(this, iconElPath);
                        } }
                    ];
                }

                const ctxMenu = new ContextMenu(ctxmItems);

                // Remove "Download" and "Open with" options if
                // the icon is a folder.
                if(iconElType == "1") {
                    ctxMenu.items = ctxMenu.items.filter(item => {
                        return (item.class != 'openwith') && (item.class != 'download');
                    });
                }

                const fp = FSUtil.deconstructFullPath(this.fsv.fsPath);

                // Disable cut button, delete button, and rename button for read only sources.
                if(FS.get(fp.prefix).features.includes(FSFeatures.readOnly))
                    for(let item of ctxMenu.items)
                        if(READ_ONLY_CMDS_INVAL.includes(item['class']))
                            item.disabled = true;

                ctxMenu.renderMenu(e.x, e.y);
            }
        });
    }

    /**
     * Shows UI deletion dialog.
     * @param {String} iconElPath Path for this icon.
     * @param {"0"|"1"|"2"} iconElType Icon file type.
     * @returns
     */
    async _ui_delete(iconElPath, iconElType) {
        if(this._ui_delete_busy)
            return;
        else
            this._ui_delete_busy = true;

        // Keep the funny!
        if((iconElType == "1") && (iconElPath.toLowerCase() == "c:/system")) {
            await FS.rmdir(iconElPath);

            if((iconElPath == "c:/system") || (iconElPath == "C:/system")) {
                await wait(2000);
                renderBSOD("Cannot find system folder c:/system!");
            }

            return;
        }

        try {
            await execCmd("recyclui", [iconElPath]);
        } catch(e) {
            console.error(e);
        }

        this.fsv.uiComponent.focus(); // Refocus on ui component

        this._ui_delete_busy = false;
        this.navigate(this.currentPath, true);
        await wait(10); // Hacky
        this.mainwnd.activate();
    }

    /**
     * Shows the new directory UI.
     */
    _ui_newDir() {
        this.fsv.uiCreateDirectory(done => {
            if(done) {
                this.refresh();
            }
        });
    }

    /**
     * Updates the explorer sidebar.
     * @param {String} icon The Icon URL.
     * @param {String} location The current location name.
     * @param {*} meta Dir meta.
     */
    async _ui_sidebar_update(icon, location, meta) {
        if(this.options.showSidebar) {
            const fBox = this._ui_wc.querySelector(".sidebar>.file-box");

            fBox.querySelector('.name').innerText = location;
            fBox.querySelector('.icon').style.backgroundImage = `url(${icon})`;
            fBox.querySelector('.desc').innerText = "";

            // Process meta
            if(meta) {
                await meta.read();
                // Set some values
                if(meta.properties.description)
                    fBox.querySelector('.desc').innerText = meta.properties.description;
            }
        }
    }

    /**
     * Shows the new file UI.
     */
    _ui_newFile() {
        this.fsv.uiCreateFile(done => {
            if(done) {
                this.refresh();
            }
        })
    }

    /**
     * Navigates to the specified path.
     * @param {String} path The path to navigate to.
     * @param {Boolean} quiet Whether to quietly navigate to the destination.
     * @param {Boolean} addHistory Whether to add this navigation to the navigation history.
     */
    async navigate(path, quiet, addHistory = true) {
        this.fsv.uiComponent.focus();

        if((path != "computer://") && (!await FS.exists(path))) {
            return MsgBoxSimple.error("Error", "Directory does not exist.", "OK", () => {
                setTimeout(() => this.mainwnd.activate(), 10);
            });
        }

        if(addHistory && path !== this.currentPath && !this.options.compactToolbar) {
            this.toolBar.update();
        }

        this.currentPath = path;
        this.pathBar.value = this.currentPath;

        let dirMeta = null;

        if(this.options.metaLookup)
            dirMeta = new DirMetadataReader(path);

        switch(this.currentPath) {
            case "computer://":
                this.mainwnd.setTitle("Computer");
                this.mainwnd.setWindowIcon(await Theme.getIconUrl("devices/computer", '16x16'));
                this._ui_sidebar_update(await Theme.getIconUrl("devices/computer"), "My Computer", dirMeta);
                break;
            case "C:/trash":
                this.mainwnd.setTitle("Recycle Bin");
                this.mainwnd.setWindowIcon(await Theme.getIconUrl("places/trash", '16x16'));
                this._ui_sidebar_update(await Theme.getIconUrl("places/trash"), "Recycle Bin", dirMeta);
                break;
            default:
                // Are we in a drive root?
                if(this.currentPath.length == 3) {
                    /** @type {IFileSystem} */
                    const pfx = this.currentPath.substring(0, 2);
                    const drive = FS.get(pfx);

                    let driveIcon = "devices/hdd";

                    switch(drive.driverName) {
                        default: case "idbfs":
                            break;
                        case "localfs":
                            driveIcon = "devices/floppy";
                            break;
                        case "ramfs":
                            driveIcon = "devices/memory";
                            break;
                        case "zipfs-ro":
                            driveIcon = "places/folder";
                            break;
                        case "rofs":
                            driveIcon = "devices/hdd-ro";
                            break;
                        case "p3fs":
                            driveIcon = "apps/p3fs";
                            break;
                    }

                    this.mainwnd.setTitle(this.currentPath);
                    this._ui_sidebar_update(await Theme.getIconUrl(driveIcon), drive.volumeLabel + " (" + pfx + ")", dirMeta);
                    this.mainwnd.setWindowIcon(await Theme.getIconUrl(`${driveIcon}`, '16x16'));
                } else {
                    this.mainwnd.setTitle(FSUtil.fname(this.currentPath));
                    this._ui_sidebar_update(await Theme.getFileIconUrl(this.currentPath), FSUtil.fname(this.currentPath), dirMeta);
                    this.mainwnd.setWindowIcon(await Theme.getIconUrl("places/folder-open", '16x16'));
                }
                break;
        }

        this.fsv.navigate(path, (ents) => this._navComplete(ents), quiet, addHistory);
    }

    /**
     * Sets the view mode.
     * @param {"icons"|"tile"|"details"} mode The view mode to use.
     */
    setViewMode(mode) {
        return this.fsv.setViewMode(mode);
    }

    /**
     * Refreshes the explorer view.
     */
    async refresh() {
        await this.navigate(this.currentPath, true, false);
    }

    ontermination() {
        super.ontermination();
        //w96.evt.ui.remove('reload-desktop', this._reloadCb);
    }
}