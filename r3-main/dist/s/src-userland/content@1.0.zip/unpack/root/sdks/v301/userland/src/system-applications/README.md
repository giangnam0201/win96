# System Apps Directory

The dir names suggest exactly what each app folder contains.