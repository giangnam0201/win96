/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams, FSFeatures } = w96;
const { Theme, MenuBar, MsgBoxSimple, OpenFileDialog, SaveFileDialog, DialogCreator } = w96.ui;
const { rand } = w96.util;
const { execCmd } = w96.sys;

class MonacoApplication extends WApplication {
    constructor() {
        super();
        this.libs = [];
    }

    async main(argv) {
        super.main(argv);
        await this.initData();
        this._createWindow(argv);
    }

    async initData() {
        const typesDir = "C:/system/local/share/monaco/types";

        if(!(await FS.exists(typesDir)))
            await FS.mkdir(typesDir);
        
        const idleProg = MsgBoxSimple.idleProgress("Loading libraries", "Importing typings...");

        for(let t of (await FS.readdir(typesDir))) {
            if(t.toLowerCase().endsWith(".ts")) {
                this.libs.push({
                    name: `ts:int/${FSUtil.fname(t)}`,
                    content: await FS.readstr(t)
                });
            }
        }

        idleProg.closeDialog();
    }

    async _createWindow(argv) {
        var params = new WindowParams();
        params.title = "Monaco";
        params.initialWidth = 620;
        params.initialHeight = 440;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`
        <div class="appbar"></div>
        <iframe src="/system/apps/monaco/"></iframe>
        <footer class="w96-footer">
            <div class="cell">
                <none>
            </div>
        </footer>
        `);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('monaco-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/monaco", '16x16'));

        const appBar = new MenuBar();
        
        appBar.addRoot("File", [
            { type: "normal", label: "New", onclick: ()=>{
                this.newDocumentUI();
            }},
            { type: "separator" },
            { type: "normal", label: "Open", onclick: ()=>{
                this.openDocumentDialog();
            }},
            { type: "normal", label: "Save", onclick: async ()=>{
                await this.saveDocumentDialog();
            }},
            { type: "normal", label: "Save As", onclick: async ()=>{
                await this.saveDocumentDialog(true);
            }},
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{
                if(this.documentModified) 
                    MsgBoxSimple.confirm("Are you sure? The current document is not saved yet!", (vx)=>{if(vx) this.mainwnd.close(); }, "warning");
                else
                    this.mainwnd.close();
            }}
        ]);

        appBar.addRoot("View", [
            {
                type: "submenu",
                label: "Themes",
                items: [
                    { type: "normal", label: "Dark", onclick: ()=>this.switchTheme("vs-dark") },
                    { type: "normal", label: "Light", onclick: ()=>this.switchTheme("vs-light") },
                    { type: "normal", label: "High Contrast Dark", onclick: ()=>this.switchTheme("hc-black") },
                ]
            }
        ], false);

        appBar.addRoot("Document", [
            {
                type: "submenu",
                label: "Language",
                items: [
                    { type: "normal", label: "Batch", onclick: ()=>this.switchLang("bat") },
                    { type: "normal", label: "C / C++", onclick: ()=>this.switchLang("c") },
                    { type: "normal", label: "CSS", onclick: ()=>this.switchLang("css") },
                    { type: "normal", label: "HTML", onclick: ()=>this.switchLang("html") },
                    { type: "normal", label: "INI", onclick: ()=>this.switchLang("ini") },
                    { type: "normal", label: "JavaScript", onclick: ()=>this.switchLang("js") },
                    { type: "normal", label: "JSON", onclick: ()=>this.switchLang("json") },
                    { type: "normal", label: "Lua", onclick: ()=>this.switchLang("lua") },
                    { type: "normal", label: "Markdown", onclick: ()=>this.switchLang("md") },
                    { type: "normal", label: "Python", onclick: ()=>this.switchLang("py") },
                    { type: "normal", label: "TypeScript", onclick: ()=>this.switchLang("ts") },
                    { type: "normal", label: "YAML", onclick: ()=>this.switchLang("yaml") },
                    { type: "separator" },
                    { type: "normal", label: "Plain Text", onclick: ()=>this.switchLang("plain") }
                ]
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Document Info",
                onclick: ()=>this.appFrame.contentWindow.showDocInfo()
            }
        ], false);

        appBar.addRoot("Tools", [
            {
                type: "normal",
                label: "Preview in Browser",
                onclick: async ()=>{
                    const randFn = rand(0,  1000000) + ".html";
                    const randPath = "c:/system/temp/" + randFn;

                    await FS.writestr(randPath, this.appFrame.contentWindow.editor.getValue());
                    execCmd("internete", [randPath]);
                }
            },
            { type: "separator" },
            {
                type: "normal",
                label: "Edit Monaco Config",
                onclick: ()=>{
                    MsgBoxSimple.confirm("Are you sure? Please save any changes first.", (v)=>{
                        if(v)
                            this.loadDocument("c:/user/appdata/Monaco/config.json");
                    }, "warning");
                }
            }
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "About", onclick: ()=>{
                MsgBoxSimple.info ("About Monaco", '<span class="bold-noaa">Monaco Editor</span><br>Version 1.1<br><br>Powered by <a href="https://github.com/microsoft/monaco-editor">Microsoft Monaco Editor</a>', "OK").dlg.setSize(320, 140);
            }}
        ]);

        const appFrame = mainwnd.wndObject.querySelector("iframe");

        appFrame.onload = ()=>{
            // Call app main from iframe
            appFrame.contentWindow.app(w96, u96, this, (editor)=>{
                appFrame.contentDocument.addEventListener('click', ()=>document.body.onclick({ target: this.appWindow.wndObject }));

                wContainer.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

                if(argv[1] == null)
                    this.newDocument();
                else
                    this.loadDocument(argv[1]);
            });
        }

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        this.currentDocument = null;
        this.lastPath = "c:/";
        this.documentModified = false;

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        mainwnd.onclose = (e)=>{
            if(this.documentModified) {
                e.canceled = true;

                MsgBoxSimple.confirm("Are you sure? The current document is not saved yet!", (vx)=>{
                    if(vx) {
                        this.documentModified = false;
                        mainwnd.close();
                    } else {

                    }
                }, "warning");
            }
            else
                return;
        }

        // Start the app
        mainwnd.show();        
    }

    newDocument() {
        this.mainwnd.setTitle("Untitled - Monaco");
        this.appFrame.contentWindow.editor.setValue("");
        this.appFrame.contentWindow.switchLang("plain");
        this.mainwnd.wndObject.querySelector(".w96-footer>.cell").textContent = "<untitled document>";
        this.currentDocument = null;
        this.setDocumentModified(false);
    }

    updateTitle() {
        let fn = (this.currentDocument == null) ? "Untitled" : FSUtil.fname(this.currentDocument);
        this.mainwnd.setTitle((this.documentModified ? "*" : "") + fn + " - Monaco");
    }

    setDocumentModified(v) {
        if(this.documentModified === v)
            return;

        this.documentModified = v;
        this.updateTitle();
    }

    checkReadOnly(path) {
        if(!path)
            return false;

        const dp = FSUtil.deconstructFullPath(path);
        const fs = FS.get(dp.prefix);
        return fs.features.includes(FSFeatures.readOnly);
    }

    /**
     * Switches themes.
     * @param {string} thName The theme name to use.
     */
    switchTheme(thName) {
        this.appFrame.contentWindow.switchTheme(thName);
    }

    switchLang(lang) {
        this.appFrame.contentWindow.switchLang(lang);
    }

    async loadDocument(path) {
        if((!await FS.exists(path)) || (!await FS.isFile(path))) {
            MsgBoxSimple.error("Error", "Cannot load file.", "OK");
            this.newDocument();
            return;
        }

        const contents = await FS.readstr(path);
        this.appFrame.contentWindow.editor.setValue(contents);
        this.appFrame.contentWindow.assumeLangFromExt(path);
        this.mainwnd.setTitle(FSUtil.fname(path) + " - Monaco");
        this.mainwnd.wndObject.querySelector(".w96-footer>.cell").textContent = path;
        this.currentDocument = path;
        this.lastPath = FSUtil.getParentPath(path);

        if(this.lastPath.length == 2)
            this.lastPath += "/";

        this.setDocumentModified(false);
    }

    async saveDocumentDialog(saveNew) {
        if(this.checkReadOnly(this.currentDocument)) {
            MsgBoxSimple.error("Error saving document", "This document is stored in a read-only location.", "OK");
            return;
        }

        if((this.currentDocument == null) || saveNew) {
            // Show save as dialog
            new SaveFileDialog(this.lastPath, [/.*/], async (v)=>{
                if((!v) || (v.trim() == "")) return;

                this.currentDocument = v;
                await FS.writestr(this.currentDocument, this.appFrame.contentWindow.editor.getValue());
                this.lastPath = FSUtil.getParentPath(v);
                this.appFrame.contentWindow.assumeLangFromExt(v);
                this.mainwnd.setTitle(FSUtil.fname(v) + " - Monaco");
                this.setDocumentModified(false);

                if(this.lastPath.length == 2)
                    this.lastPath += "/";
            }).show();
            return;
        }

        // Just save the file
        await FS.writestr(this.currentDocument, this.appFrame.contentWindow.editor.getValue());
        this.setDocumentModified(false);
    }

    openDocumentDialog() {
        new OpenFileDialog(this.lastPath, [/.*/], async (v)=>{
            if((!v) || (v.trim() == "")) return;

            if((await FS.stat(v)).length > 1048576) {
                MsgBoxSimple.confirm("The file is larger than 1 MB. Continue loading? (you may suffer)", (v2)=>{
                    if(v2) {
                        if(this.documentModified) 
                            MsgBoxSimple.confirm("Are you sure? The current document is not saved yet!", (vx)=>{if(vx) this.loadDocument(v) }, "warning");
                        else
                            this.loadDocument(v);
                    }
                }, "warning");
            } else {
                if(this.documentModified) 
                    MsgBoxSimple.confirm("Are you sure? The current document is not saved yet!", (vx)=>{if(vx) this.loadDocument(v) }, "warning");
                else
                    this.loadDocument(v);
                //this.loadDocument(v);
            }
        }).show();
    }

    newDocumentUI() {
        if(this.documentModified) 
            MsgBoxSimple.confirm("Are you sure? The current document is not saved yet!", (v)=>{ if(v) this.newDocument() }, "warning");
        else
            this.newDocument();
    }

    ontermination() {
        super.ontermination();
    }
}