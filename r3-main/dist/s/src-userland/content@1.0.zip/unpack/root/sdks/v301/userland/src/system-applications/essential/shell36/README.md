# Shell36

Shell36 is the new shell for Windows 96 Release 3.0.