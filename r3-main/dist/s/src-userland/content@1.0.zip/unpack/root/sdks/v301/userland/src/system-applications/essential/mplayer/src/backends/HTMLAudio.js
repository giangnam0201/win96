/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

// maybe i should see if i can merge the audio and video one together but Lol i've had enough for now
class MPlayer_HTMLAudio {
    // The names are here since I will be adding them to the "devices" dropdown
    static backendName = "HTML Audio";

    static fileExtensions = [
        "mp3",
        "ogg",
        "flac",
        "wav",
        "opus"
    ];

    constructor() {
        this._player = new Audio();
        this._fileName = null;
        this._fileURL = null;
        this._hookEvents();
    }

    getVideoElement() {
        return null;
    }

    _hookEvents() {
        // this is fuck
        this._player.onloadeddata = e => { if (this.onloaded) this.onloaded(e); };

        this._player.onplay = e => { if (this.onplay) this.onplay(e); };
        this._player.onpause = e => { if (this.onpause) this.onpause(e); };
        this._player.onended = e => { if (this.onended) this.onended(e); };
        this._player.onerror = e => { if (this.onerror) this.onerror(e); };

        this._player.ondurationchange = e => { if (this.ondurationchange) this.ondurationchange(this._player.duration, e); };
        this._player.ontimeupdate = e => { if (this.ontimeupdate) this.ontimeupdate(this._player.currentTime, e); };
        this._player.onvolumechange = e => { if (this.onvolumechange) this.onvolumechange(this._player.volume, e); };
    }

    load(src) {
        if (!src)
            throw new Error("File to load has not been specified");

        /**
         * Haha nested async (end me)
         */
        return new Promise(async (resolve, reject) => {
            const fileExt = FSUtil.getExtension(src).toLowerCase().substring(1);

            URL.revokeObjectURL(this._fileURL);

            if (this.constructor.fileExtensions.includes(fileExt)) {
                this._player.addEventListener('canplaythrough', resolve, { once: true });
                this._fileName = FSUtil.fname(src);
                this._fileURL = URL.createObjectURL(await FS.toBlob(src));

                this._player.src = this._fileURL;
            } else {
                throw new Error("Unsupported file type: " + fileExt);
            }
        });
    };

    play() {
        this._player.play();
    };

    pause() {
        this._player.pause();
    }

    stop() {
        this._player.pause();
        this._player.currentTime = 0;
    }

    time(seconds) {
        if (typeof seconds == "number")
            this._player.currentTime = seconds;

        return this._player.currentTime;
    }

    volume(value) {
        if (typeof value == "number" && value <= 1.00)
            this._player.volume = value;

        return this._player.volume;
    }

    duration() {
        return this._player.duration;
    }

    getName() {
        return this._fileName;
    }

    state() {
        if (this._player.ended)
            return 3; // Media finished
        else if (this._player.paused && this._player.currentTime !== 0)
            return 2; // Media paused
        else if (!this._player.paused)
            return 1; // Media playing
        else
            return 0; // Media hasn't started?
    }

    playbackRate(rate) {
        if (rate)
            this._player.playbackRate = rate;

        return this._player.playbackRate;
    }

    unload() {
        this._player.pause();
        this._player.removeAttribute("src");
        this._player.load();

        URL.revokeObjectURL(this._fileURL);
    }
}
