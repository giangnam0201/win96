/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { CheckBox, ExplorerAddressBar, TabControl,
        FSView, GraphStatBox, GroupBox, ListBox } = w96.ui.components;

const { MenuBar, Theme } = w96.ui;

const APP_STYLE = `
<style>
.ui-control-tester-app {
    background: rgb(116 116 116);
}

.ui-control-tester-app>.test-panel {
    /* todo */
    flex: 1;
    display: flex;
}

.ui-control-tester-app>.top {
    padding: 5px;
    box-sizing: border-box;
    background: rgb(192, 192, 192);
}

.ui-control-tester-app>.top>select {
    width: 100%;
}

.ui-control-tester-app>.test-panel>.component-view {
    margin: auto;
    box-shadow: 2px 2px black;
    max-width: 90%;
    max-height: 90%;
    background: rgb(192, 192, 192);
}

.ui-control-tester-app>.w96-footer {
    background: rgb(192, 192, 192);
}
</style>`;

const uiControls = [
    {
        name: "Button",
        init: function() {
            const b = document.createElement('button');
            b.style.margin = "8px";
            b.classList.add('w96-button');
            b.textContent = "Sample Text";
            return b;
        }
    },
    {
        name: "CheckBox",
        init: function() {
            return new CheckBox().getElement();
        }
    },
    {
        name: "ExplorerAddressBar",
        areaClassName: "wexplorer-app",
        init: function() {
            return new ExplorerAddressBar().getElement();
        }
    },
    {
        name: "Footer (Status Bar)",
        init: function() {
            const el = document.createElement('footer');
            el.classList.add('w96-footer');
            el.style.width = "150px";
            el.textContent = "Status Bar";
            return el;
        }
    },
    {
        name: "FSView",
        init: async function() {
            const fsv = new FSView("C:/", true);
            await fsv.init();
            const el = fsv.getElement();
            el.style.width = "300px";
            el.style.height = "200px";
            fsv.navigate("C:/");
            return el;
        }
    },
    {
        name: "GraphStatBox",
        init: async function() {
            const gsbox = new GraphStatBox({
                ondata: ()=>Math.floor(Math.random() * 100)
            });

            gsbox.init();

            return gsbox.getElement();
        }
    },
    {
        name: "GroupBox",
        init: async function() {
            const gbox = new GroupBox({
                title: "Group Box Title"
            });

            const el = gbox.getElement();
            el.style.margin = "1em";

            el.querySelector(".content").appendChild(new CheckBox().getElement());
            el.querySelector(".content").appendChild(document.createElement('br'));
            el.querySelector(".content").appendChild(new CheckBox().getElement());
            el.querySelector(".content").appendChild(document.createElement('br'));
            el.querySelector(".content").appendChild(new CheckBox().getElement());
            
            return el;
        }
    },
    {
        name: "Inset Separator",
        init: async function() {
            const el = document.createElement('div');
            el.classList.add('w96-ui-inset-separator');
            el.style.width = "150px";
            el.style.margin = "8px";
            return el;
        }
    },
    {
        name: "ListBox",
        init: async function() {
            const listBox = new ListBox();

            for(let x = 0; x < 25; x++)
                listBox.addItem(`Item #${x}`, x);

            const el = listBox.getElement();

            el.style.width = "250px";
            el.style.height = "250px";

            return el;
        }
    },
    {
        name: "MenuBar",
        init: async function() {
            const mbar = new MenuBar();

            mbar.addRoot("File", [
                {
                    type: "normal",
                    label: "New",
                    onclick:()=>{}
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Open",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Save",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Save As",
                    onclick:()=>{}
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Exit",
                    onclick:()=>{}
                }
            ]);

            mbar.addRoot("Edit", [
                {
                    type: "normal",
                    label: "Undo",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Redo",
                    onclick:()=>{}
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Cut",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Copy",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Paste",
                    onclick:()=>{}
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Select All",
                    onclick:()=>{}
                }
            ]);

            mbar.addRoot("Format", [
                {
                    type: "normal",
                    label: "Font...",
                    onclick:()=>{}
                }
            ]);

            mbar.addRoot("View", [
                {
                    type: "submenu",
                    label: "Zoom",
                    items: [
                        {
                            type: "normal",
                            label: "50%",
                            onclick: ()=>{}
                        },
                        {
                            type: "normal",
                            label: "75%",
                            onclick: ()=>{}
                        },
                        {
                            type: "normal",
                            label: "100%",
                            onclick: ()=>{}
                        },
                        {
                            type: "normal",
                            label: "150%",
                            onclick: ()=>{}
                        },
                        {
                            type: "normal",
                            label: "200%",
                            onclick: ()=>{}
                        },
                        {
                            type: "normal",
                            label: "500%",
                            onclick: ()=>{}
                        }
                    ]
                }
            ], false);

            mbar.addRoot("Window", [
                {
                    type: "normal",
                    label: "Cascade",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Tile Vertical",
                    onclick:()=>{}
                },
                {
                    type: "normal",
                    label: "Tile Horizontal",
                    onclick:()=>{}
                }
            ]);

            mbar.addRoot("Help", [
                {
                    type: "normal",
                    label: "Help Topics",
                    onclick:()=>{}
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "About Sample Software...",
                    onclick:()=>{}
                }
            ]);

            return mbar.getMenuDiv();
        }
    },
    {
        name: "TabControl",
        init: function() {
            const tab = new TabControl();

            tab.openPage(tab.addPage("Page 1", (e)=>{
                e.appendChild(new Text("Internet"));
            }));

            tab.addPage("Page 2", (e)=>{
                e.appendChild(new Text("The cake was a lie"));
            })

            const el = tab.getElement();

            // Set some minimums
            el.style.minWidth = "220px";
            el.style.minHeight = "230px";

            return el;
        }
    },
    {
        name: "TextBox",
        init: function() {
            const tb = document.createElement('input');
            tb.type = "text";
            tb.classList.add('w96-textbox');
            tb.style.width = "150px";
            tb.style.margin = "8px";
            tb.value = "Sample text";
            return tb;
        }
    },
];

/**
 * Initializes the component area.
 * @param {HTMLDivElement} compArea The component area to initialize
 * @param {String} controlName The name of the control to add.
 */
async function initComponentArea(compArea, controlName) {
    // Remove elements

    while(compArea.firstChild)
        compArea.removeChild(compArea.firstChild);

    // Set class name
    compArea.className = "component-view";

    const uic = uiControls.find(x => x.name == controlName);

    if(uic.areaClassName)
        compArea.classList.add(uic.areaClassName);

    compArea.appendChild(await uic.init());
}

class UIComponentTestApp extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);
        
        const mainwnd = this.createWindow({
            title: "UI Component Tester Devtool",
            body: `${APP_STYLE}
            <div class="top">
                <select class="w96-textbox controls"></select>
            </div>
            <div class="test-panel w96-inset">
                <div class="component-view"></div>
            </div>
            <footer class="w96-footer">
                Component Size: <span class="comp-size">null</span>
            </footer>`,
            bodyClass: 'ui-control-tester-app',
            taskbar: true,
            initialHeight: 430,
            initialWidth: 450
        }, true);

        await mainwnd.setWindowIcon(await Theme.getIconUrl("C:/system/sdk/v3-1.0b/res/icons/uictest-16.png"));

        /** @type {HTMLDivElement}  */
        const body = mainwnd.getBodyContainer();
        const select = body.querySelector("select");

        this.body = body;

        // Populate select box
        for(let control of uiControls) {
            const optionEl = document.createElement('option');
            optionEl.value = control.name;
            optionEl.textContent = control.name;
            select.appendChild(optionEl);
        }
        
        // Assign events
        select.onchange = (e)=> {
            initComponentArea(body.querySelector(".component-view"), uiControls[select.selectedIndex].name).then(()=>this.updateStatus());
        }

        await initComponentArea(body.querySelector(".component-view"), uiControls[0].name);
        this.updateStatus();

        mainwnd.show();
    }

    updateStatus() {
        const cz = this.body.querySelector(".component-view").getBoundingClientRect();
        this.body.querySelector(".comp-size").textContent = `${cz.width}x${cz.height}`;
    }
}
