/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, SaveFileDialog, DialogCreator, Theme, MenuBar } = w96.ui;
const { TreeView } = w96.ui.components;

class DevMgrApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(document.querySelector(".devmgr-app"))
            return;

        const mainwnd = this.createWindow({
            title: "Device Manager",
            icon: await Theme.getIconUrl("apps/devmgr", '16x16'),
            taskbar: true,
            initialWidth: 530,
            initialHeight: 400,
            bodyClass: "devmgr-app",
            body: `
            <div class="appbar"></div>
            <div class="tree w96-tree" style="height: 100%;"></div>
            <footer class="w96-footer">
                <div class="cell">
                    No errors found
                </div>
            </footer>
            `
        }, true);

        const body = mainwnd.getBodyContainer();
        const appbar = new MenuBar();

        appbar.addRoot("File", [
            {
                type: "normal",
                label: "Save Report",
                onclick: ()=>new SaveFileDialog("c:/user/documents", [], async(v)=>{
                    if((v != null) && (v.trim() != "")) {
                        await FS.writestr(v, `
Device Manager Report
Generated at ${new Date()}
=====================
Monitor: ${(await this.getMonitor())[0].label}
CPU: ${(await this.getCPU())[0].label}
GPU: ${await this.getGPU()}
Mounted Disks:
${FS.list().join('\n')}`);

                        DialogCreator.create({
                            body: "Report has been generated.",
                            title: "Information",
                            icon: "info"
                        });
                    }
                }).show()
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>mainwnd.close()
            }
        ]);

        appbar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>DialogCreator.alert('<span class="bold-noaa">Device Manager</span><br>Version 1.0<br>', {
                    title: "About Device Manager",
                    icon: "info"
                })
            }
        ]);

        body.querySelector(".appbar").replaceWith(appbar.getMenuDiv());

        const statusBox = MsgBoxSimple.status("Device Manager", "Computing resources...");
        statusBox.show();

        body.querySelector(".tree").replaceWith(new TreeView([{
            label: "Computer",
            icon: await Theme.getIconUrl("devices/computer", '16x16'),
            items: [
                {
                    label: "File System Interfaces",
                    icon: await Theme.getIconUrl("mime/executable", '16x16'),
                    opened: false,
                    items: await this.computeAvailableFSDrivers()
                },
                {
                    label: "GPU",
                    icon: await Theme.getIconUrl("devices/card", '16x16'),
                    opened: false,
                    items: [
                        {
                            label: await this.getGPU(),
                            icon: await Theme.getIconUrl("devices/card", '16x16')
                        }
                    ]
                },
                {
                    label: "Monitors",
                    icon: await Theme.getIconUrl("devices/monitor", '16x16'),
                    opened: false,
                    items: await this.getMonitor()
                },
                {
                    label: "Processors",
                    icon: await Theme.getIconUrl("devices/cpu", '16x16'),
                    opened: false,
                    items: await this.getCPU()
                },
                {
                    label: "Volumes",
                    icon: await Theme.getIconUrl("devices/hdd", '16x16'),
                    opened: false,
                    items: await (async ()=>{
                        const volumes = [];
                        for (let volume of FS.list()) {
                            volumes.push({
                                icon: await Theme.getIconUrl("devices/hdd", '16x16'),
                                label: volume
                            });
                        }
                        return volumes;
                    })()
                }
            ],
            opened: true
        }]).getElement());

        statusBox.close();

        mainwnd.show();
    }

    async computeAvailableFSDrivers() {
        const items = [];

        if(typeof window.indexedDB !== 'undefined')
            items.push({ label: "Indexed Storage", icon: await Theme.getIconUrl("devices/hdd", '16x16') });

        if(typeof window.localStorage !== 'undefined')
            items.push({ label: "Local Storage", icon: await Theme.getIconUrl("devices/floppy", '16x16') });

        items.push({ label: "In-memory Storage", icon: await Theme.getIconUrl("devices/memory", '16x16') });

        return items;
    }

    async getGPU() {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl');

        try {
            let renderer = gl.getParameter(gl.RENDERER);

            /**
             * Apparently, WEBGL_debug_renderer_info is deprecated and
             * you have to use gl.RENDERER. However for some reason WebKit
             * reports itself as "WebKit WebGL" using gl.RENDERER, but not
             * with WEBGL_debug_renderer_info. So.. here's that bad check.
             */
            if(renderer === 'WebKit WebGL') {
                const glExtInfo = gl.getExtension("WEBGL_debug_renderer_info");

                if(glExtInfo && (glExtInfo.UNMASKED_RENDERER_WEBGL)) {
                    return gl.getParameter(glExtInfo.UNMASKED_RENDERER_WEBGL);
                }
            } else {
                return renderer;
            }
        } catch(e) {
            // Error, return unknown GPU
        }

        return "Unknown GPU";
    }

    async getCPU() {
        return [{
            label: "Generic Processor with " + (navigator.hardwareConcurrency) + " logical processors",
            icon: await Theme.getIconUrl("devices/cpu", '16x16')
        }];
    }

    async getMonitor() {
        if((!screen) || (!screen.width) || (!screen.height)) {
            return [{
                label: `Unknown Monitor`,
                icon: await Theme.getIconUrl("devices/monitor", '16x16')
            }];
        }

        return [{
            label: `Monitor (${screen.width * window.devicePixelRatio}x${screen.height * window.devicePixelRatio})`,
            icon: await Theme.getIconUrl("devices/monitor", '16x16')
        }];
    }
}