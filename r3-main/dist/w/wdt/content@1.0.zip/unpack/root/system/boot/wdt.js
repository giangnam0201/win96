// Set WDT PATH
w96.sys.env.setEnv("path", `${w96.sys.env.getEnv("path")};C:/sdks/v301/wdt/bin`);
