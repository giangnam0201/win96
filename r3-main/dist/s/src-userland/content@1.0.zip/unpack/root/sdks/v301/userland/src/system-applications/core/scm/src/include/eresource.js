/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const StyleCSS = {
    Main: `.scm-app>.container {
        flex: 1;
        flex-direction: row;
        display: flex;
        overflow: hidden;
        margin-bottom: 2px;
    }
    
    .scm-app>.container>.item-view {
        flex: 1;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        background: white;
        overflow: auto;
    }
    
    .scm-app>.container>.item-view>.shell-icon {
        top: 2px;
        left: 3px;
    }
    
    .scm-app>.container>.item-view>.shell-icon>.icon-text {
        color: black;
        text-shadow: none;
    }
    
    .scm-app>.container>.item-view>.shell-icon.selected>.icon-text
    {
        color: white;
    }
    
    .scm-app>.container>.preview {
        width: 200px;
        white-space: pre-line;
        padding: 5px;
        box-sizing: border-box;
        overflow: auto;
    }
    
    .scm-app .w96-toolbar>.item {
        min-width: 54px;
    }
    
    .scm-app .w96-toolbar>.item[disabled] {
        text-shadow: 1px 1px white;
        color: rgb(109, 109, 109);
    }
    
    .scm-app .w96-toolbar>.item[disabled]>.icon {
        filter: contrast(0) drop-shadow(1px 1px #fff);
    }
    
    .scm-app .w96-toolbar>.item>.icon {
        background-position: center;
        filter: grayscale(100%);
    }
    
    .scm-app .w96-toolbar>.item:not([disabled]):hover>.icon {
        filter: none;
    }`
}