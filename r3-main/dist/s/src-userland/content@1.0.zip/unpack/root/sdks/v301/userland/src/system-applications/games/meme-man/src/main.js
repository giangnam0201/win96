/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { rand } = w96.util;
const { ContextMenu, animateElement } = w96.ui;

/**
 * Meme man skins.
 */
const SKINS = [
    "skin1",
    "skin2",
    "skin3"
];

// Skin sizes
const SKIN_H = 180;
const SKIN_W = 180;

class MemeManApplication extends WApplication {
    constructor() {
        super();
        this.currentSkin = "";
        this.skinScale = 1;
    }

    async main(argv) {
        super.main(argv);
        await this._init();
    }

    async _init() {
        const mmEl = document.createElement('div');
        this.mmEl = mmEl;

        mmEl.className = "meme-man";
        mmEl.style.top = rand(0, window.innerHeight - this.getSkinH()) + "px";
        mmEl.style.left = rand(0, window.innerWidth - this.getSkinW()) + "px";
        mmEl.ondblclick = ()=>this.randomTp();
        mmEl.oncontextmenu = (e) => {
            // HACK
            try { document.body.onclick(); } catch(e) { }

            // Show ctx menu
            new ContextMenu([
                {
                    type: "normal",
                    label: "Cycle Skin",
                    onclick: ()=>this.cycleSkin()
                },
                { type: "separator" },
                {
                    type: "submenu",
                    label: "Movement",
                    items: [
                        {
                            type: "normal",
                            label: "Teleport",
                            onclick: ()=>this.randomTp()
                        }
                    ]
                },
                {
                    type: "submenu",
                    label: "Scale",
                    items: [
                        { type: "normal", label: "1x", onclick: ()=>this.setScale(1) },
                        { type: "normal", label: "1.25x", onclick: ()=>this.setScale(1.25) },
                        { type: "normal", label: "1.5x", onclick: ()=>this.setScale(1.5) },
                        { type: "normal", label: "1.75x", onclick: ()=>this.setScale(1.5) },
                        { type: "normal", label: "2x", onclick: ()=>this.setScale(2) }
                    ]
                },
                { type: "separator" },
                {
                    type: "normal",
                    label: "Quit",
                    onclick: ()=>this.terminate()
                }
            ]).renderMenu(e.x, e.y);
        };

        $(mmEl).draggable();
        this.switchSkin(SKINS[0]);
        document.querySelector("#maingfx").appendChild(mmEl);
    }

    /**
     * Switches the meme man skin.
     * @param {string} sName The skin name.
     */
    switchSkin(sName) {
        this.mmEl.className = `meme-man ${sName}`;
        this.currentSkin = sName;
    }

    /**
     * Randomly teleport meme man.
     */
    randomTp() {
        animateElement(this.mmEl, "mm-zoomout", ()=>{
            this.mmEl.style.top = rand(0, window.innerHeight - this.getSkinH()) + "px";
            this.mmEl.style.left =  rand(0, window.innerWidth - this.getSkinW()) + "px";
            animateElement(this.mmEl, "mm-zoomin");
        });
    }

    /**
     * Cycles the skin.
     */
    cycleSkin() {
        // Get next skin
        let sIndex = SKINS.indexOf(this.currentSkin);
        let nextSkin = SKINS[sIndex + 1];

        if(nextSkin == null)
            nextSkin = SKINS[0];

        this.switchSkin(nextSkin);
    }

    /**
     * Gets the skin height.
     * @returns The skin height.
     */
    getSkinH() {
        return SKIN_H * this.skinScale;
    }

    /**
     * Gets the skin width.
     * @returns The skin width.
     */
    getSkinW() {
        return SKIN_W * this.skinScale;
    }

    /**
     * Sets the meme man scale.
     * @param {Number} scale The scale to use.
     */
    setScale(scale = 1) {
        if(scale < 1)
            throw new Error("Invalid scale.");

        this.skinScale = scale;
        this.mmEl.style.height = `${SKIN_H * this.skinScale}px`;
        this.mmEl.style.width = `${SKIN_W * this.skinScale}px`;
    }

    /**
     * Ran on program termination.
     */
    ontermination() {
        super.ontermination();
        this.mmEl.remove();
        this.mmEl = null;
    }
}