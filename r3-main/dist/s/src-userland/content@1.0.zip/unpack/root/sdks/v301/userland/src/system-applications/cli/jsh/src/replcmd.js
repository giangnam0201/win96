/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const alphaSort = (a, b) => {
    if(a > b) return 1;
    else if(a < b) return -1;
    return 0;
}

const REPL_COMMANDS = [
    {
        name: "clear",
        description: "Clears the screen",
        exec: (args, cmdLine, term)=>term.clear()
    },
    {
        name: "exit",
        description: "Quits this REPL shell.",
        exec: (args, cmdLine, term) => 255
    },
    {
        name: "load",
        args: "<path>",
        description: "Loads the specified file into the current shell.",
        exec: async(args, cmdLine, term) => {
            const fileName = cmdLine.substring(REPL_CMD_PREFIX.length + args[0].length);
            const resolvedPath = FSUtil.resolvePath(current.cwd, fileName);

            term.println(term.color`{hex('#afffaf') Loading file "${resolvedPath}"}`);

            const fileContents = await FS.readstr(resolvedPath);
            let e = eval(fileContents);
            if (e instanceof Promise) e = await e;
            e = inspect(e, {depth: 1, colors: true});
            term.writeln(e);
        }
    },
    {
        name: "help",
        description: "Shows this help message",
        exec: (args, cmdLine, term) => {
            term.println(term.color`{hex('#87d700') JS Shell (jsh) Commands List}`);

            for(let cmd of REPL_COMMANDS.sort(alphaSort))
                term.println(term.color`  {hex('#af5fff') ${REPL_CMD_PREFIX}${cmd.name}}${(cmd.args == null) ? '' : term.color` {hex('#ffff00') ${cmd.args}}`}: ${cmd.description}`);

            term.println('');
        }
    }
]