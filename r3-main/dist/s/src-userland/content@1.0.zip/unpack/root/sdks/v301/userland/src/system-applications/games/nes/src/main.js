/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { MenuBar, OpenFileDialog, SaveFileDialog, MsgBoxSimple, Theme } = w96.ui;

class NESEmulatorApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        
        if(argv[1] == null) {
            new OpenFileDialog("c:/", ["nes", "NES"], (fn)=>{
                if(!fn) {
                    this.terminate();
                    return;
                }
                this._createWindow(fn);
            }).show();
            return;
        }

        await this._createWindow(argv[1]);
    }

    showOpenRomDialog() {
        new OpenFileDialog("c:/", ["nes", "NES"], async (fn)=>{
            if(this._fnUrl)
                URL.revokeObjectURL(this._fnUrl);
            
            this._fnUrl = URL.createObjectURL(await FS.toBlob(fn));
            
            this.appFrame.onload = ()=> {
                this.appFrame.contentWindow.app.init(this, this.mainwnd, this._fnUrl);
            }
            this.appFrame.contentDocument.location.reload();
        }).show();
    }

    async _createWindow(fn) {
        // Transform to blob url
        var params = new WindowParams();
        params.title = FSUtil.fname(fn) + " - NES";
        params.initialWidth = 256;
        params.initialHeight = 281;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<div class="appbar"></div><iframe src="/system/apps/nes"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('nes-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/nes", '16x16'));

        // Create menubar
        const appBar = new MenuBar();
        
        appBar.addRoot("File", [
            { type: "normal", label: "Open ROM", onclick: ()=>{
                this.showOpenRomDialog();
            } },
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{
                this.terminate();
            }}
        ]);

        appBar.addRoot("Scale", [
            { type: "normal", label: "Stretch", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode(""); }},
            { type: "normal", label: "Zoom", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode("zoom-scale"); }},
            { type: "normal", label: "Pixel Perfect", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode("pixel-perfect"); }}
        ]);

        appBar.addRoot("Debug", [
            { type: "normal", label: "Dump Memory", onclick: ()=>{ 
                const memDump = Array.from(this.appFrame.contentWindow.app.nes.cpu.mem);
                const sfd = new SaveFileDialog("c:/", ["mem"], async (fn)=>{
                    if(!fn)
                        return;

                    await FS.writebin(fn, memDump);
                });

                sfd.show();
                sfd.fileBox.value = "Dump_" + (new Number(new Date())+0).toString() + ".mem";
            }},
            { type: "normal", label: "Load Dump", onclick: ()=>{ 
                new OpenFileDialog("c:/", ["mem"], async (fn)=>{
                    if(!fn)
                        return;
                    
                    this.appFrame.contentWindow.app.nes.cpu.mem = Array.from(await FS.readbin(fn));
                }).show();
            }}
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "Controls", onclick: ()=>{
                w96.ui.MsgBoxSimple.info ("Controls", '<span class="bold-noaa">Controls</span><br>a =&gt; A<br>s =&gt; B<br>Arrow Keys =&gt; DPAD<br>Enter =&gt; START<br>Tab =&gt; SELECT', "OK").dlg.setSize(320, 170);
            } },
            { type: "separator" },
            { type: "normal", label: "About", onclick: ()=>{
                w96.ui.MsgBoxSimple.info ("About NES", '<span class="bold-noaa">NES Emulator</span><br>Version 1.0<br><br>Powered by <a href="https://github.com/bfirsh/jsnes">JSNES</a>', "OK").dlg.setSize(320, 140);
            }}
        ])

        wContainer.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        // Create app frame

        const appFrame = mainwnd.wndObject.querySelector("iframe");
        const objectUrl = URL.createObjectURL(await FS.toBlob(fn));
        this._fnUrl = objectUrl;

        appFrame.onload = ()=> {
            appFrame.contentWindow.app.init(this, mainwnd, objectUrl);
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }

    async ontermination() {
        await super.ontermination();
        URL.revokeObjectURL(this._fnUrl);
    }
}