/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Shell command.
 * @param {SCMCApp} app App instance.
 * @param {String[]} argv Program arguments.
 */
async function cmd_Shell(app, argv) {
    let isRunning = true;

    while(isRunning) {
        let str = await term.prompt("scmc> ");
        const args = argParser.parse(str);

        // Internal command list structure
        switch(args[0]) {
            case "help":
                term.println("scmc Commands:");
                term.println(`    ${commandRegistry.map(x => `${x.name}${x.usage}`).join("\n    ")}\n`);
                term.println("Shell Commands:");
                term.println(`    clear - Clear the screen.\n    exit - Exits the shell.\n    help - This page.\n`);
                continue;
            case "clear":
                term.clear();
                continue;
            case "exit":
                isRunning = false;
                break;
        }

        // Break
        if(!isRunning)
            break;

        // Look for cmd
        const cmd = commandRegistry.find(x => x.name == args[0]);

        if(!cmd)
            term.println("Error: command not found.");
        else
            await cmd.exec(this, args) ?? 0;
    } 
}