/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Taskbar, NotifyIcon } = w96.shell;
const { flags: Flags, execCmd, execFile, MobileDeviceConfiguration, loader: Loader } = w96.sys;
const { WindowSystem, sysConf: SCM } = w96;
const { klog, gfxEl, cover } = current.boxedEnv;
const { FSView } = w96.ui.components;
const { Theme, MsgBoxSimple, ContextMenu, OpenFileDialog, DialogCreator } = w96.ui;
const { escapeHtml, argParser: ArgParser, blobToDataURI } = w96.util;

$$Include("./include/defaults.js")
$$Include("./include/start/utils.js")
$$Include("./include/start/startmenu.js")
$$Include("./include/taskbar/notify.js")
$$Include("./include/taskbar/setup.js")
$$Include("./include/ui/dialogs.js")
$$Include("./include/dom/explorer.js")

/**
 * Windows 96 default shell program.
 */
class ShellApplication extends WApplication {
    constructor() {
        super();
        
        /**
         * The current desktop configuration.
         */
        this.desktopConfiguration = {
            ...DESKTOP_CONFIG_DEFAULT
        }

        /**
         * Current desktop state
         */
        this.state = {
            // Selected icons are handled by FS View - We do not have to worry about it here.
            iconPositions: [], // Icon position registry
            reloading: false
        }

        this.ipcEq = this.registerIpcEQ("shell36");
    }

    /**
     * Constructs the shell DOM.
     */
    async constructDOM() {
        setupTaskbar();
        await setupIconDesktop();

        // Add taskbar to GFX element
        gfxEl.appendChild(fsView.getElement());
        gfxEl.appendChild(taskbar);
    }

    /**
     * Loads the desktop configuration
     */
    async loadConfiguration() {
        // Create desktop folder if it does not exist
        if(!await FS.exists("c:/user/desktop"))
            await FS.mkdir("c:/user/desktop");

        klog.println_styled("[desktop] Initializing desktop shell...", 'color: orchid');
        klog.println_styled("[desktop] Reading desktop configuration file at c:/system/config/desktop.json");

        // Load the desktop configuration file.
        if(!await FS.exists("c:/system/config/desktop.json")) {
            klog.println_styled(">> No valid desktop configuration found, creating one...", 'color: yellow');

            await FS.mkdir("c:/system/config");
            await FS.writestr("c:/system/config/desktop.json", JSON.stringify(this.desktopConfiguration));

            klog.println("[desktop] Wrote default configuration file successfully.");
        } else {
            try {
                this.desktopConfiguration = JSON.parse(await FS.readstr("c:/system/config/desktop.json"));
            } catch(e) {
                klog.warn("An invalid configuration file was loaded, sticking with default until user repairs configuration file.");
            }
        }

        // Load start menu items from SCM
        smConfig = SCM.get("Software/Shell36/StartMenu");

        if(smConfig == undefined) {
            smConfig = {... START_MENU_CONFIG };
            await SCM.setAndSync("Software/Shell36/StartMenu", smConfig);
        }

        // Register IPC events
        this.registerIPCEvents();
    }

    /**
     * Registers IPC events.
     */
    registerIPCEvents() {
        this.ipcEq.on('start-update', (cfg) => {
            if(!cfg)
                return;

            smConfig = cfg;
        });
    }

    /**
     * Applies the current desktop configuration.
     */
    async applyConfiguration() {
        const fsViewEl = fsView.getElement();
        const dc = this.desktopConfiguration;

        // Prep: if the background type won't be an iframe, remove the frame
        if(dc.background.type !== "iframe") {
            const ifr = document.querySelector('.ui-bg-iframe');

            if(ifr)
                ifr.remove();
        }

        // Do the checks
        switch(dc.background.type) {
            default:
                klog.warn("Background type '" + dc.background.type + "' is not recognized, switching to fallback...");
                dc.background.type = "css";
                dc.background.bg = "black";
                fsViewEl.style.background = dc.background.bg;
                break;
            case "css":
                fsViewEl.style.background = dc.background.bg;
                break;
            case "url":
                fsViewEl.style.background = `url(${dc.background.bg})`;
                break;
            case "local":
                if(!await FS.exists(dc.background.bg)) {
                    klog.warn("Cannot find local resource " + dc.background.bg + ", switching to fallback.");
                    dc.background = DESKTOP_CONFIG_DEFAULT.background;
                    await FS.writestr("c:/system/config/desktop.json", JSON.stringify(this.desktopConfiguration));
                } else {
                    try {
                        fsViewEl.style.backgroundImage = `url(${URL.createObjectURL(await FS.toBlob(dc.background.bg))})`;
                        fsViewEl.style.backgroundRepeat = "no-repeat";
                        fsViewEl.style.backgroundSize = "cover";
                    } catch(e) {
                        fsViewEl.style.background = `black`;
                    }
                }
                break;
            case "iframe":
                fsViewEl.style.background = "transparent";
    
                let bg_iframe = document.querySelector('.ui-bg-iframe');
    
                if(!bg_iframe)
                    bg_iframe = (function() {
                        const iframe = document.createElement('iframe');
                        iframe.classList.add('ui-bg-iframe');
                        gfxEl.appendChild(iframe);
                        return iframe;
                    })();
    
                bg_iframe.src = dc.background.bg;
                break;
        }
    }

    /**
     * Reloads the desktop.
     */
    async reloadDesktop() {
        if(this.state.reloading)
            return;
        else
            this.state.reloading = true; // Avoid double reloads

        // Create desktop folder if it does not exist
        // It could have been deleted by the user since last reload
        if(!await FS.exists("c:/user/desktop"))
            await FS.mkdir("c:/user/desktop");

        // Refresh trash icon status
        if(await FS.exists("C:/trash")) {
            const trashItems = await FS.readdir("C:/trash");

            // Remove meta item
            trashItems.forEach((v, i, a)=>{
                if(v == "C:/trash/.meta")
                    a.splice(i, 1);
            });

            // Check if trash is full
            for(let icon of specialIcons)
                if(icon.id == "trash")
                    if(trashItems.length > 0)
                        icon.icon = "places/trash-full";
                    else
                        icon.icon = "places/trash";
        }

        await fsView.navigate("c:/user/desktop", ()=>{
            const icons = fsView.getElement().querySelectorAll('.shell-icon');

            for(let icon of icons) {
                icon.ondblclick = ()=> {
                    const id = icon.getAttribute("ident");

                    if(id) {
                        // Special item switcher

                        switch(id) {
                            case "computer":
                                execCmd("explorer", ["computer://"]);
                                break;
                            case "trash":
                                execCmd("explorer", ["c:/trash"]);
                                break;
                            case "documents":
                                execCmd("explorer", ["c:/user/documents"]);
                                break;
                        }
                    }
                    else execFile(icon.getAttribute("path"));
                }
            }
            
        }, true);

        this.state.reloading = false;
    }

    /**
     * The entry point for the shell
     * @param {String[]} argv The arguments
     */
    async main(argv) {
        await super.main(argv);

        console.group("shell36");

        // Step 1. Load desktop configuration (wallpapers)
        console.log("Loading desktop configuration...");
        await this.loadConfiguration();
        
        // Step 2. Setup desktop DOM
        console.log("Constructing DOM...");
        await this.constructDOM();

        // Step 3. Setup events (desktop click deactivating windows)
        assignDesktopEvents();
        w96.evt.ui.on('reload-desktop', ()=>this.reloadDesktop());

        // Step 4. Load Window System
        Taskbar.assign(taskbar);
        WindowSystem.setWindowContainer(gfxEl);

        // Step 5. Load the desktop
        console.log("Initializing clock...");
        initializeClock();
        initializeErrorNotifyIcon();
        await this.applyConfiguration();

        console.log("Loading desktop...");
        await this.reloadDesktop();

        // Step 6. Apply mobile patches
        if(MobileDeviceConfiguration.isMobileModeEnabled()) {
            await MobileDeviceConfiguration.applyPatches();

            // Add SCM key if it doesn't exist
            if(SCM.get("Software/Shell36/CE") == undefined)
                await SCM.setAndSync("Software/Shell36/CE", true); // Enable CE mode by default

            if(SCM.get("Software/Shell36/CE"))
                await Loader.loadStyleAsync("/system/resource/stylesheets/ce.css");
        }

        // FS events
        /**
         * Handles FS events and updates the desktop if needed.
         */
        let fsEventHandler = ({ path }) => {
            if(this.state.reloading)
                return; // Block reload

            const normPath = FSUtil.normalizeDriveLetter(path);

            if(normPath.startsWith('C:/user/desktop') || normPath.startsWith('C:/user/desktop'))
                this.reloadDesktop();
        }

        w96.evt.fs.on('dir-create', fsEventHandler);
        w96.evt.fs.on('dir-remove', fsEventHandler);
        w96.evt.fs.on('touch', fsEventHandler);
        w96.evt.fs.on('file-write-string', fsEventHandler);
        w96.evt.fs.on('file-write-binary', fsEventHandler);
        w96.evt.fs.on('rm', fsEventHandler);

        console.groupEnd();

        // Shell events
        w96.evt.shell.on('config-modify', async (o)=> {
            if((!o) || (typeof o !== 'object'))
                throw new Error("Nothing to modify!");

            this.desktopConfiguration = {
                ...this.desktopConfiguration,
                ...o
            };

            // Save to desktop.json
            await FS.writestr("c:/system/config/desktop.json", JSON.stringify(this.desktopConfiguration));

            // Apply the changes
            await this.applyConfiguration();
        });

        w96.evt.shell.on('start-open', ()=>StartMenu.open());
        w96.evt.shell.on('start-close', ()=>StartMenu.close());

        await w96.shell.imde.init();

        // Inform kernel we are done.
        current.boxedEnv.shellCompleteCb();
        
        w96.evt.sys.once('init-complete', async ()=> {
            // Read through startup folder
            if(!await FS.exists("C:/system/startup"))
                await FS.mkdir("C:/system/startup");

            for(let i of await FS.readdir("C:/system/startup")) {
                try {
                    void execFile(i);
                } catch(e) {
                    console.error(`Startup Failure: ${e}`);
                }
            }
        });

        // Infinite wait to keep process from closing
        await new Promise((resolve)=>{ this._resolve = resolve; });
    }

    /**
     * On application termination.
     */
    async ontermination() {
        await super.ontermination();
        
        console.log("Shutting down shell...");

        if(typeof this._resolve === 'function') {
            this._resolve();
            this._resolve = null;
        }

        taskbar.remove();
        fsView.uiComponent.remove();
    }
}