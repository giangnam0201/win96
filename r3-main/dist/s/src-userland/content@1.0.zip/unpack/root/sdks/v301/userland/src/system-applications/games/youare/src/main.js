/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme } = w96.ui;

class YouAreApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this.isFirstWindow = true;
        this._createWindow();
    }

    async _createWindow() {
        var params = new WindowParams();
        params.title = "Trojan.JS.YouAreAnIdiot";
        params.initialWidth = this.isFirstWindow ? 640: 213;
        params.initialHeight = this.isFirstWindow ? 500: 178;
        params.controlBoxStyle = "WS_CBX_CLOSE";
        params.resizable = false;

        var mainwnd = this.createWindow(params, false);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<video style="height: 100%; width: 100%;" autoplay loop><source src="/system/apps/youare/vid.mp4" type="video/mp4"></video>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('gameing-app');
        wContainer.addEventListener('click', () => {
            alert('You are an idiot!');
            this._createWindow();
        });

        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/youare", '16x16'));

        mainwnd.onclose = e => {
            e.canceled = true;
            this._createWindow();
        }

        let incX = 2;
        let incY = 2;
        let x = ~~(Math.random() * document.body.clientWidth);
        let y = ~~(Math.random() * document.body.clientHeight);

        function updatePos() {
            x += incX;
            y += incY;

            mainwnd.setPosition(x, y);

            if(x >= document.body.clientWidth - params.initialWidth)
                incX = -2;

            if(x <= 0)
                incX = 2;

            if(y >= document.body.clientHeight - params.initialHeight)
                incY = -2;

            if(y <= 0)
                incY = 2;

            requestAnimationFrame(updatePos);
        }

        requestAnimationFrame(updatePos);

        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
        this.isFirstWindow = false;
    }
}