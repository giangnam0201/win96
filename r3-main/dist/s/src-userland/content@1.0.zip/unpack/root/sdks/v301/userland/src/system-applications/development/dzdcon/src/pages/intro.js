/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "intro",
    content: `
        <div class="container">
            <div>
                Welcome to the Dazzle DevConnector Wizard!<br>
                <br>
                This wizard will guide you to setup the DevConnector for Windows 96 development.<br>
                <br>
                Before starting, please ensure you:<br>
                <ul>
                    <li>
                        Know the address of the development machine you want to connect to.<br>
                        <i>Dazzle will provide this for you if you start the development server.</i>
                    </li>
                    <br>
                    <li>
                        Save any unsaved work before starting. In some cases, a reload may be required to setup the DevConnector properly.
                    </li>
                </ul>
            </div>
        </div>
    `,
    onrender: ()=>{
        // Called upon rendering
    },
    buttons: [
        {
            cls: "next",
            enabled: true,
            onclick: (app)=> {
                // Render a new page
                app.renderPage("address");
            }
        },
        {
            cls: "back",
            enabled: false
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});