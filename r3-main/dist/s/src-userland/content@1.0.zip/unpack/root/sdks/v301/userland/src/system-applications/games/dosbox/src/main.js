/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams, WRT } = w96;
const { DialogCreator, Theme, OpenFileDialog, MsgBoxSimple, MenuBar } = w96.ui;
const { isURL, isDataURL, dataURItoBlob } = w96.util;

class DOSBOXApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        await this._createWindow((argv[1] != null) ? argv[1] : "W:/system/apps/dosbox/zips/msd-essentials.zip");
    }

    showOpenZipDialog() {
        new OpenFileDialog("w:/system/apps/dosbox/zips", ["zip", "ZIP"], async (fn)=>{
            if(this._fnUrl)
                URL.revokeObjectURL(this._fnUrl);
            
            this._fnUrl = URL.createObjectURL(await FS.toBlob(fn));
            
            this.appFrame.onload = ()=> {
                this.appFrame.contentWindow.app.init(this, this.mainwnd, this._fnUrl);
            }
            this.appFrame.contentDocument.location.reload();
        }).show();
    }

    async _createWindow(fn) {
        /** @type {Blob} */
        var blobObj;

        let gameCfg = {
            args: [],
            ui: {
                showMenuBar: true,
                width: 642,
                height: 441
            },
            scripts: {
                init: null
            }
        };

        if(fn.endsWith(".json")) { // This is a configuration file.
            try {
                gameCfg = {...gameCfg, ...JSON.parse(await FS.readstr(fn))};

                if(gameCfg.zip) {
                    blobObj = await FS.toBlob(gameCfg.zip);
                }

                if(gameCfg.icon)
                    gameCfg.icon = URL.createObjectURL(await FS.toBlob(gameCfg.icon));
            } catch(e) {
                MsgBoxSimple.error("DOSBox", "Error reading configuration.", "OK");
                this.terminate();
            }
        } else {
            try {
                if(isURL(fn)) {
                    const req = await fetch(fn, { method: "GET", cache: "no-cache" });
                    blobObj = await req.blob();
                } else if(isDataURL(fn)) {
                    blobObj = dataURItoBlob(fn);
                } else {
                    blobObj = await FS.toBlob(fn);
                }
            } catch(e) {
                console.error(e);
                MsgBoxSimple.error("DOSBox", "Cannot mount ZIP file!", "OK");
                this.terminate();
            }
        }

        // Transform to blob url
        const params = new WindowParams();
        params.title = "DOSBox";
        params.initialWidth = gameCfg.ui.width;
        params.initialHeight = gameCfg.ui.height;

        const mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<div class="appbar"></div><iframe src="/system/apps/dosbox"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('dosbox-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/dosbox", '16x16'));

        // Create menubar
        const appBar = new MenuBar();
        
        appBar.addRoot("File", [
            { type: "normal", label: "Open ZIP", onclick: ()=>{
                this.showOpenZipDialog();
            } },
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{
                this.terminate();
            }}
        ]);

        appBar.addRoot("Scale", [
            { type: "normal", label: "Aspect", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode("aspect"); }},
            { type: "normal", label: "Stretch", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode("stretch"); }},
            { type: "separator" },
            { type: "normal", label: "Fullscreen", onclick: ()=>{ this.appFrame.contentWindow.app.setScaleMode("fullscreen"); }}
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "About", onclick: ()=>{
                w96.ui.MsgBoxSimple.info ("About NES", '<span class="bold-noaa">JSDOSBox Emulator</span><br>Version 1.0<br><br>Powered by <a href="https://js-dos.com/">jsdos</a>', "OK").dlg.setSize(320, 140);
            }}
        ])

        wContainer.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        // If a game config was specified, read the UI variables

        if(gameCfg.icon)
            mainwnd.setWindowIcon(gameCfg.icon);

        if(gameCfg.title)
            mainwnd.setTitle(gameCfg.title);

        if(!gameCfg.ui.showMenuBar)
            appBar.getMenuDiv().style.display = "none";

        // Create app frame

        const appFrame = mainwnd.wndObject.querySelector("iframe");
        const objectUrl = URL.createObjectURL(blobObj);
        this._fnUrl = objectUrl;

        appFrame.onload = ()=> {
            appFrame.contentWindow.app.init(this, mainwnd, objectUrl, this.gameCfg.args, ()=>{
                if(this.gameCfg.ui.aspect)
                    this.appFrame.contentWindow.app.setScaleMode(this.gameCfg.ui.aspect);
            });
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
        this.gameCfg = gameCfg;
    }

    async procScript(scriptName, args) {
        const scriptPath = this.gameCfg.scripts[scriptName];

        if(!scriptPath)
            return;

        const dlg = MsgBoxSimple.idleProgress("DOSBox", "Running scripts, please wait...");

        try {
            await WRT.runFile(scriptPath, {
                boxedEnv: {
                    instance: this,
                    ...args
                }
            });
        } catch(e) {
            DialogCreator.create({
                icon: "error",
                title: "DOSBox",
                body: `Failed to execute script ${scriptPath}:\n` + new String(e)
            });
        }

        dlg.closeDialog();
    }

    ontermination() {
        super.ontermination();
        URL.revokeObjectURL(this._fnUrl);

        if(this.gameCfg.icon)
            URL.revokeObjectURL(this.gameCfg.icon);
    }
}