/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme } = w96.ui;
const { WindowSystem } = w96;

const boxedEnv = this.boxedEnv;
const kernel = boxedEnv.kernel;

class UInitStage3 extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        kernel.hideCover(); // Hide the cover
        kernel.log.close(); // Destroy kernel log

        // Fix main graphics
        kernel.maingfx.style.display = "";
        kernel.maingfx.style.height = "100vh";
        document.body.style.overflow = "hidden";

        // Create main container
        const desktopEl = document.createElement('div');
        desktopEl.style.backgroundImage = "url(/system/resource/misc/setup.png)";
        desktopEl.style.width = "100vw";
        desktopEl.style.height = "100vh";
        desktopEl.style.position = "absolute";
        desktopEl.style.top = "0px";
        desktopEl.style.left = "0px";
        desktopEl.style.zIndex = "9";
        desktopEl.style.overflow = "hidden";
        desktopEl.style.backgroundPosition = "center";
        desktopEl.style.backgroundRepeat = "no-repeat";
        desktopEl.style.backgroundColor = "#0d9287";
        kernel.maingfx.appendChild(desktopEl);

        // Set configs
        WindowSystem.setWindowContainer(desktopEl);
        WindowSystem.disableAppBar(true);
        Theme.uiVars.maxWindowSizeFormulaH = "100vh";
        Theme.uiVars.maxWindowSizeFormulaW = "100vw";

        // Init theme engine
        await Theme.init(true);

        // Run oobe
        await w96.sys.execCmd("v2mig", []);
        await w96.sys.execCmd("oobe",  []);

        return false;
    }
}