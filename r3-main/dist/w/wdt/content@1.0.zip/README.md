# Windows 96 WDT Dist Package
Copyright (C) Windows96.net 2023.

## Generator Info

Generated on Sun Aug 27 2023 00:43:26 GMT+0200 (Central European Summer Time)

WDT Version: v1.0.0