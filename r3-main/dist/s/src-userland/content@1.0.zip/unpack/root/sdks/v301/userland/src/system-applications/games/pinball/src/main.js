/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme } = w96.ui;

/**
 * 3D Pinball - Space Cadet.
 */
class PinballApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * Entry point.
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        super.main(argv);
        await this._createWindow();
    }

    /**
     * Creates the window.
     */
    async _createWindow() {
        const mainwnd = this.createWindow({
            title: "3D Pinball for Windows - Space Cadet",
            initialHeight: 460,
            initialWidth: 600,
            controlBoxStyle: "WS_CBX_MINCLOSE",
            bodyClass: "eyeframe-app",
            icon: await Theme.getIconUrl("apps/pinball", '16x16'),
            body: `<iframe src="/system/apps/pinball"></iframe>`,
            taskbar: true,
            resizable: false
        }, true);

        mainwnd.show();

        // Focus iframe
        const body = mainwnd.getBodyContainer();
        const appFrame = body.querySelector('iframe');

        appFrame.focus();
    }
}