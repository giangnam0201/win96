/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/*
BWine installer.

Copyright (C) sys36.net 2023.
*/

const { Theme, DialogCreator } = w96.ui;
const { sideloadZip } = w96.util;

class BoxedWineApplication extends WApplication {
    constructor() { super() }

    /**
     * Main entry point.
     * @param {String[]} argv Program arguments.
     */
    async main(argv) {
        await super.main(argv);

        DialogCreator.confirm("In order to use WINE, you will need to download it (approx 620K).<br><br>Would you like to continue?", {
            icon: await Theme.getIconUrl("apps/wine", "32x32")
        }, async(v) => {
            if(!v) { this.ontermination(); return; }

            // Create progress dialog
            const pDlg = DialogCreator.progress("Downloading WINE package, please wait...");
            pDlg.wnd.setControlBoxStyle("WS_CBX_NONE");

            // Sideload the zip
            try {
                await sideloadZip("/system/sideload/bwinepkg.zip");
                pDlg.close();
                DialogCreator.alert("WINE has successfully been installed.", { icon: "info" });
            } catch(e) {
                DialogCreator.alert("Something went wrong whilst downloading the package:<br><br>" + String(e), { icon: "error" });
            }

            this.ontermination();
        });
    }
}