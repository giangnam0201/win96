/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WRT } = w96;

const term = this.boxedEnv.term;
const cwd = this.cwd;

if(!term)
    return 1;

class WJSApplication extends WApplication {
	constructor() {
        super();
    }

	async main(args) {
		super.main(args);

        if(args.includes("--help")) {
            term.println("usage: wjs <path> [--no-term] [--no-wrt]\nRuns a JS file in WRT (the Windows 96 JavaScript runtime).\n\nIf --no-wrt is specified, the file will be evaluated in normal JS instead.\nIf --no-term is specified, the WRT application will not know that it is running in a terminal.");
            return 0;
        }
        
        let pathArg = args[1];
        
        if((pathArg == "") || (pathArg == null)) {
            term.printError("wjs: 'wjs' requires a file path argument (none specified).");
            return 1;
        }
        
        if(!/^([a-zA-Z]:)/.test(pathArg)) // Relative path
            pathArg = FSUtil.resolvePath(cwd, pathArg);
        
        if(!await FS.exists(pathArg)) {
            term.printError(`wjs: unable to access '${pathArg}': No such file or directory.`);
            return 1;
        }
        
        if(!await FS.isFile(pathArg)) {
            term.printError(`wjs: invalid argument.`);
            return 1;
        }
        
        try {
            if(args.includes("--no-wrt")) {
                eval(await FS.readstr(pathArg));
            } else {
                let newArgs = [...args];
                newArgs.shift();
                
                await WRT.runFile(pathArg, {
                    boxedEnv: (args.includes("--no-term") ? null : {
                        term,
                        cwd,
                        args: newArgs
                    }),
                    envType: "terminal"
                });
            }
        } catch(e) {
            term.printError(e);
        }
    }
}