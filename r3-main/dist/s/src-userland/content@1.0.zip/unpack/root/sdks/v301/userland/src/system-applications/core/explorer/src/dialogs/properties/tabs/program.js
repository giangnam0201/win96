/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Returns the localized subsystem string.
 * @param {String} str The subsystem string to parse.
 */
function parseSubsystem(str) {
    if(!str)
        return "(none)";

    switch(str) {
        default:
            return str;
        case "gui":
            return "GUI";
        case "cli":
            return "Command-Line Interface";
    }
}

/**
 * Adds the program (version) tab.
 * @param {TabControl} tabc The tab control.
 * @param {String} path The program path.
 */
async function addProgramTab(tabc, path) {
    // Step 1. Check if this is actually a program.

    let binSpec;
    const fp = FSUtil.deconstructFullPath(path);
    const fso = FS.get(fp.prefix);

    // Make sure the FS type is right
    if (!(fso.features.includes(w96.FSFeatures.remote) || fso.remote) && (await FS.stat(path)).length < 10485760) {
        const wrtChk = await FS.readStrChunk(path, 0, 256);

        if (wrtChk.startsWith("//!wrt")) {
            // Parse the BinSpec (app metadata) if it exists
            if (wrtChk.includes("$BSPEC:")) {
                const nextLine = wrtChk.indexOf("\n");
                const bspecStr = wrtChk.substring(wrtChk.indexOf("$BSPEC:"), (nextLine == -1) ? undefined : nextLine);

                try {
                    binSpec = JSON.parse(bspecStr.substring(7));
                } catch (e) {
                    console.error(e);
                    return;
                }
            }
        }
        else
            return;
    }

    // Continue if binspec is successfully found
    if(binSpec) {
        tabc.addPage("Version", (e) => {
            e.classList.add("tab-version");
    
            // Add program fields
            appendFields(e, [
                { name: "File version", value: (binSpec.ver != null) ? binSpec.ver.toFixed(1) : "<unknown>" },
                { name: "Description", value: binSpec.dsc ?? "(none)" },
                { name: "Copyright", value: binSpec.cpr ?? "(none)" }
            ]);

            // Add group box
            const gbox = new GroupBox({
                title: "Other version information",
                body: ""
            });

            const gboxEl = gbox.getElement();

            /** @type {HTMLTextAreaElement} */
            let infoBox;

            // Add additional version info content
            const vInfoTableEl = document.createElement('div');
            vInfoTableEl.classList.add('vinfo-table');
            
            // Create left panel
            const leftPanel = document.createElement('div');
            leftPanel.classList.add('left');

            // Add the listbox
            const listBox = new ListBox();
            listBox.addItem("Author", "author").addEventListener('click', ()=>infoBox.value = binSpec.aut ?? "(none)");
            listBox.addItem("Friendly Name", "friendlyName").addEventListener('click', ()=>infoBox.value = binSpec.frn ?? "(none)");
            listBox.addItem("Subsystem", "subsystem").addEventListener('click', ()=>infoBox.value = parseSubsystem(binSpec.ssy));
            leftPanel.appendChild(listBox.getElement());

            // Create right panel
            const rightPanel = document.createElement('div');
            rightPanel.classList.add('right');

            // Create info box
            infoBox = document.createElement('textarea');
            infoBox.readOnly = true;
            infoBox.disabled = true;
            infoBox.value = "";
            rightPanel.appendChild(infoBox);

            // Add panels
            vInfoTableEl.appendChild(leftPanel);
            vInfoTableEl.appendChild(rightPanel);

            // Append table
            gboxEl.querySelector(".content").appendChild(vInfoTableEl);

            // Append groupbox element
            e.appendChild(gboxEl);
        });
    }
}