/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Dump command.
 * @param {SCMCApp} app App instance.
 * @param {String[]} argv Program arguments.
 */
async function cmd_Dump(app, argv) {
    argv.shift();

    // If no arg specified.
    if(!argv[0])
        return die("Error: no path specified.");

    const item = SCM.get(argv[0]);

    if(!item)
        return die("No object found for the specified path.");
    
    // Try to dump
    try {
        // check if output is file
        if(argv.includes('-o')) {
            const fileArg = argv[argv.indexOf("-o") + 1];

            if(!fileArg)
                return die("No file specified to dump to!");

            const finalPath = FSUtil.resolvePath(current.cwd, fileArg);
            
            await FS.writestr(finalPath, JSON.stringify({
                scmRestoreInfo: {
                    date: new Date().toUTCString(),
                    path: argv[0]
                },
                dumpData: item
            }, null));

            return 0;
        }
        else
            term.println(JSON.stringify(item, null, 4));
    } catch(e) {
        return die(new String(e));
    }
}