/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const CSS_CODE = `
.livecss-window {
    height: 400px;
    width: 400px;
    position: absolute;
    top: 10px;
    left: 10px;
    background: rgb(0, 0, 0, 0.8);
    z-index: 20;
    border: 1px solid white;
    display: flex;
    flex-direction: column;
    font-family: tahoma, verdana;
    color: white;
    font-size: 13px;
    box-shadow: 0px 0px 5px 0px black;
    z-index: 2147483647;
}

.livecss-window>.lc-tbar {
    background: white;
    color: black;
    padding: 5px;
    box-sizing: border-box;
    font-weight: bold;
}

.livecss-window>.lc-content {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.livecss-window>.lc-content>.style-input {
    flex: 1;
    outline: none;
    background: transparent;
    color: white;
    font-family: monospace;
    font-size: 14px;
    overflow: scroll;
    white-space: pre;
}

.livecss-window>.lc-content>.style-input::selection {
    background: royalblue;
}
`;