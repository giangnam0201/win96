/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

class MPlayer_libopenmpt {
    static backendName = "libopenmpt";

    static fileExtensions = [
        "mod",
        "xm",
        "it",
        "s3m",
        "mo3"
        // Yes there are a lot more I'll put them here soon
    ]

    static loadlibopenmpt() {
        // this is balls
        return new Promise((resolve, reject) => {
            if (!window.libopenmpt) {
                window.libopenmpt = {};
                window.libopenmpt.locateFile = filename => {
                    return "/system/libraries/extern/libopenmpt/" + filename;
                };
                window.libopenmpt.onRuntimeInitialized = resolve;
                import(/* webpackIgnore: true */ "/system/libraries/extern/libopenmpt/libopenmpt.js");
            } else {
                resolve();
            };
        });
    }

    constructor() {
        this._fileName = null;
        this._fileBuffer = null;
        this._filePtr = null;
        this._modulePtr = null;
    }

    getVideoElement() {
        return null;
    }

    async load(src) {
        if (!src)
            throw new Error("File to load has not been specified");

        await this.constructor.loadlibopenmpt();

        this._fileName = FSUtil.fname(src);
        this._fileBuffer = await FS.readbin(src);
        this._filePtr = window.libopenmpt._malloc(this._fileBuffer.byteLength);

        if (!this._filePtr)
            throw new Error("libopenmpt failed to allocate memory while loading " + this._fileName);

        window.libopenmpt.HEAPU8.set(this._fileBuffer, this._filePtr);

        this._modulePtr = window.libopenmpt._openmpt_module_create_from_memory(this._filePtr, this._fileBuffer.byteLength, 0, 0, 0);

        if (!this._modulePtr)
            throw new Error("libopenmpt failed to load " + this._fileName);

        window.libopenmpt._openmpt_module_set_repeat_count(this._modulePtr, 0);

        this._metadataKeys = window.libopenmpt.UTF8ToString(window.libopenmpt._openmpt_module_get_metadata_keys(this._modulePtr)).split(";");
        this._metadata = {};

        {
            const metadataKeyLongest = this._metadataKeys.reduce((prev, cur) => (cur.length > prev.length ? cur : prev), "");
            const metadataKeyLen = window.libopenmpt.lengthBytesUTF8(metadataKeyLongest) + 1;
            const metadataKeyBuf = window.libopenmpt._malloc(metadataKeyLen);

            if (!metadataKeyBuf)
                throw new Error("libopenmpt failed to allocate memory while processing metadata for " + this._fileName);

            for (const metadataKey of this._metadataKeys) {
                window.libopenmpt.stringToUTF8(metadataKey, metadataKeyBuf, metadataKeyLen);
                this._metadata[metadataKey] = window.libopenmpt.UTF8ToString(window.libopenmpt._openmpt_module_get_metadata(this._modulePtr, metadataKeyBuf));
            }

            window.libopenmpt._free(metadataKeyBuf);
            console.log(this._metadata);
        }

        this.onloaded();
    }

    play() {

    }

    pause() {

    }

    stop() {

    }

    time(seconds) {
        if (typeof seconds == "number")
            window.libopenmpt._openmpt_module_set_position_seconds(this._modulePtr, seconds);

        return window.libopenmpt._openmpt_module_get_position_seconds(this._modulePtr);
    }

    volume(value) {

    }

    duration() {
        return window.libopenmpt._openmpt_module_get_duration_seconds(this._modulePtr);
    }

    getName() {
        return `${this._metadata.title ? this._metadata.title + " - (" : ""}${this._fileName}${this._metadata.title ? ")" : ""}`;
    }

    state() {

    }

    playbackRate(rate) {

    }

    unload() {
        if (this._modulePtr) {
            window.libopenmpt._openmpt_module_destroy(this._modulePtr);
            this._modulePtr = null;
        }
    }
}
