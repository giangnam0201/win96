/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "setup-finish",
    content: `
        <div class="container">
            <div>
                The DevConnector setup has successfully completed.<br><br>
                Press "Finish" to exit this wizard and launch the DevConnector service.
            </div>
        </div>
    `,
    onrender: (app, contentEl)=>{
        app.body.querySelector("button.next").textContent = "Finish";
    },
    buttons: [
        {
            cls: "next",
            enabled: true,
            onclick: async (app)=>{
                await app.terminate();
                setTimeout(()=>execCmd("dzdsvc", []), 1); // Schedule
            }
        },
        {
            cls: "back",
            enabled: false
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});