DOOM for Windows 96.

DOOM (C) ID software.