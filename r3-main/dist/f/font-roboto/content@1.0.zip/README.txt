This package contains the Roboto font family.

You can find the full license in c:/system/local/share/licenses/font-roboto/LICENSE.txt