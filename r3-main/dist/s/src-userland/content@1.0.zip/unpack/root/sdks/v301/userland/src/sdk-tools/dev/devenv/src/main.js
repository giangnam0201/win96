/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { wait, escapeHtml } = w96.util;
const { DialogCreator, MenuBar, Theme } = w96.ui;
const { ToolBar, UIComponent } = w96.ui.components;
const noop = ()=>{};

/**
 * The app instance.
 * @type {MDevEnvApplication}
 */
let appInstance = null;

/* DevEnv PATHS */
const DEV_ENV_ROOT = "W:/system/apps/devenv";

/**
 * DevEnv Paths
 */
const DEV_ENV_PATHS = {
    /**
     * App root directory.
     */
    ROOT: DEV_ENV_ROOT,

    /**
     * DevEnv resources folder.
     */
    RSRC: DEV_ENV_ROOT + "/resources",


    /**
     * User projects directory.
     */
    PROJECTS_DIR: "C:/user/documents/DevEnv Projects"
}

$$Include("./ui/components/xtab.js")
$$Include("./ui/about.js")
$$Include("./ui/splash.js")
$$Include("./ide/tab-repository.js")
$$Include("./ide/env.js")


class MDevEnvApplication extends WApplication {
    constructor() {
        super();
        appInstance = this;
        this.blobs = [];
        this.textResourceMap = {};
    }

    /**
     * Reads a text file as a resource string.
     * @param {string} id The resource ID.
     * @param {string} src The path of the file to read.
     */
    async loadStrRsrcFromFile(id, src) {
        if(this.textResourceMap[id] != null)
            return;

        this.textResourceMap[id] = await FS.readstr(src);
    }

    /**
     * Gets a text resource.
     * @param {string} id The ID of the resource.
     * @returns 
     */
    getTextResource(id) {
        return this.textResourceMap[id];
    }

    /**
     * Initializes the IDE.
     */
    async initializeEnvironment() {
        await this.loadStrRsrcFromFile("UI/SplashStyles", DEV_ENV_PATHS.RSRC + "/splash.css");
        await this.loadStrRsrcFromFile("UI/Splash", DEV_ENV_PATHS.ROOT + "/ui/splash.html");

        const splashWindow = await createApplicationSplash(this);
        const windowBody = splashWindow.getBodyContainer();
        const progress = windowBody.querySelector(".w96-progressbar>.progress");

        // Stage 1: Create important directories
        if(!await FS.exists(DEV_ENV_PATHS.PROJECTS_DIR))
            await FS.mkdir(DEV_ENV_PATHS.PROJECTS_DIR);

        progress.style.width = `10%`;

        // Stage 2: Load app css
        const styleEl = document.createElement('style');
        styleEl.textContent = await FS.readstr(DEV_ENV_PATHS.RSRC + "/app.css");
        document.body.appendChild(styleEl);
        this.styleEl = styleEl;
        progress.style.width = `20%`;

        // Stage 3: Load UI files
        progress.style.width = `30%`;
        await this.loadStrRsrcFromFile("UI/StartPage", DEV_ENV_PATHS.ROOT + "/ui/start-page.html");
        await this.loadStrRsrcFromFile("UI/Tab/WebBrowser", DEV_ENV_PATHS.ROOT + "/ui/tabs/web-browser.html");

        // We're done
        progress.style.width = `100%`;
        splashWindow.close();
    }

    /**
     * Program entry point.
     * @param {string[]} argv Program arguments.
     */
    async main(argv) {
        await super.main(argv);
        
        // Inits the environment
        try {
            await this.initializeEnvironment();
        } catch(e) {
            const dlg = w96.ui.DialogCreator.alert(`The development environment failed to initialize!<br><br>Exception: <span class="ex">
                <br>
                Message -> ${escapeHtml(e.message || "<none>")}<br>
                Stack -> ${escapeHtml(e.stack || "<none>")}<br> 
            </span>`, { icon: "error", title: "DevEnv Error"});
            await dlg.wait();
            this.terminate();
            return;
        }

        // Show start window
        this.ide = new IDE(this);
        await this.ide.begin();
        this.ide = null;
        
        // Shutdown procedure
    }

    /**
     * On program closure.
     */
    async ontermination() {
        await super.ontermination();

        for(let blob of this.blobs)
            URL.revokeObjectURL(blob);

        if(this.styleEl)
            this.styleEl.remove();

        this.styleEl = null;
        this.textResourceMap = null;
        this.ide = null;
        appInstance = null;
    }
}