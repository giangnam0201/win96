Windows 96 Userland Sources (C) Windows 96 Team 2023.

Use of this source is governed by the license found at https://git.sys36.net/windows-96/sys-userland/

To build all projects, change directory to "src" and run "wdt make". Output files will be available in "../output".