# App SDK projects

These projects are intended as dev tools and should not be included in the default Win96 install.
