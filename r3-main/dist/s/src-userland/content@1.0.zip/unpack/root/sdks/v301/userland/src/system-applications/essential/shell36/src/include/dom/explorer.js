/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/** @type {import("../../../../../../../../source/src/gui/ui/components/fs-view").FSViewUIComponent} */
let fsView;
let iconDesktop;

// For icon positions
let iconRegistry = [];

// State variables
let _ui_delete_busy = false;

// Special icon registry for fsview
const specialIcons = [
    {
        name: "Computer",
        path: "c:/user/desktop",
        icon: "devices/computer",
        id: "computer"
    },
    {
        name: "Documents",
        path: "c:/user/desktop",
        icon: "places/documents",
        id: "documents"
    },
    {
        name: "Recycle Bin",
        path: "c:/user/desktop",
        icon: "places/trash-full",
        id: "trash"
    }
];

/**
 * Updates the icon position.
 * @param {String} fn The name of the icon.
 * @param {{top: Number, left: Number}} pos The position.
 */
function updateIconPosition(fn, pos) {
    const previousPosition = iconRegistry.find(x => x.name == fn);
    
    if(previousPosition)
        iconRegistry.splice(iconRegistry.indexOf(previousPosition), 1);

    // Push the new position
    iconRegistry.push({
        name: fn,
        pos
    });

    try {
        FS.writestr("c:/system/config/deskicn.json", JSON.stringify(iconRegistry));
    } catch(e) {
        console.log(e);
    }
}

/**
 * Sets up the icon desktop.
 */
async function setupIconDesktop() {
    fsView = new FSView("c:/user/desktop", false);
    await fsView.init();

    try {
        // Read icon registry
        if(await FS.exists("c:/system/config/deskicn.json"))
            iconRegistry = JSON.parse(await FS.readstr("c:/system/config/deskicn.json", iconRegistry));
    } catch(e) {
        console.error(e);
    }

    // Set some options
    fsView.options.enableNavigation = false;
    fsView.options.showHiddenFiles = false;
    fsView.options.metaLookup = false;
    fsView.options.alignMode = "desktop";
    fsView.options.specialIcons = specialIcons;
    fsView.options.iconMovement = "free";
    fsView.options.storedIconPositions = iconRegistry;

    // Modify FS view
    const fsViewEl = fsView.getElement();
    fsViewEl.classList.add("user-desktop");
    fsViewEl.style.height = `calc(100% - ${Theme.uiVars.taskbarHeight})`;
}

/**
 * File deletion UI.
 */
async function uiDelete() {
    const fsViewEl = fsView.getElement();
    const paths = [...fsViewEl.querySelectorAll('.shell-icon.selected')].map(x => x.getAttribute("path"));

    if(paths.length < 1)
        return;

    // Check paths to ensure all item deletions are actually within the desktop folder
    // Needed for special icon handling
    for(let p of paths)
        if(FSUtil.getParentPath(p) !== "C:/user/desktop")
            return; // Do not process

    if(_ui_delete_busy)
        return;
    else
        _ui_delete_busy = true;
    
    try {
        await execCmd("recyclui", paths);
    } catch(e) {
        console.error(e);
    }

    fsViewEl.focus(); // Refocus on ui component
    _ui_delete_busy = false;
    w96.evt.ui.emit('reload-desktop');
}

/**
 * Assigns some desktop events.
 */
function assignDesktopEvents() {
    const fsViewEl = fsView.getElement();
    const refreshCb = ()=>w96.evt.ui.emit('reload-desktop');

    fsView.onclipboard = refreshCb;
    fsView.ondropfinish = refreshCb;
    fsView.onrefreshneeded = refreshCb;

    // Save positions
    fsView.onicondrop = (e, pos)=> {
        if(fsView.options.iconMovement != "free")
            return;

        let path;

        if(typeof e === 'string')
            path = FSUtil.normalizeDriveLetter(e);
        else
            {
                const ent = e.getAttribute("ent");

                if(ent == "2")
                    path = FSUtil.normalizeDriveLetter("c:/dummy/" + e.querySelector('.icon-text').textContent);
                else
                    path = FSUtil.normalizeDriveLetter(e.getAttribute("path"));
            }

        // Save in icon registry
        updateIconPosition(FSUtil.fname(path), pos);
    }

    // Add a context menu
    fsViewEl.addEventListener('contextmenu', (e) => {
        // Preliminary checks
        if((!e.target) && (!e.target.classList))
            return;

        // Destroy other menus
        document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());

        // Check if item is shell icon or just empty space
        let isIconSelected = false;

        /** @type {Node} */
        let parEl = e.target;

        while(parEl.id != gfxEl.id) {
            parEl = parEl.parentNode;
            if(parEl.classList.contains("shell-icon")) {
                isIconSelected = true;
                break;
            }
        }

        let ctxmItems = [];

        // Show menu for icon
        if(isIconSelected) {
            const selectedIcons = fsViewEl.querySelectorAll('.shell-icon.selected');

            if(selectedIcons.length < 1)
                return; // Do not bother
            else if(selectedIcons.length == 1) {
                const iconEl = selectedIcons[0];
                const iconElType = iconEl.getAttribute("ent");
                const iconElPath = iconEl.getAttribute("path");

                ctxmItems = [
                    { type: "normal", label: "Open", onclick: ()=> {
                        iconEl.ondblclick(e);
                    } },
                    { type: "normal", label: "Open with...", class: "openwith", onclick: () => {
                        execCmd('openwith', [iconElPath]);
                    } },
                    { type: "normal", label: "Download", class: "download", onclick: ()=> {
                        if(iconElType == "1") {
                            MsgBoxSimple.error("Error", "Not implemented", "OK");
                            return;
                        }

                        FSUtil.downloadFile(iconElPath);
                    } },
                    { type: "separator" },
                    {
                        type: "normal",
                        label: "Cut",
                        class: "cut",
                        onclick: async ()=> {
                            fsView.performClipboard("cut");
                        }
                    },
                    {
                        type: "normal",
                        label: "Copy",
                        class: "copy",
                        onclick: async ()=> {
                            fsView.performClipboard("copy");
                        }
                    },
                    { type: "separator" },
                    {
                        type: "normal",
                        label: "Make Link",
                        class: "mklink",
                        onclick: async ()=> {
                            const linkObj = {
                                action: iconElPath
                            }

                            const fn = FSUtil.fname(iconElPath);
                            let target = `c:/user/desktop/Link to ${fn}.link`;

                            if(fn.endsWith(".link")) {
                                target = `c:/user/desktop/Copy of ${fn}`;
                                await FS.cpfile(iconElPath, target);
                            } else
                                await FS.writestr(target, JSON.stringify(linkObj));

                                w96.evt.ui.emit('reload-desktop');
                        }
                    },
                    { type: "normal", label: "Rename", class: "rename", onclick: async ()=> {
                        MsgBoxSimple.prompt("Rename", "Enter the new name of the entry.", FSUtil.fname(iconElPath), async(val)=> {
                            if(val == null)
                                return;

                            await FS.rename(iconElPath, val);
                            w96.evt.ui.emit('reload-desktop');
                        });
                    } },
                    {
                        type: "normal",
                        label: "Delete",
                        class: "delete",
                        onclick: async ()=> {
                            uiDelete();
                        }
                    },
                    { type: "separator"},
                    { 
                        type: "normal",
                        label: "Properties",
                        class: "prop",
                        onclick: ()=> {
                            execCmd("explorer", ["--prop", iconElPath]);
                        }
                    }
                ];

                switch(iconElType) {
                    case "2":
                        ctxmItems = [
                            {
                                type: "normal",
                                label: "Open",
                                onclick: ()=> {
                                    iconEl.ondblclick(e);
                                }
                            }
                        ]
                        break;
                    case "1":
                        ctxmItems = ctxmItems.filter((item => (item.class != 'openwith') && (item.class != 'download')));
                        break;
                }
            } else {
                // TODO
                // Deal with multiple items
            }
        } else {
            // Show normal menu
            // Deselect all icons so we know that this is a desktop context menu
            fsView.deselectAllIcons();
            
            ctxmItems = [
                {
                    type: "normal",
                    label: "New File",
                    onclick: () => {
                        MsgBoxSimple.prompt("Create File", "Enter the name of the file to create.", "New File.txt", async (val) => {
                            if (val == null)
                                return;
                
                            const pathToCreate = "c:/user/desktop/" + val;
                
                            if (await FS.exists(pathToCreate)) {
                                MsgBoxSimple.warning("File Creation Failure", "The path specified already exists.", "OK");
                            } else {
                                await FS.touch(pathToCreate);
                                w96.evt.ui.emit('reload-desktop');
                            }
                        });
                    }
                }, {
                    type: "normal",
                    label: "New Directory",
                    onclick: () => {
                        MsgBoxSimple.prompt("Create Directory", "Enter the name of the directory to create.", "New Folder", async (val) => {
                            if (val == null)
                                return;
                
                            const pathToCreate = "c:/user/desktop/" + val;
                
                            if (await FS.exists(pathToCreate)) {
                                MsgBoxSimple.warning("Directory Creation Failure", "The path specified already exists.", "OK");
                            } else {
                                await FS.mkdir(pathToCreate);
                                w96.evt.ui.emit('reload-desktop');
                            }
                        });
                    }
                }, {
                    type: "normal",
                    label: "New Shortcut",
                    onclick: () => {
                        showNewShortcutDialog("c:/user/desktop");
                    }
                }, {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Refresh",
                    onclick: () => {
                        w96.evt.ui.emit('reload-desktop');
                    }
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Paste",
                    cls: "paste",
                    disabled: true,
                    onclick: () => {
                        // Do paste
                        fsView.performClipboard("paste");
                    }
                },
                {
                    type: "separator"
                },
                {
                    type: "normal",
                    label: "Properties",
                    onclick: () => {
                        execCmd("ctrl", ["--cpl", "laf"]);
                    }
                }
            ];

            if(w96.wmem.clipboard && (w96.wmem.clipboard.items.length > 0))
                ctxmItems.find(x=>x['cls'] == "paste").disabled = false;
        }

        const ctxMenu = new ContextMenu(ctxmItems);
        ctxMenu.renderMenu(e.x, e.y);
    });

    fsViewEl.addEventListener('keydown', (e)=>{
        if(document.activeElement !== fsViewEl)
            return; // Do not process key events if desktop is not in focus

        if(e.key == "Delete") {
            e.preventDefault();
            e.stopPropagation();

            uiDelete();
        }
    });

    fsViewEl.addEventListener('mousedown', (e) => {
        fsViewEl.focus(); // Make sure we are focused
        WindowSystem.deactivateAllWindows();
    });

    // For start menu closure
    gfxEl.addEventListener('click', (e)=>{
        /** @type {HTMLDivElement} */
        const el = e.target;

        if((!e.target) || (!el.classList)) return;

        if(el.classList.contains("oc-event-exempt") || el.classList.contains("start_button"))
            return;

        /** @type {Node} */
        var parEl = e.target;

        while(parEl && (parEl.id != gfxEl.id)) {
            parEl = parEl.parentNode;

            if(!parEl)
                continue;

            if(parEl.classList.contains("oc-event-exempt"))
                return;
        }

        if(isStartOpen)
            StartMenu.close();
    });

    // Add reboot warning listener.
    document.addEventListener('keydown', (e) =>{
        if((e.key == "F5") || (e.ctrlKey && (e.key == "r"))) {
            e.preventDefault();

            if(!w96.wmem._refreshConfirm) {
                w96.wmem._refreshConfirm = true;
                DialogCreator.confirm("Are you sure you want to reboot? Any unsaved data is lost!", {
                    title: "System",
                    icon: "warning"
                }, (v)=>{
                    if(v) {
                        w96.sys.reboot();
                    }

                    w96.wmem._refreshConfirm = false;
                }, "warning");
            }
        }
    });

    // Menu handler
    document.body.onclick = (e)=> {
        try {
            if((!e.target) || (!e.target.classList) && (e.target.classList.contains("root-item")))
                return;
        } catch(e) {
            // Terrible practice but too f'd to figure this out right now
        }
                        
        document.querySelectorAll(".wcontext-menu").forEach((v)=>v.remove());
        document.querySelectorAll(".w96-menubar>.root-item.selected").forEach((v)=>v.classList.remove('selected'));
    }
}