/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "dcsettings",
    content: `
        <div class="container">
            <div>
                Below you can configure DevConnector to suit your needs.
            </div>
            <br>
            <div class="gbox1"></div>
        </div>
    `,
    onrender: (app, contentEl)=>{
        const gbox1 = new GroupBox({ title: "Behavior" });
        const gbox1El = gbox1.getElement();

        // Startup checkbox
        const startupCbox = new CheckBox({
            label: "Launch DevConnector service on startup",
            checked: installState.dcStartup,
            onchange: (e)=>installState.dcStartup = e.checked,
            displayAsBlock: true
        });

        gbox1El.querySelector('.content').appendChild(startupCbox.getElement());
        contentEl.querySelector(".gbox1").replaceWith(gbox1El);
    },
    buttons: [
        {
            cls: "next",
            enabled: true,
            onclick: async (app)=> {
                // Save settings in SCM
                await SCM.setAndSync("Software/DevConnector", installState);

                // Make startup shortcut
                if(installState.dcStartup)
                    FS.writestr("c:/system/startup/dzdsvc.link", JSON.stringify({ action: "dzdsvc", icon: "mime/executable" }));

                app.renderPage("setup-finish");
            }
        },
        {
            cls: "back",
            enabled: false,
            onclick: (app)=> {}
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});