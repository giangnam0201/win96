/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme } = w96.ui;
const { WindowParams } = w96;

const LATEST_RELEASE = "v020_wgl";
const RELEASE_SERVE_URL = "https://serve01.windows96.net/gameing/versions/$BUILD$/dl";

class GameingApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow(argv);
    }

    async _createWindow(argv) {
        let version = LATEST_RELEASE;

        if(argv[1] != null) {
            version = argv[1];
        }

        var params = new WindowParams();
        params.title = "Gameing";
        params.initialWidth = 640;
        params.initialHeight = 441;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<iframe src="${RELEASE_SERVE_URL.replace(/\$BUILD\$/g, version)}"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('gameing-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/gameing", '16x16'));

        const appFrame = mainwnd.wndObject.querySelector("iframe");

        appFrame.onload = ()=> {
            
        }

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }
}