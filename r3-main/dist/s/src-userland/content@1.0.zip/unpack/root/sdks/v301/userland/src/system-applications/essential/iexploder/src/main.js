/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { DialogCreator, MenuBar, Theme } = w96.ui;

/**
 * Formats a URL.
 * @param {String} u The url to format.
 */
function formatUrl(u) {
    let nu = u;

    if(u.startsWith("about:"))
        return nu;
    else if(u.startsWith("/"))
        return nu;
    else if(!(nu.startsWith("https://") || nu.startsWith("http://"))) {
        nu = "https://" + nu;
    }

    return nu;
}

const systemUrls = [
    {
        url: "exploder://start",
        title: "Start Page",
        redir: "/system/data/iexploder/syspages/start",
        import_sys: true // Import system resources
    }
]

class IntExploderApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(!await FS.exists("c:/user/appdata/Internet Exploder"))
            await FS.mkdir("c:/user/appdata/Internet Exploder");

        if(!await FS.exists("c:/user/appdata/Internet Exploder/Bookmarks.json")) {
            // Create some default bookmarks
            await FS.writestr("c:/user/appdata/Internet Exploder/Bookmarks.json", JSON.stringify({
                "Windows 96": [
                    {
                        name: "Old release v1",
                        url: "https://rel1.windows96.net/"
                    },
                    {
                        name: "OS-ception",
                        url: "https://windows96.net/"
                    },
                    {
                        name: "Gameing Standalone",
                        url: "https://windows96.net/dl/gameing"
                    },
                    {
                        name: "ShareBoard",
                        url: "https://sb.windows96.net/"
                    },
                    {
                        name: "Wiki",
                        url: "https://wiki.windows96.net"
                    },
                    {
                        name: "MsgRoom",
                        url: "https://msgroom.windows96.net"
                    }
                ],
                "Developer": [
                    {
                        name: "API documentation",
                        url: "https://apidocs.windows96.net"
                    },
                    {
                        name: "Developer Documentation",
                        url: "https://devdocs.windows96.net"
                    }
                ],
                "Cool": [
                    {
                        name: "WebGL Aquarium Sample",
                        url: "https://webglsamples.org/aquarium/aquarium.html"
                    },
                    {
                        name: "HTML5Test",
                        url: "https://html5test.com/"
                    },
                    {
                        name: "Octane JS Benchmark",
                        url: "https://chromium.github.io/octane/"
                    },
                    {
                        name: "Acid3 Test",
                        url: "http://acid3.acidtests.org/"
                    }
                ]
            }, null, 4));
        }

        await this._createWindow(argv);
    }

    async _createWindow(argv) {
        const params = new WindowParams();
        params.title = "about:blank - Internet Exploder";
        params.initialWidth = 800;
        params.initialHeight = 650;

        const mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<div class="appbar"></div>
        <div class="header">
            <div class="toolbar w96-toolbar">
                <button class="w96-button nav back"></button>
                <button class="w96-button nav forward"></button>
                <button class="w96-button nav reload"></button>
                <div class="vseparator" style="margin-right: 0px;"></div>
                <div class="w96-menubar bookmarks-bar"></div>
            </div>
            <div class="navbar">
                <span class="text">
                Address:
                </span>
                <input class="w96-textbox navbox">
                <button class="w96-button go">Go</button>
            </div>
        </div>
        <iframe src="about:blank"></iframe>
        <footer class="w96-footer">
            <div class="cell">
                Internet Exploder 1.0
            </div>
        </footer>`);

        const wContainer = mainwnd.getBodyContainer();
        wContainer.classList.add('iexploder-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/iexploder", '16x16'));

        const appFrame = mainwnd.wndObject.querySelector("iframe");
        /** @type {HTMLInputElement} */
        this.navBox = wContainer.querySelector('.navbox');
        this.footer = wContainer.querySelector('footer');

        wContainer.querySelector('.nav.back').onclick = ()=> {
            appFrame.contentWindow.history.back();
        }

        wContainer.querySelector('.nav.forward').onclick = ()=> {
            appFrame.contentWindow.history.forward();
        }

        wContainer.querySelector('.nav.reload').onclick = ()=> {
            this.navigate(this.navBox.value);
        }

        this.navBox.onkeydown = (e)=> {
            if(e.key == "Enter") {
                this.navigate(this.navBox.value);
            }
        }

        wContainer.querySelector(".w96-button.go").onclick = ()=>this.navigate(this.navBox.value);

        /*
        Add elements
        */

        /*
        Create app bar
        */

        const appBar = new MenuBar();

        appBar.addRoot("File", [
            { type: "normal", label: "Exit", onclick: ()=>{
                this.terminate();
            }}
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "About", onclick: ()=>{
                DialogCreator.alert('<span class="bold-noaa">Internet Exploder</span><br>Version 1.0<br>', {
                    title: "About Internet Exploder",
                    icon: "info"
                });
            }}
        ]);

        wContainer.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        /*
        Create bookmarks bar
        */
        const bookmarksBar = new MenuBar();
        this.bookmarksBar = bookmarksBar;

        // TODO read bookmarks from JSON file


        try {
            const bookmarks = JSON.parse(await FS.readstr("c:/user/appdata/Internet Exploder/Bookmarks.json"));
            const folders = Object.keys(bookmarks);

            folders.forEach((folder)=>this.createBookmarksFolder(folder, bookmarks[folder]));

        } catch(e) {
            DialogCreator.alert(e.toString(), {
                title: "Error",
                icon: "error"
            });
        }

        const bmMenu = bookmarksBar.getMenuDiv();
        bmMenu.classList.add('bookmarks-bar');
        wContainer.querySelector('.bookmarks-bar').replaceWith(bmMenu);
        /*
        Assign events
        */

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();

        if(argv[1] != null) {
            this.navigate(argv[1]);
        } else {
            this.navigate("exploder://start");
        }
    }

    /**
     * Loads a URL.
     * @param {String} url The URL to load.
     */
    async navigate(url) {
        // Check if the URL is a file
        if(await FS.exists(url)) {
            // Create SW url
            //c:/users
            const dp = FSUtil.deconstructFullPath(url);
            return this.navigate(`/_/${dp.prefix[0]}/${url.substring(3)}`);
        }

        const systemUrlObj = systemUrls.find((x)=>x.url == url);
        this.appFrame.onload = ()=>{}; // Clear event

        if(systemUrlObj) {
            if(!systemUrlObj.title)
                this.mainwnd.setTitle(url + " - Internet Exploder");
            else
                this.mainwnd.setTitle(systemUrlObj.title + " - Internet Exploder");

            this.navBox.value = url;

            if(systemUrlObj.import_sys) {
                this.appFrame.onload = ()=>{
                    this.appFrame.contentWindow.w96 = w96;
                }
            }

            if(systemUrlObj.body)
                this.appFrame.src = `data:text/html;base64,` + btoa(systemUrlObj.body);
            else
                this.appFrame.src = systemUrlObj.redir;

            this.footer.innerText = "Internet Exploder 1.0";
            return;
        }

        const formattedUrl = formatUrl(url);

        this.mainwnd.setTitle(formattedUrl + " - Internet Exploder");
        this.navBox.value = formattedUrl;
        this.appFrame.src = formattedUrl;
        this.footer.innerText = "Internet Exploder 1.0";
    }

    /**
     * Creates a bookmarks folder.
     * @param {String} name The name of the folder.
     * @param {*[]} items
     */
    createBookmarksFolder(name, items) {
        const fImg = document.createElement('span');
        fImg.classList.add('image');
        Theme.getIconUrl("places/folder", '16x16').then((v)=>fImg.style.background = `url(${v})`);

        const itemsExec = [];

        for(let i of items) {
            itemsExec.push({
                type: "normal",
                label: i.name,
                onclick: ()=>this.navigate(i.url)
            });
        }

        const root = this.bookmarksBar.addRoot(name, itemsExec);
        root.prepend(fImg);
        return root;
    }
}