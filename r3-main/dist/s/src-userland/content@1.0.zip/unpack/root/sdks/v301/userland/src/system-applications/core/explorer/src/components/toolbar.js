/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

class ExplorerToolbar extends ToolBar {
    constructor(options = {}) {
        super();
        options = {
            backwards: true,
            forwards: true,
            up: true,
            delete: false,
            properties: false,
            iconMap: {},
            ...options
        }

        this.fsv = null;
        this.navigate = null;

        let btnBackwards;
        let btnForwards;

        if(options.backwards) {
            btnBackwards = this.addItem({
                text: "Back",
                imageUrl: options.iconMap["back"],
                isDropdown: true,
                dropdownMenu: new ContextMenu(),
                onclick: () => {
                    btnForwards.el.removeAttribute('disabled');
                    this.navigate(this.fsv.backwards(false), false, false);
                    if(this.fsv.historyPos === 0) {
                        btnBackwards.el.setAttribute('disabled', 'true');
                    }
                }
            });

            btnBackwards.el.setAttribute('disabled', 'true');
            this.btnBackwards = btnBackwards;
        }

        if(options.forwards) {
            btnForwards = this.addItem({
                text: "Forward",
                imageUrl: options.iconMap["forward"],
                isDropdown: true,
                dropdownMenu: new ContextMenu(),
                onclick: () => {
                    btnBackwards.el.removeAttribute('disabled');
                    this.navigate(this.fsv.forwards(false), false, false);

                    if(this.fsv.historyPos + 1 === this.fsv.history.length) {
                        btnForwards.el.setAttribute('disabled', 'true');
                    }
                }
            });

            btnForwards.el.setAttribute('disabled', 'true');
            this.btnForwards = btnForwards;
        }

        if(options.up) {
            this.addItem({
                text: "Up",
                imageUrl: options.iconMap["up"],
                onclick: () => {
                    this.navigate(this.fsv.up(false));
                }
            });
        }

        // The sizes are fucked when there's a vseparator in a window that's too small :((((
        this.getElement().insertAdjacentHTML('beforeend', '<div class="vseparator"></div>'); // Mmm

        this.addItem({
            text: "Cut",
            imageUrl: options.iconMap["cut"],
            onclick: () => {
                this.fsv.performClipboard("cut");
            }
        });

        this.addItem({
            text: "Copy",
            imageUrl: options.iconMap["copy"],
            onclick: () => {
                this.fsv.performClipboard("copy");
            }
        });

        this.addItem({
            text: "Paste",
            imageUrl: options.iconMap["paste"],
            onclick: () => {
                this.fsv.performClipboard("paste");
            }
        });

        this.getElement().insertAdjacentHTML('beforeend', '<div class="vseparator"></div>');

        /*this.addItem({
            text: "Undo",
            imageUrl: "/system/resource/app/explorer/toolbar/undo.png",
            onclick: ()=>{}
        });

        this.getElement().insertAdjacentHTML('beforeend', '<div class="vseparator"></div>');*/

        if(options.delete) {
            this.addItem({
                text: "Delete",
                imageUrl: options.iconMap["delete"],
                onclick: () => {
                    let icon = this.fsv.selectedIcons[0];
                    if(icon) this.ondelete(icon.getAttribute('path'), icon.getAttribute('ent'));
                }
            });
        }

        if(options.properties) {
            this.addItem({
                text: "Properties",
                imageUrl: options.iconMap["properties"],
                onclick: () => {
                    let icon = this.fsv.selectedIcons[0];
                    if(icon) this.onproperties(icon.getAttribute('path'));
                }
            });
        }

        /*this.getElement().insertAdjacentHTML('beforeend', '<div class="vseparator"></div>');

        // The details view seems to be a bit broken
        this.addItem({
            text: "Views",
            imageUrl: "/system/resource/app/explorer/toolbar/views.png",
            isDropdown: true,
            dropdownMenu: new ContextMenu(),
            onclick: ()=>{}
        });*/
    }

    update() {
        if(this.fsv.historyPos + 1 != this.fsv.history.length && this.btnForwards) {
             this.btnForwards.el.setAttribute('disabled', 'true');
        }

        if(this.fsv.history.length !== 0 && this.btnBackwards) {
            this.btnBackwards.el.removeAttribute('disabled');
        }
    }
}
