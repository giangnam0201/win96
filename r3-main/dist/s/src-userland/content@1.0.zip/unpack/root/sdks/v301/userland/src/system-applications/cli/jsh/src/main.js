/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

$$Include("./replcmd.js")

const { inspect } = w96.util;

const term = this.boxedEnv.term;

if(!term)
    return 1;

const REPL_CMD_PREFIX = ".";
const JSH_PROFILE_DEFAULT = `// These commands will be executed on each JSH startup.

/**
 * Called on JSH initialization.
 */
async function init(context) {
    // Supply custom code here
}

module.exports = { init }`;

/**
 * The template for a terminal application.
 */
class JSShellApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        const JshConfig = {
            prompt: '> '
        };

        // Preinit: check if JSH profile exists
        if(!await FS.exists("C:/user/appdata/JSH/profile.js")) {
            if(!await FS.exists("C:/user/appdata/JSH"))
                await FS.mkdir("C:/user/appdata/JSH");

            await FS.writestr("C:/user/appdata/JSH/profile.js", JSH_PROFILE_DEFAULT);
        }

        // Load profile
        try {
            const profileModule = await include("C:/user/appdata/JSH/profile.js");
        
            if(profileModule.init) {
                const result = await profileModule.init({
                    config: JshConfig,
                    term,
                    app: this
                });

                if(result == 255)
                    return;
            }
        } catch(e) {
            term.print("Cannot load profile due to the following error:");
            term.print(inspect(e));
        }

        term.writeln(term.color`{hex('#d75fff') JS Shell v1.0}`);

        let ctrlCcount = 0;
        let depth = 1;
        while(true){
            try {
                let str = await term.prompt(JshConfig.prompt, true);

                if (!str) {
                    ctrlCcount += 1;
                    if (ctrlCcount === 1) term.writeln('\nPress Ctrl+C again to quit.');
                    if (ctrlCcount === 2) break;
                } else {
                    // We do a little processing
                    const args = str.split(' ');

                    if(args[0].startsWith(REPL_CMD_PREFIX)) {
                        // Check if cmd is internal REPL command
                        const cmdObj = REPL_COMMANDS.find(x => x.name == args[0].substring(REPL_CMD_PREFIX.length));

                        if(cmdObj) {
                            // Execute command
                            const result = await cmdObj.exec(args, str, term);

                            // Quit app
                            if(result == 255)
                                break;

                            continue;
                        }
                    }

                    ctrlCcount = 0;
                    let e = eval(str);
                    if (e instanceof Promise) e = await e;
                    e = inspect(e, {depth, colors: true});
                    //e = xInspect(e);
                    term.writeln(e);
                }
            } catch(e) {
                term.writeln(term.color.red(e.toString()));
            }
        }
    }
}