Drop items into this folder to show it in quick launch.

Note: some themes may not play well with this extension. This is up to the theme developer to fix.