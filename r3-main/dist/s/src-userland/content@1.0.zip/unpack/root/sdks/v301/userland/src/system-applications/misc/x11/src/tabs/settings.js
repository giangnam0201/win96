/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates the settings tab.
 * @param {TabControl} tabc Tab controller.
 * @param {X11Application} app The app instance.
 */
function createSettingsTab(tabc, app) {
    tabc.addPage("Settings", (e) => {
        e.innerHTML = `<div class="pg-content">
            <div class="explanation">
                You can configure the Xpra client to your likings below.<br><br>
                Please note, some of these settings only take effect after a full app restart!<br><br>
            </div>
            <div class="integbox"></div><br>
            <div class="miscbox"></div>
        </div>`;

        // -------- Integrations box --------
        const integrationsBox = new GroupBox({ title: "Integrations" });
        const integrationsBoxEl = integrationsBox.getElement();

        // Create checkbox
        integrationsBoxEl.querySelector(".content").appendChild(new CheckBox({
            label: "Enable X11 app browser (xdg menu) in start menu",
            checked: CL_SETTINGS.registerStartMenuItem,
            onchange: async (e)=>{
                CL_SETTINGS.registerStartMenuItem = e.checked;
                CL_SETTINGS_MODIFIED = true;
            },
            displayAsBlock: true
        }).getElement());

        integrationsBoxEl.querySelector(".content").appendChild(new CheckBox({
            label: "Load icons for XDG menu items",
            checked: CL_SETTINGS.loadXdgIcons,
            onchange: async (e)=>{
                CL_SETTINGS.loadXdgIcons = e.checked;
                CL_SETTINGS_MODIFIED = true;
            },
            displayAsBlock: true
        }).getElement());

        e.querySelector(".integbox").replaceWith(integrationsBoxEl);

        // -------- Miscellaneous box --------
        const miscBox = new GroupBox({ title: "Miscellaneous" });
        const miscBoxEl = miscBox.getElement();

        // Create checkbox
        miscBoxEl.querySelector(".content").appendChild(new CheckBox({
            label: "Use colored border to distinguish X11 applications",
            checked: CL_SETTINGS.distinguishX11Windows,
            onchange: async (e)=>{
                CL_SETTINGS.distinguishX11Windows = e.checked;
                CL_SETTINGS_MODIFIED = true;
            },
            displayAsBlock: true
        }).getElement());

        e.querySelector(".miscbox").replaceWith(miscBoxEl);
    });
}