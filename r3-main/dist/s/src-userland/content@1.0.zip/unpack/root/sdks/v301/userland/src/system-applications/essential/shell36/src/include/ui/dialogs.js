/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Shows a shortcut creation dialog.
 * @param {String} saveDir The save directory for this shortcut.
 */
async function showNewShortcutDialog(saveDir) {
    let lastBlobURL;

    const wnd = new StandardWindow({
        title: "New Shortcut",
        initialHeight: 115,
        initialWidth: 320,
        resizable: false,
        controlBoxStyle: "WS_CBX_CLOSE",
        body: `
        <div class="p1">
            <button class="w96-button icon-box" style="background-image: url(${await Theme.getIconUrl("mime/unknown")})"></button>
        </div>
        <div class="p2">
            <div class="field"><span>Name</span><input class="w96-textbox name"></div>
            <div class="field"><span>Command</span><input class="w96-textbox cmd"></div>
            <button class="w96-button cancel">Cancel</button><button class="w96-button create">Create</button>
        </div>`,
        bodyClass: "dlg-newshortcut",
        center: true
    });

    const wc = wnd.getBodyContainer();
    const iconWell = wc.querySelector('button.icon-box');
    iconWell.setAttribute("img", "W:/" + await Theme.getIconUrl("mime/unknown"));

    wc.querySelector('button.cancel').addEventListener('click', ()=>wnd.close());

    wc.querySelector('button.create').addEventListener('click', async()=>{
        const name = wc.querySelector('.w96-textbox.name').value;
        const command = wc.querySelector('.w96-textbox.cmd').value;

        if((name == null)
        || (name.trim() == "")
        || (command == null)
        || (command.trim() == "")) {
            MsgBoxSimple.error("Invalid shortcut", "Cannot create shortcut, missing data.", "OK");
        }

        /** @type {HTMLButtonElement} */
        wc.querySelector('button.create').disabled = true;

        await FS.writestr(`${saveDir}/${name}.link`, JSON.stringify({
            "icon": iconWell.getAttribute("img"),
            "action": command
        }));

        w96.evt.ui.emit('reload-desktop');

        wnd.close();
    });

    iconWell.addEventListener('click', ()=>{
        new OpenFileDialog(Theme.registeredThemes[Theme.currentTheme].iconTheme ?? "C:/", [".png", ".PNG", ".gif", ".GIF", ".jpg", ".JPG"], async(result)=>{
            if(result == null)
                return;
            
            const blob = await FS.toBlob(result);

            if(lastBlobURL != null)
                URL.revokeObjectURL(lastBlobURL);

            const iconPreview = URL.createObjectURL(blob);
            iconWell.style.backgroundImage = `url(${iconPreview})`;
            lastBlobURL = iconPreview;
            iconWell.setAttribute("img", result);
        }).show();
    });

    wnd.show();
    await wnd.wait();
    URL.revokeObjectURL(lastBlobURL);
}
