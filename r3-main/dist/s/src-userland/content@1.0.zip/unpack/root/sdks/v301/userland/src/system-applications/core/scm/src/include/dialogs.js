/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Path UI delete.
 */
function uiDelete(app, path) {
    if ((!path.includes('/')) || (path.startsWith("/")) || (!app.selectedIcon))
        return; // We cannot delete a root

    DialogCreator.confirm(`Are you sure you want to delete '${path}'?`, {}, (v) => {
        if (!v)
            return;

        const result = SCM.remove(path);

        if (result) {
            SCM.syncRoot(path.split('/')[0]);
            app.refreshView();
        } else
            DialogCreator.alert(`Unable to delete '${path}'.`, { icon: "error" });
    });
}

/**
 * New Key UI.
 */
function uiNewKey(app, path) {
    if (path.trim() == "")
        return; // We cannot create at the top level

    DialogCreator.prompt(`Enter a new key name.<br><br>Please note that this should be alphanumeric, without spaces, for maximum compatibility.`, { title: "Enter Key Name" }, (v) => {
        if ((!v) || (v.trim() == ""))
            return;

        const target = `${path}/${v}`;

        if (SCM.get(target) !== undefined) {
            DialogCreator.alert(`Unable to create '${target}': Item exists.`, { icon: "error" });
            return;
        }

        const o = SCM.get(path);
        o[v] = {};
        SCM.syncRoot(path.split('/')[0]);
        app.refreshView();
    });
}

/**
 * New value UI.
 * @param {"new-value"|"insert-json"|"edit-value"} mode Value creation mode.
 * @param {String} target Optional target.
 */
function uiNewValue(app, mode = "new-value", target = null) {
    let title;

    const fields = [
        { name: 'oname', type: 'textbox', caption: 'Object Name' },
        { name: 'ojson', type: 'textbox', multiline: true, caption: 'JSON Value', value: "{}" }
    ];

    // New value "modes"
    switch(mode) {
        case "new-value":
            title = "New Value";
            fields[1].value = "null"; // Null is valid
            break;
        case "edit-value":
            title = "Edit Value";
            fields[0].value = target;
            fields[1].value = JSON.stringify(SCM.get(`${app.currentPath}/${fields[0].value}`));
            break;
        case "insert-json":
            title = "Insert Json Value";
            break;
    }

    // Create the dialog
    return DialogCreator.fieldset(fields, {
        title,
        onvalidate: (values) => {
            const oname = values.find(x => x.name == "oname");
            const ojson = values.find(x => x.name == "ojson");

            // Check fields

            if (oname.value.trim() == "") {
                alert("No object name has been provided.", { icon: "error" });
                return false;
            } else if (oname.value.includes("/")) {
                alert("An invalid object name has been provided.", { icon: "error" });
                return false;
            } else if (ojson.value.trim() == "") {
                alert("No JSON has been provided", { icon: "error" });
                return false;
            }

            // Check if target exists
            // Only needed for "new"||"insert" modes
            const target = `${app.currentPath}/${oname.value}`;

            if ((mode !== "edit-value") && (SCM.get(target) !== undefined)) {
                DialogCreator.alert(`Unable to create '${target}': Item exists.`, { icon: "error" });
                return false;
            }

            // Do parsing test
            try {
                JSON.parse(ojson.value);
            } catch (e) {
                alert("The specified JSON cannot be parsed.", { icon: "error" });
                return false;
            }

            return true;
        }
    },
    async (values) => {
        if (!values)
            return;

        const objectName = values.find(x => x.name == "oname").value;
        const objectJson = values.find(x => x.name == "ojson").value;
        const o = SCM.get(app.currentPath);
        o[objectName] = JSON.parse(objectJson);
        await SCM.syncRoot(app.currentPath.split('/')[0]);
        app.refreshView();
    });
}