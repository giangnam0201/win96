/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { requestTerminal } = w96.util;

const SUPPRESS_MSGS = [
    "wine_notify_icon not implemented",
    "boxeddrv_SetWindowStyle not implemented",
    "boxeddrv_SetCapture not implemented",
    "boxeddrv_ClipCursor not implemented"
];

/**
 * Represents a console redirector.
 */
class ConsoleRedirector {
    constructor() {
        /**
         * Terminal interface.
         */
        this.tInt = null;
    }

    /**
     * Initializes the console redirector.
     * @param {String} title The console title.
     * @param {String} icon The console icon.
     */
    async init(title = null, icon = null) {
        this.tInt = await requestTerminal(title, icon);
    }

    /**
     * Writes some text.
     * @param {String} text The text to write.
     */
    write(text) {
        if(SUPPRESS_MSGS.includes(text.trim()))
            return;

        this.tInt.terminal.println(text);
    }

    // Redirected functions from `console`
    log(text) { this.write(text); }
    error(text) { this.write(`\u001b[31m${text}\u001b[0m`); }
    warn(text) { this.write(`\u001b[33m${text}\u001b[0m`); }
    info(text) { this.write(`\u001b[36m${text}\u001b[0m`); }
    clear() { this.tInt.terminal.clear(); }
    trace() { /* not implemented */ }
    assert() { /* not implemented */ }
    debug() { /* not implemented */ }
}