/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WizardBaseApplication } = w96.app.templates;
const { Theme } = w96.ui;

const installationTypes = {
    lite: {
        name: "Lightweight Installation",
        zip: "/system/images/rootfs/lite.zip"
    },
    full: {
        name: "Full Installation",
        zip: "/system/images/rootfs/rootfs.zip"
    }
};

let chosenInstallType;

/**
 * Creates an XML HTTP Request to download content.
 * @param {String} url The URL to download from.
 * @param {Function} onprogress Progress callback.
 * @returns {Promise<XMLHttpRequest>}
 */
function downloadContent(url, onprogress) {
    return new Promise((resolve)=>{
        const xhr = new XMLHttpRequest();

        xhr.addEventListener('progress', (e)=> onprogress(e));
        xhr.onload = () => resolve(xhr);
        xhr.responseType = "arraybuffer";

        xhr.open("GET", url);
        xhr.send();
    });
}

/**
 * Extracts this ZIP file to root.
 * @param {*} data The data to use.
 */
async function extractZIPToRoot(data, onprogress) {
    const jsz = await JSZip.loadAsync(data);
    const kz = Object.keys(jsz.files);

    for(var x = 0; x < kz.length; x++) {
        const k = kz[x];
        const entry = jsz.files[k];
        var path = entry.name;

        if(!path.startsWith("/")) path = "/" + path;
        if(path.endsWith("/")) path = path.substring(0, path.length - 1);

        if(onprogress)
            onprogress({
                curFile: x + 1,
                totalFiles: kz.length,
                curPath: path
            });

        console.log("Write c:" + path);

        if(entry.dir) {
            await FS.mkdir(path);
        } else {
            var bdata = await entry.async('uint8array');
            var parent = FSUtil.getParentPath(path);
            if(!(await FS.exists(parent)))
                await FS.mkdir(parent);
            // console.log("Creating " + parent);
            await FS.writebin(path, bdata);
        }
    }
}

class OOBEApplication extends WizardBaseApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        // Setup intro page
        const introPage = this.findPage("intro");
        introPage.titleText = "Welcome to Windows 96";
        introPage.graphic = "/system/resource/app/oobe/graphic.png";
        introPage.body = `This wizard will help you configure your new installation of Windows 96 quickly and efficiently.<br><br>
        In the next page, you will be able to select your desired installation type, which will decide what base applications will be installed.
        <br><br>This should take less than a minute to configure, depending on your internet connection and chosen installation type.`;
        introPage.buttons[1].onclick = ()=>this.openPage("install-type", []);

        // Installation type screen
        this.pages.push({
            id: "install-type",
            type: "page",
            body: `Select an installation type:
                <br>
                <div class="icon-opt-select">
                    <div class="option full">
                        <button style="background-image: url(${await Theme.getIconUrl("devices/hdd", "32x32")})" class="w96-button btn"></button>
                        <div class="text">
                            <span class="title bold-noaa">Full Install</span>
                            <span class="explanation">Full installation - will install the full Windows 96 environment with all of its system applications.</span>
                        </div>
                    </div>

                    <div class="option lite">
                        <button style="background-image: url(${await Theme.getIconUrl("devices/floppy", "32x32")}); filter: grayscale(1);" class="w96-button btn"></button>
                        <div class="text">
                            <span class="title bold-noaa">Lightweight Install</span>
                            <span class="explanation">Minimal installation size - only the essential applications/data to get you started.</span>
                        </div>
                    </div>
                </div>`,
            graphic: "/system/resource/app/oobe/graphic-top.png",
            titleText: "Select an installation type",
            description: "Choose how you want to install your new operating system.",
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("intro", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{},
                    enabled: false,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{
                // Setup events
                page.querySelector(".option.lite>button").addEventListener('click', ()=>{
                    this.openPage("install-confirm", ["lite"]);
                });

                page.querySelector(".option.full>button").addEventListener('click', ()=>{
                    this.openPage("install-confirm", ["full"]);
                });
            }
        });

        // Install confirm dialog
        this.pages.push({
            id: "install-confirm",
            type: "page",
            body: `
                <div>
                    Installation Type: <span class="install-type"></span><br><br>
                    To begin the installation, press the next button.<br><br>
                    Please note that this may take time depending on your chosen installation type.<br><br>
                    Do not shut down during this process - you will likely end up with a corrupted installation!
                </div>
            `,
            graphic: "/system/resource/app/oobe/graphic-top.png",
            titleText: "Begin the installation",
            description: `Read the information below carefully.`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("install-type", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{
                        this.openPage("install", [])
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{
                chosenInstallType = installationTypes[args[0]];
                page.querySelector(".install-type").textContent = chosenInstallType.name;
            }
        });

        // Install progress dialog
        this.pages.push({
            id: "install",
            type: "page",
            body: `
                <div>
                    Installing Windows 96 - please wait...<br>
                    <br>
                    Current progress: <span class="prog-text"></span>
                    <div class="w96-progressbar" style="margin-top: 16px;">
                        <div class="progress" style="width: 0%; animation: none;"></div>
                    </div>
                </div>
            `,
            graphic: "/system/resource/app/oobe/graphic-top.png",
            titleText: "Installation",
            description: `Please wait until the installation has concluded.`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>{},
                    enabled: false,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{},
                    enabled: false,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: false,
                    text: "Cancel"
                }
            ],
            onopen: async (page, args)=>{
                const progressTextEl = page.querySelector(".prog-text");
                const progressEl = page.querySelector(".progress");

                // Download RootFS
                progressTextEl.innerText = "Downloading RootFS ZIP...";

                let xhr;

                try {
                    xhr = await downloadContent(chosenInstallType.zip, (e)=>{
                        const percentage = (e.loaded / e.total) * 50;
                        progressEl.style.width = `${percentage}%`;
                    });
                } catch(e) {
                    // Conclude install failure - repurpose intro page
                    const introPage = this.findPage("intro");
                    introPage.titleText = "Installation Failed";
                    introPage.body = `Windows 96 was not installed successfully on this system. Check your internet connection, or try again later.<br><br>Press Finish to restart.`;
                    introPage.graphic = "/system/resource/app/oobe/graphic.png";
                    introPage.buttons[1].onclick = ()=>w96.sys.reboot();
                    introPage.buttons[1].text = "Finish";
                    introPage.buttons[2].enabled = false;
                    this.openPage("intro", []);
                    this.mainwnd.getBodyContainer().querySelector(".explain").textContent = "Click Finish to exit.";
                    return;
                }

                // Extract rootfs
                progressTextEl.innerText = "Extracting RootFS to disk...";

                console.log(xhr.response);

                await extractZIPToRoot(xhr.response, (e)=>{
                    progressTextEl.innerText = `Writing ${e.curPath}`;
                    progressEl.style.width = `${50 + ((e.curFile/e.totalFiles) * 50)}%`;
                });

                // Delete stage file if it exists
                console.log("Deleting stage file...");

                // Ensure files deletion
                let mustDelete = [
                    "c:/.gitkeep",
                    "c:/system/local/bin/uinit_stage3",
                    "c:/system/local/bin/oobe",
                    "c:/system/local/bin/v2mig"
                ];
                
                for (let file of mustDelete){
                    if(await FS.exists(file))
                        await FS.rm(file);
                }

                // Conclude install - repurpose intro page
                const introPage = this.findPage("intro");
                introPage.titleText = "Installation Complete";
                introPage.body = `The installation for Windows 96 has completed successfully.<br><br>Press Finish to restart.`;
                introPage.buttons[1].onclick = async()=>{
                    // Commit install state to disk
                    await FS.writestr("C:/system/etc/inststate.json", JSON.stringify({
                        rootfs: chosenInstallType.zip,
                        version: await w96.sys.rel.getVersionString(),
                        installDate: new Date().toUTCString()
                    }, null, 4));
                    w96.sys.reboot();
                }
                introPage.buttons[1].text = "Finish";
                introPage.buttons[2].enabled = false;
                this.openPage("intro", []);

                this.mainwnd.getBodyContainer().querySelector(".explain").textContent = "Click Finish to exit.";
            }
        });

        this.openPage("intro", []);
        this.mainwnd.setTitle("Windows 96 Installer");
        this.mainwnd.setControlBoxStyle("WS_CBX_NONE");
        this.mainwnd.setWindowIcon(await Theme.getIconUrl("misc/logo", '16x16'));
        this.mainwnd.center();
    }
}