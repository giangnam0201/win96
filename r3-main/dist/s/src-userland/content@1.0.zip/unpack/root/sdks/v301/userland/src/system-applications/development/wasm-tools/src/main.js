/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, OpenFileDialog, MsgBoxSimple } = w96.ui;
const { TabControl } = w96.ui.components;
const { wasm: WASM } = w96.sys;

function npeek(n) {
    return (n == null) ? -1 : n;
}

function acmp(a1, a2) {
    if(a1.length !== a2.length)
        return false;

    for(let x = 0; x < a1.length; x++)
        if(a1[x] != a2[x])
            return false;

    return true;
}

class WASMToolsApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        // Check for wasm support

        if(typeof WebAssembly === 'undefined') {
            MsgBoxSimple.error("Unsupported Platform", '<span class="bold-noaa">Critical Error:</span> This browser does not support WebAssembly.', "OK");
            return;
        }

        if(argv[1] == null) {
            new OpenFileDialog("c:/", ["wasm", "WASM"], (fn)=>{
                if(!fn) {
                    this.terminate();
                    return;
                }
                this._createWindow(fn);
            }).show();
            return;
        }

        this._createWindow(argv[1]);
    }

    async _createWindow(fn) {
        var params = new WindowParams();
        params.title = "WASM Tools";
        params.initialWidth = 410;
        params.initialHeight = 365;
        params.resizable = true;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(``);
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/wasm-tools", '16x16'));

        const htmlContainer = mainwnd.wndObject.querySelector(".window-html-content");
        htmlContainer.classList.add("wasmtools-app");

        const tabc = new TabControl();

        try {
            await this.loadFile(fn);
        } catch(e) {
            console.log(e);
            MsgBoxSimple.error("Error", "Cannot load WebAssembly file!", "OK");
            this.terminate();
        }

        const pageId = tabc.addPage("Exported Functions", (c)=>this._page_exportedFunctions(c));

        tabc.setSize('100%', '100%');
        htmlContainer.appendChild(tabc.getElement());

        const footer = document.createElement('footer');
        footer.classList.add('w96-footer');
        footer.innerText = fn;
        htmlContainer.appendChild(footer);

        // Start the app
        mainwnd.show();
        tabc.openPage(pageId);
    }

    async _page_exportedFunctions(container) {
        const exportsDiv = document.createElement('div');
        exportsDiv.classList.add('readonly-tbox');
        
        this.exports.forEach((e)=>{
            const line = document.createElement('span');
            line.classList.add('line');
            line.innerHTML = '<span style="color: royalblue">ƒ</span> ' + e;
            exportsDiv.appendChild(line);
        });

        container.appendChild(exportsDiv);
    }

    /**
     * Reads imports from wasm bin data.
     * @param {Uint8Array} binData The binary data to read.
     */
    readImports(binData) {
        const importsReadEnd = [0x0, 0x1, 0x3];
        const strippedData = [];
        
        for(let x = 6; x < binData.length; x++) {
            if(acmp([npeek(binData[x]), npeek(binData[x + 1]), npeek(binData[x + 2])], importsReadEnd))
                break;
            
            strippedData.push(binData[x]);
        }

        const rawString = [];
        strippedData.forEach((v)=>rawString.push(String.fromCharCode(v)));
        const str = rawString.join('').replace(/\W/gi, ' '); 
        const imports = str.split(' ').filter((v)=>{
            if(v == "") return false;
            if(v == "imports") return false;
            if(/^[0-9]/.test(v)) return false;

            return true;
        });

        return imports;
    }

    async loadFile(fn) {
        const prgm = await WASM.loadLocal(fn, true);
        this.exports = Object.keys(prgm.instance.exports);
    }
}