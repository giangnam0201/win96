/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * CLI exit code. These codes instruct the application what to do after processing CLI arguments.
 */
const CLI_PROC_RESULT = {
    OK: 0,
    EXIT: -1
}

/**
 * Processes CLI arguments.
 * @param {string[]} argv Program arguments.
 * @param {X11Application} app The app instance.
 * @returns 
 */
async function processCLICommands(argv, app) {
    // Check if we even have arguments
    const command = argv[1];

    if((command == null) || (command.trim() == ""))
        return CLI_PROC_RESULT.OK; // Do nothing

    // Process command
    switch(command) {
        default:
            alert("Invalid CLI usage.", { title: "X11/Xpra Client" });
            return CLI_PROC_RESULT.EXIT;
        case "connect": {
            const target = argv[2].split(':');
            const address = target[0];
            const port = parseInt(target[1]);

            if(mutex.find("xpra::app") != null) {
                // We are a secondary instance - inform via IPC of new connection
                w96.ipc.findIpcEQ("xpra").emit("connect", address, port);
                return CLI_PROC_RESULT.EXIT;
            } else {
                // Set startup flags
                XPRA_STARTUP_FLAGS.startupClient = {
                    address,
                    port
                }
            }

            break;
        }
    }

    return CLI_PROC_RESULT.OK;
}