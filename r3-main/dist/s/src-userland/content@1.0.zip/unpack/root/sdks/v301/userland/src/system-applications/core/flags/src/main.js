/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { DialogCreator, Theme, MenuBar } = w96.ui;
const { ListBox } = w96.ui.components;
const { has: hasFlag, set: setFlag, clear: clearFlags } = w96.sys.flags;
const { getReleaseChannel } = w96.sys.rel;

const systemFlags = [
    {
        displayName: "Disable anti-virus service",
        name: "av_svc_disabled",
        description: "Disable the anti-virus service.",
        args: []
    },
    {
        displayName: "Disable analytics and tracking",
        name: "disable_analytics",
        description: "Disables the analytics script ran on startup.",
        args: []
    },
    {
        displayName: "Simulate missing IndexedDB",
        name: "simulate_missing_idb",
        description: "Removes indexedDb from the session to simulate a missing storage backend.",
        args: []
    },
    {
        displayName: "Disable WebAssembly",
        name: "simulate_no_wasm",
        description: "Removes WebAssembly from the current session.",
        args: []
    },
    {
        displayName: "Do not mount W:/",
        name: "sys_ignore_mount",
        description: "Does not mount the W:/ system drive upon boot.",
        args: []
    },
    {
        displayName: "Disable update notifications",
        name: "no_update_notifs",
        description: "Disables the system update notification.",
        args: []
    },
    {
        displayName: "Disable boot scripts",
        name: "no_boot_scripts",
        description: "Disables the processing of scripts in c:/system/boot during startup.",
        args: []
    },
    {
        displayName: "Disable desktop icons",
        name: "no_desktop_icons",
        description: "Stops desktop icons from appearing.",
        args: []
    },
    {
        displayName: "Hide build info",
        name: "no_build_info",
        description: "Hides the build info from the desktop.",
        args: []
    },
    {
        displayName: "Force pixelated image rendering",
        name: "force_pixel_render",
        description: "Forces the browser to render all images pixelated.",
        args: []
    },
    {
        displayName: "Disable fast booting",
        name: "no_fastboot",
        description: "Enables kernel debug timers. These are disabled by default.",
        args: []
    },
    {
        displayName: "Display exceptions",
        name: "exclaim_exceptions",
        description: "Shows error dialogs for exceptions that occur during your session.",
        args: []
    },
    {
        displayName: "Do not load previous desktop icon positions",
        name: "no_icon_positioning",
        description: "Prevents desktop icons from loading in their last placed positions.",
        args: []
    },
    {
        displayName: "Disable new bootscreen",
        name: "disable_new_bootscreen",
        description: "Disables the beta version of the startup screen",
        args: []
    },
    {
        displayName: "Disable window compositing",
        name: "disable_wcomp",
        description: "Disables window compositing (may break some themes).",
        args: []
    },
    {
        displayName: "Disable eastereggs",
        name: "disable_easter_eggs",
        description: "Disables eastereggs and other jokes.",
        args: []
    },
    {
        displayName: "Disable system log",
        name: "disable_syslog",
        description: "Disables the system event log (not recommended).",
        args: []
    }
    /*{
        displayName: "Enable Service Worker",
        name: "enable_sw",
        description: "Enable the caching service worker. THIS MAY BREAK UPDATES. You have been warned.",
        args: []
    }*/
];

class FlagsApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        // Add a battery API flag if the browser supports it
        if(typeof BatteryManager !== 'undefined') {
            systemFlags.push({
                displayName: "Disable battery monitoring",
                name: "disable_battery_api",
                description: "Disables the battery monitoring service.",
                args: []
            });
        }

        if((getReleaseChannel() == "staging") || (getReleaseChannel() == "development")) {
            systemFlags.push({
                displayName: "Disable \"Comments?\" button",
                name: "disable_comments_btn",
                description: "Disables the Comments button on all windows.",
                args: []
            });
        }

        const mainwnd = this.createWindow({
            title: "System Flags",
            icon: await Theme.getIconUrl("objects/tools", '16x16'),
            body: `
            <div class="appbar"></div>
            <div class="container">
                <div class="list-box"></div>
                <div class="buttons">
                    <button class="w96-button toggle" disabled>Enable</button>
                    <button class="w96-button clear">Clear All</button>
                    <button class="w96-button reboot">Reboot</button>
                </div>
            </div>
            <footer class="w96-footer">
                <div class="cell">
                    ${systemFlags.length} available flags
                </div>
            </footer>`,
            bodyClass: "wflags-app",
            center: true,
            initialWidth: 500,
            height: 340,
            taskbar: true
        }, true);

        // Create app bar
        const appbar = new MenuBar();

        appbar.addRoot('File', [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        appbar.addRoot('Help', [
            {
                type: "normal",
                label: "About",
                onclick: ()=>DialogCreator.create({
                    title: "About",
                    icon: "info",
                    body: `<span class="bold-noaa">System Flags 1.0.</span><br><br>Copyright (C) windows96.net 2023.`
                })
            }
        ]);

        const body = mainwnd.getBodyContainer();
        body.querySelector(".appbar").replaceWith(appbar.getMenuDiv());

        // Create flags list box
        const listBox = new ListBox();

        for(let f of systemFlags) {
            const e = listBox.addItem(f.displayName, f.name);


            if(hasFlag(f.name))
                e.classList.add('enabled');

            e.innerHTML = `
                <span class="bold-noaa">${f.displayName} <i style="opacity: 50%">[${f.name}]</i></span><br>
                ${f.description}
            `;

            e.addEventListener('dblclick', () => {
                const toggleBtn = body.querySelector('button.toggle');
                toggleBtn.click();
            });

            e.addEventListener('click', ()=>{
                const toggleBtn = body.querySelector('button.toggle');
                toggleBtn.disabled = false;

                let disableCb = ()=>{
                    e.classList.remove('enabled');
                    toggleBtn.innerText = "Enable";

                    if(hasFlag(f.name))
                        setFlag(f.name, false);

                    toggleBtn.onclick = enableCb;
                };

                let enableCb = ()=>{
                    e.classList.add('enabled');
                    toggleBtn.innerText = "Disable";

                    if(!hasFlag(f.name))
                        setFlag(f.name);

                    toggleBtn.onclick = disableCb;
                };

                if(e.classList.contains('enabled')) {
                    toggleBtn.innerText = "Disable";

                    // Event to disable flag
                    toggleBtn.onclick = disableCb;
                } else {
                    toggleBtn.innerText = "Enable";

                    // Event to enable flag
                    toggleBtn.onclick = enableCb;
                }
            });
        }

        const listBoxEl = listBox.getElement();
        body.querySelector('.list-box').replaceWith(listBoxEl);

        // Set some events
        body.querySelector('button.reboot').addEventListener('click', ()=>document.location.reload());

        body.querySelector('button.clear').addEventListener('click', ()=>{
            listBoxEl.querySelectorAll('.item').forEach((v)=>v.classList.remove('enabled'));
            clearFlags();
        });

        mainwnd.show();

        if(localStorage.getItem("flags_first_time_done") !== "true") {
            DialogCreator.create({
                title: "Warning",
                icon: "warning",
                body: `<span class="bold-noaa">This tool is intended for developers or for troubleshooting.</span><br>Changing any of these options may cause instability or a loss of data.<br>We will not provide any support for systems with flags enabled.`
            });

            localStorage.setItem("flags_first_time_done", "true");
        }
    }
}