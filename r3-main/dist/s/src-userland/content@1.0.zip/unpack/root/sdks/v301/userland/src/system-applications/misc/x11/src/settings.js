/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Client default settings.
 */
const CL_DEFAULT_SETTINGS = {
    /**
     * Whether to register the X11 start menu item.
     */
    registerStartMenuItem: true,

    /**
     * Whether to distinguish X11 windows using a custom color.
     */
    distinguishX11Windows: false,

    /**
     * Whether to load xdg menu icons.
     */
    loadXdgIcons: true
}

/**
 * Xpra client settings. These settings are synced to SCM upon application closure.
 * @type {CL_DEFAULT_SETTINGS}
 */
let CL_SETTINGS = { };

/**
 * Whether to commit to SCM on app exit.
 */
let CL_SETTINGS_MODIFIED = false;

/**
 * Retrieves client settings from SCM.
 * 
 * Commits the defaults if the settings do not exist.
 */
async function loadSettings() {
    CL_SETTINGS = SCM.get("Software/XpraClient");

    if(CL_SETTINGS == undefined) {
        CL_SETTINGS = {... CL_DEFAULT_SETTINGS };
        await SCM.setAndSync("Software/XpraClient", CL_SETTINGS);
    }
}

/**
 * Synchronizes SCM with the current settings.
 */
const syncSettings = async() => await SCM.setAndSync("Software/XpraClient", CL_SETTINGS);
