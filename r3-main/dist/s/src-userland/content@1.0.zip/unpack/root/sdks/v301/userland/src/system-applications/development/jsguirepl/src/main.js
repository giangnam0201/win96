/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { DialogCreator, Theme, MenuBar } = w96.ui;
const { DomUtils } = w96.util;

class JSGUIRepl extends WApplication {
    constructor() {
        super();

        this.stats = {
            errors: 0
        }
    }

    async main(argv) {
        super.main(argv);

        const mainwnd = this.createWindow({
            title: "JS REPL (Gui)",
            icon: await Theme.getIconUrl("apps/js", '16x16'),
            taskbar: true,
            bodyClass: "jsguirepl-app",
            initialHeight: 400,
            initialWidth: 520,
            body: `<div class="appbar"></div>
            <div class="view w96-inset">
                <div class="history"></div>
                <div class="input">
                    <input class="w96-textbox" type="text">
                </div>
            </div>
            <footer class="w96-footer">
                <div class="cell">
                    0 errors
                </div>
            </footer>`
        }, true);

        const body = mainwnd.getBodyContainer();
        
        const appbar = new MenuBar();

        appbar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>mainwnd.close()
            }
        ]);

        appbar.addRoot("View", [
            {
                type: "normal",
                label: "Clear History (CTRL + L)",
                onclick: ()=>this.clearConsole()
            }
        ]);

        appbar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>DialogCreator.alert('<span class="bold-noaa">JS REPL (Gui)</span><br>Version 1.0<br>', {
                    title: "About JS REPL (Gui)",
                    icon: "info"
                })
            }
        ]);

        this.mainwnd = mainwnd;

        body.querySelector(".appbar").replaceWith(appbar.getMenuDiv());

        this.setupInputBox();

        mainwnd.show();
    }

    clearConsole() {
        const body = this.mainwnd.getBodyContainer();
        const historyElement = body.querySelector(".history");

        while(historyElement.firstChild)
            historyElement.removeChild(historyElement.firstChild);
    }

    pushConsoleMessage(userOptions, content) {
        const options = {
            type: "text",
            severity: "none",
            caller: "code", // code | user
            ...userOptions
        };

        const line = DomUtils.mkElement("div", ["line", `caller-${options.caller}`]);

        switch(options.severity) {
            case "none":
                break;

            default:
                line.classList.add(options.severity);
                break;
        }

        if((options.type == "text") && (content !== undefined)) {
            line.innerText = content;
        }

        const body = this.mainwnd.getBodyContainer();
        const historyElement = body.querySelector(".history");
        historyElement.appendChild(line);
        historyElement.scrollTop = historyElement.scrollHeight;

        return line;
    }

    setupInputBox() {
        const body = this.mainwnd.getBodyContainer();
        const input = body.querySelector('input');
        const historyElement = body.querySelector(".history");

        input.addEventListener('keydown', (e)=>{
            if(e.ctrlKey && (e.key == "l")) {
                e.preventDefault();
                this.clearConsole();
            } else if(e.key == "Enter") {
                if(input.value.trim() == "")
                    return;

                this.pushConsoleMessage({
                    caller: "user"
                }, input.value);

                // Process input value

                this.evaluate(input.value);
                historyElement.scrollTop = historyElement.scrollHeight;

                // Clear input value for next eval

                input.value = "";

                return;
            }
        });
    }

    formatObject(msg, result) {
        // Basic formatting

        switch(typeof result) {
            case "bigint":
            case "number":
                msg.classList.add('js-number');
                return;
            case "string":
                msg.classList.add('js-string');
                msg.innerText = `"${msg.innerText}"`;
                return;
            case "undefined":
                msg.classList.add('js-undefined');
                msg.innerText = "undefined";
                return;
            case "symbol":
                msg.classList.add('js-symbol');
                msg.innerText = "Symbol";
                return;
            case "boolean":
                msg.classList.add('js-bool');
                return;
        }

        if(result === null) {
            msg.classList.add('js-undefined');
            msg.innerText = "null";
            return;
        }

        // Check for special types
        // e.g. arrays, regex, object, function, etc.

        if(result instanceof Array) {
            let strResult = "";

            if(result.length > 200) {
                strResult = `... large array (${result.length} items) ...`;
            } else  if(result.length == 0) {
                strResult = "";
            } else {
                for(let i of result) {
                    // TODO make this entire function recursive
                    let m = DomUtils.mkElement("span", []);
                    
                    if(typeof i == 'symbol')
                        m.innerText = "Symbol";
                    else if(typeof i == 'function')
                        m.innerText = "ƒ";
                    else if(typeof i == 'object')
                        m.innerText = "{ . obj . }";
                    else m.innerText = i;

                    this.formatObject(m, i);
                    strResult += m.outerHTML + ", ";
                    m = null;
                }
            }
            
            msg.innerHTML = `[ ${strResult.substring(0, strResult.length - 2)} ]`;
        }
    }

    updateErrorCount() {
        const body = this.mainwnd.getBodyContainer();
        this.stats.errors++;
        body.querySelector('.w96-footer .cell').textContent = `${this.stats.errors} error${(this.stats.errors === 1) ? "" : "s"}`;
    }

    evaluate(text) {
        try {
            const result = eval(text);

            const msg = this.pushConsoleMessage({
                caller: "code"
            }, (typeof result !== 'symbol') ? result : ""); // TODO format result

            this.formatObject(msg, result);
        } catch(e) {
            const msg = this.pushConsoleMessage({
                severity: "error",
                caller: "code"
            });

            msg.classList.add('exception'); // Give message error class

            if(e instanceof Error) {
                const errorNameEl = DomUtils.mkElement("span", ["name"]);
                errorNameEl.innerText = `${e.name}: `;

                const errorMsg = DomUtils.mkElement("span", ["message"]);
                errorMsg.innerText = `${e.message}`;
                
                msg.appendChild(errorNameEl);
                msg.appendChild(errorMsg);
            } else {
                // Just print error
                const errorMsg = DomUtils.mkElement("span", ["message"]);
                errorMsg.innerText = `${e.message}`;

                msg.appendChild(errorMsg);
            }

            this.updateErrorCount();
        }
    }
}