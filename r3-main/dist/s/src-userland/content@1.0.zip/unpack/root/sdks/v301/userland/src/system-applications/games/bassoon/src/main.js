/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { OpenFileDialog, Theme } = w96.ui;
const { WindowParams } = w96;

class BassoonTrackerApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this.file = argv[1];
        this._createWindow();
    }

    async _createWindow() {
        var params = new WindowParams();
        params.title = "BassoonTracker";
        params.initialWidth = 780;
        params.initialHeight = 730;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        let fURL;
        if(this.file && (await FS.exists(this.file))) {
            fURL = URL.createObjectURL(new Blob([await FS.readbin(this.file)]));
        }

        mainwnd.setHtml(`<iframe src="/system/apps/bassoon${fURL ? '?file=' + fURL: ''}"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector(".window-html-content");
        wContainer.classList.add("bassoon-app");

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/bassoon", "16x16"));

        const appFrame = mainwnd.wndObject.querySelector("iframe");
        const cw = appFrame.contentWindow;
        cw.W96 = {
            requestFile: cb => {
                new OpenFileDialog("/", ["mod", "xm"], async file => {
                    if(!file) {
                        return;
                    }

                    cb(URL.createObjectURL(new Blob([await FS.readbin(file)])));
                }).show()
            },

            setPlaying: file => {
                if(file) {
                    mainwnd.setTitle(file + " - BassoonTracker");
                } else {
                    mainwnd.setTitle("BassoonTracker");
                }
            }
        }

        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }
}