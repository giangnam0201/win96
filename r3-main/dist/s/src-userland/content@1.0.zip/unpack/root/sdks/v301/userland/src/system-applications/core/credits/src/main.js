/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { DialogCreator } = w96.ui;
const { escapeHtml } = w96.util;

const people = [
    {
        avatar: "url(https://cdn.windows96.net/credits/ctrlz2.png)",
        name: "ctrlz",
        position: "PROJECT CREATOR + LEAD DEVELOPER",
        background: "linear-gradient(1deg, rgb(0 0 0), rgb(19, 104, 154))",
        socials: [
            {
                type: "twitter",
                url: "https://twitter.com/ctrlz40961"
            }
        ]
    },
    {
        avatar: "url(https://cdn.ziad87.net/z-av-256.png)",
        name: "ziad87",
        position: "LEAD DEVELOPER + SYSADMIN",
        background: "linear-gradient(315deg, #000, #00ddfd)",
        socials: [
            {
                type: "github",
                url: "https://github.com/ziad8727"
            },
            {
                type: "site",
                url: "https://ziad87.net"
            }
        ]
    },
    {
        avatar: "url(https://cdn.windows96.net/credits/h.gif)",
        name: "utf-4096",
        position: "LEAD DEVELOPER",
        background: "url(https://cdn.windows96.net/credits/utf_bg.png), #005",
        backgroundSize: "cover",
        socials: [
            {
                type: "gitlab",
                url: "https://git.sys36.net/utf-4096"
            },
            {
                type: "site",
                url: "https://penguins.win"
            }
        ]
    },
    {
        avatar: "url(https://cdn.windows96.net/credits/darkok/avatar.jpg)",
        name: "DarkOK",
        position: "DEVELOPER + KFC MAN",
        background: "url(https://cdn.windows96.net/credits/darkok/bg.jpg), #005",
        backgroundSize: "cover",
        socials: [
            {
                type: "github",
                url: "https://github.com/dakrk"
            }
        ]
    },
    {
        avatar: "url(https://cdn.windows96.net/credits/2048/avatar.gif)",
        name: "2048",
        position: "DEVELOPER + CRITTER ENJOYER",
        background: "#030",
        backgroundSize: "cover",
        socials: [
            {
                type: "twitter",
                url: "https://twitter.com/1024x2"
            },
            {
                type: "gitlab",
                url: "https://gitlab.com/1024x2"
            },
            {
                type: "site",
                url: "https://1024x2.xyz/"
            }
        ]
    }
];

class CreditsUIApplication extends WApplication {
    constructor() {
        super();
    }

    main(argv) {
        super.main(argv);
        const params = new WindowParams();
        params.resizable = false;
        params.title = "WINDOWS 96 CREDITS";
        params.initialWidth = 500;
        params.initialHeight = 420;
        params.mobResize = true;

        const mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.setControlBoxStyle("WS_CBX_CLOSE");
        mainwnd.setHtml(`
            <div class="bg" tabindex="1">
                <div class="avatar"></div>
                <div class="name"></div>
                <div class="position"></div>
                <div class="socials">

                </div>
                <div class="buttons">
                    <button class="previous">Previous</button>
                    <button class="next">Next</button>
                </div>
            </div>
        `);

        const wcontainer = mainwnd.getBodyContainer();
        wcontainer.classList.add('credits-ui');

        const bgEl = wcontainer.querySelector('.bg');
        bgEl.addEventListener('keyup', (e)=> {
            if(e.altKey && e.key == "Enter") {
                // Enter fullscreen and do something wacky?
                bgEl.requestFullscreen();
            } else {
                switch(e.key) {
                    case "R":
                        this.showProfile(Math.floor(Math.random() * people.length));
                        break;
                    case "S":
                        w96.urlopen("http://sys36.net");
                        break;
                    case "B":
                        DialogCreator.alert(`CSS Code for profile:<br> ${escapeHtml(people[this.currentIndex].background)}`, { title: "Credits", icon: "info" })
                        break;
                    case "K":
                        DialogCreator.alert(`ALT+ENTER - Fullscreen mode.<br> SHIFT + B - Display background CSS string.<br> SHIFT + R - Random profile<br> SHIFT + S - Open sys36 site.`, { title: "KEYBINDS", icon: "info" });
                        break;
                }
            }
        });

        // Start the app
        mainwnd.show();
        mainwnd.center();
        this.mainwnd = mainwnd;
        bgEl.focus();

        this.currentIndex = 0;

        const previousButton = wcontainer.querySelector(".previous");
        const nextButton = wcontainer.querySelector(".next");

        previousButton.addEventListener('click', ()=>{
            this.showProfile(--this.currentIndex);
        });

        nextButton.addEventListener('click', ()=>{
            this.showProfile(++this.currentIndex);
        });

        this.showProfile();
    }

    showProfile(index = 0) {
        const wcontainer = this.mainwnd.getBodyContainer();
        const socialsBox = wcontainer.querySelector(".socials");
        const previousButton = wcontainer.querySelector(".previous");
        const nextButton = wcontainer.querySelector(".next");

        previousButton.className = "previous";
        nextButton.className = "next";

        socialsBox.innerHTML = ""; // Clear box

        wcontainer.querySelector(".avatar").style.backgroundImage = people[index].avatar;
        wcontainer.querySelector(".bg").style.background = people[index].background;
        wcontainer.querySelector(".bg").style.backgroundSize = people[index].backgroundSize;
        wcontainer.querySelector(".name").innerText = people[index].name;
        wcontainer.querySelector(".position").innerText = people[index].position;

        for(let social of people[index].socials) {
            const a = document.createElement('a');
            a.classList.add(social.type);
            a.href = social.url;
            socialsBox.appendChild(a);
        }

        if(index < 1)
            previousButton.className = "previous disabled";

        if((index + 1) >= people.length)
            nextButton.className = "next disabled";
    }
}