/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MenuBar, Theme, DialogCreator } = w96.ui;
const { TabControl, ListView, GroupBox, GraphStatBox } = w96.ui.components;
const { procMgr } = w96.state;
const { execCmd } = w96.sys;
const { DomUtils } = w96.util;

$$Include("./util.js")

class TaskManagerApplication extends WApplication {
    constructor() {
        super();
        this.updateInterval = 1000;
        this.updateFunc = null;
        this._state = {
            selectedTask: null
        };
    }

    /**
     * Entry point.
     * @param {String[]} argv Program arguments.
     */
    async main(argv) {
        await super.main(argv);

        this.title = "taskmgr";

        const mainwnd = this.createWindow({
            title: "Task Manager",
            initialWidth: 404,
            initialHeight: 447,
            bodyClass: "taskmgr-app",
            body: `<div class="appbar"></div>
            <div class="tabc"></div>
            <footer class="w96-footer">
                <div class="cell proc">
                    Processes: 0
                </div> 
                <div class="cell mem">
                    Memory Usage: 0 MB
                </div> 
            </footer>`,
            icon: await Theme.getIconUrl("apps/taskmgr", '16x16'),
            taskbar: true
        }, true);

        // Reference body
        const body = mainwnd.getBodyContainer();

        // Create appbar
        const menuBar = new MenuBar();

        menuBar.addRoot("File", [
            {
                type: "normal",
                label: "New Task",
                onclick: ()=>this.showNewTaskDlg()
            },
            { type: "separator" },
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        // menuBar.addRoot("View", [
        //     {
        //         type: "submenu",
        //         label: "Update Speed",
        //         items: [
        //             { type: "normal", label: "High", checked: false, onclick: void 0 },
        //             { type: "normal", label: "Normal", checked: this.updateInterval == 1000, onclick: void 0 },
        //             { type: "normal", label: "Low", onclick: void 0 },
        //             { type: "normal", label: "Paused", onclick: void 0 }
        //         ]
        //     }
        // ], false);

        menuBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: async()=>DialogCreator.alert("<span class=\"bold-noaa\">Task Manager</span><br>Version 1.0", {
                    title: "About",
                    icon: await Theme.getIconUrl("apps/taskmgr")
                })
            }
        ]);

        body.querySelector(".appbar").replaceWith(menuBar.getMenuDiv());

        // Create tab control
        const tabControl = new TabControl();

        // Applications tab
        tabControl.openPage(tabControl.addPage("Applications", async(e) => {
            this._state.selectedTask = null;
            e.classList.add("tab-applications");
            e.style.padding = "15px";
            e.innerHTML = `<div class="table"></div>
            <div class="buttons">
                <button class="w96-button end-task">End Task</button>
                <button class="w96-button switch-to">Switch To</button>
                <button class="w96-button new-task">New Task</button>
            </div>`;
            
            const lvw = new ListView();
            
            lvw.addColumnHeader("Task", 200);
            lvw.addColumnHeader("Status");

            // Enumerate active tasks
            for(let wnd of enumerateTasks()) {
                // Auto select first window
                if(!this._state.selectedTask)
                    this._state.selectedTask = wnd;

                let iconUrl;

                if((wnd.windowIcon != null) && (wnd.windowIcon.trim() != ""))
                    iconUrl = `${wnd.windowIcon}`;
                else
                    iconUrl = `${await Theme.getIconUrl("mime/executable", '16x16')}`;

                const itemEl = lvw.pushData([wnd.title || "<unnamed>", "Running"], iconUrl);

                // TODO add selected event to list view
                itemEl.addEventListener('click', () => {
                    this._state.selectedTask = wnd;
                });

                // On item double click
                itemEl.addEventListener('dblclick', () => this.performSwitchTo(this._state.selectedTask));
            }

            // Set some button events
            e.querySelector("button.end-task").addEventListener('click', () => {
                // Ignore if no task is selected
                if(!this._state.selectedTask)
                    return;

                this._state.selectedTask.close();
                
                setTimeout(() => {
                    if((!this._state) || (!this._state.selectedTask))
                        return;

                    if(!this._state.selectedTask.wndObject) {
                        const i = lvw.getSelectedItem();
                        
                        if(i)
                            i.remove();

                        this._state.selectedTask = null;
                    }
                }, 1000);
            });

            e.querySelector("button.switch-to").addEventListener('click', () => this.performSwitchTo(this._state.selectedTask));
            e.querySelector("button.new-task").addEventListener('click', () => this.showNewTaskDlg());
            e.querySelector(".table").replaceWith(lvw.getElement());

            lvw.select(0);
        }));

        // Processes tab
        tabControl.addPage("Processes", (e) => {
            e.style.padding = "15px";
            e.classList.add("tab-processes");
            e.innerHTML = `<div class="table"></div>
            <div class="buttons">
                <button class="w96-button">End Process</button>
            </div>`;

            // Add processes list view
            const lvw = new ListView();

            lvw.setSelectionMode("full");

            lvw.addColumnHeader("ID", 25);
            lvw.addColumnHeader("Title", 80);
            lvw.addColumnHeader("Class Name");

            // Append processes
            for(let p of w96.state.processes) {
                if(!p)
                    continue;

                lvw.pushData([p.appId || "??", p.title || "unnamed", p.constructor.name || "(unknown)"]);
            }

            e.querySelector(".table").replaceWith(lvw.getElement());

            lvw.select(0); // Select first process

            // Add some button events
            e.querySelector('button').addEventListener('click', ()=>{
                const selectedItem = lvw.getSelectedItem();

                if(!selectedItem)
                    return; // No selected item

                DialogCreator.confirm(`WARNING: Terminating a process can cause undesired results including loss of data and system instability. 
The process will not be given the chance to save its state or data before it is terminated. Are you sure you want to terminate the process?`,
                {
                    title: "Task Manager Warning",
                    icon: "warning",
                    maxWidth: 342
                },
                (v) => {
                    /* .. kill process .. */
                    if(v) {
                        // Get process
                        const selectedPid = lvw.getSelectedColumnData(0);
                        
                        // If there is no pid, this is either a critical system process or glitch
                        // Either way, do not touch it.
                        if(!selectedPid) {
                            DialogCreator.alert("This process cannot be killed.", {
                                title: "Task Manager Error",
                                icon: "error"
                            });

                            return;
                        }

                        // Kill process
                        procMgr.quit(parseInt(selectedPid), true);
                        selectedItem.remove();
                    }
                });
            });
        });

        // // Performance tab
        // tabControl.addPage("Performance", (e) => {
        //     this._state.selectedTask = null;
        //     e.classList.add("tab-performance");
        //     e.style.padding = "15px";
        //     e.innerHTML = `<div class="grpbx1"></div>`;

        //     const cpuHistoryGrpBox = new GroupBox({
        //         title: "CPU Usage History",
        //         body: " "
        //     });

        //     const gsbox = new GraphStatBox({
        //         ondata: ()=>Math.floor(Math.random() * 100),
        //         size: {
        //             box_width: 12,
        //             box_height: 12,
        //             width: 344,
        //             height: 60
        //         }
        //     });

        //     gsbox.init();

        //     cpuHistoryGrpBox.getElement().querySelector(".content").appendChild(gsbox.getElement());

        //     e.querySelector(".grpbx1").replaceWith(cpuHistoryGrpBox.getElement());
        // });

        body.querySelector(".tabc").replaceWith(tabControl.getElement());

        mainwnd.show();

        this.mainwnd = mainwnd;

        // Start updating timer.
        this.updateProc();
        this.updateFunc = setInterval(()=>this.updateProc(), this.updateInterval);
    }

    /**
     * Shows the new task dialog.
     */
    showNewTaskDlg() {
        // TODO add customized dialog
        execCmd("run", []);
    }

    /**
     * Switches to the window.
     * @param {StandardWindow} wnd The window to switch to.
     */
    performSwitchTo(wnd) {
        if(!wnd)
            return;

        if(wnd.minimized)
            wnd.toggleMinimize();

        wnd.activate();
    }

    /**
     * Update the task manager views.
     */
    updateProc() {
        const body = this.mainwnd.getBodyContainer();

        const memCell = body.querySelector(".w96-footer .cell.mem");
        memCell.textContent = `Memory Usage: ${Number(((window.performance.memory || { usedJSHeapSize: 0 }).usedJSHeapSize / 1024 / 1024).toFixed(1))} MB`;
        
        const procCell = body.querySelector(".w96-footer .cell.proc");
        procCell.textContent = `Processes: ${w96.state.procMgr.getRunningProcesses().length}`;
    }

    /**
     * On app close.
     */
    async ontermination() {
        await super.ontermination();

        console.log("Closing down...");

        if(this.updateFunc !== null) {
            clearInterval(this.updateFunc);
            this.updateInterval = null;
            this.updateFunc = null;
        }

        this._state = null;
        this.mainwnd = null;
    }
}