/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

$$Include("./style.js")


class LiveCSSApplication extends WApplication {
    constructor() {
        super();
        this.schedInt = -1;
    }

    /**
     * The main entry point.
     * @param {String[]} argv Program arguments.
     */
    async main(argv) {
        super.main(argv);

        // Append CSS code
        this.styleEl = document.createElement('style');
        this.styleEl.textContent = CSS_CODE;
        document.body.appendChild(this.styleEl);

        // CSS style code
        const liveStyleEl = document.createElement('style');
        liveStyleEl.textContent = "";
        this.liveStyleEl = liveStyleEl;
        document.head.appendChild(liveStyleEl);
        
        await this._createWindow();
    }

    /**
     * Creates the main window.
     */
    async _createWindow() {
        const windowObj = document.createElement('div');
        windowObj.classList.add('livecss-window');
        
        // Create titlebar
        const titlebar = document.createElement('div');
        titlebar.classList.add('lc-tbar');
        windowObj.appendChild(titlebar);

        // Add title
        const wndTitle = document.createElement('div');
        wndTitle.textContent = "LiveCSS";
        wndTitle.classList.add('title');
        titlebar.appendChild(wndTitle);

        // Create content container
        const contentCnt = document.createElement('div');
        contentCnt.classList.add('lc-content');
        windowObj.appendChild(contentCnt);

        document.body.appendChild(windowObj);

        $(windowObj).draggable({
            cancel: '.lc-content'
        });

        $(windowObj).resizable({
            handles: 'n, s, w, e, ne, se, sw, nw',
        });

        // // Create menu bar
        // const menuBar = document.createElement('div');
        // menuBar.classList.add('lc-mbar');
        // contentCnt.appendChild('lc-mbar');

        // function createMbarItem(text, action) {
        //     const item = document.createElement('div');
        //     item.textContent = text;
        //     item.addEventListener('click', action);
        // }

        // createMbarItem("Load", ()=>{});

        // Create CSS text field
        const textArea = document.createElement('textarea');
        textArea.classList.add('style-input');
        contentCnt.appendChild(textArea);

        textArea.addEventListener('keydown', function(e) {
            if (e.key == 'Tab') {
                e.preventDefault();
                var start = this.selectionStart;
                var end = this.selectionEnd;

                // set textarea value to: text before caret + tab + text after caret
                this.value = this.value.substring(0, start) +
                "    " + this.value.substring(end);

                // put caret at right position again
                this.selectionStart =
                    this.selectionEnd = start + 4;
            }
        });

        // Set events
        textArea.addEventListener('input', () => {
            // Change CSS
            this.scheduleCSSChange(textArea.value);
        });
    }

    /**
     * Schedules a CSS change (updates the styles)
     */
    scheduleCSSChange(css) {
        if(this.schedInt !== -1)
            return; // Wait for operation to complete

        this.schedInt = setTimeout(()=>{
            this.liveStyleEl.textContent = css;
            this.schedInt = -1;
        }, 100);
    }

    /**
     * On app termination.
     */
    ontermination() {
        super.ontermination();
        
        // Remove style element
        this.styleEl.remove();
        this.styleEl = null;

        // Remove live style element
        this.liveStyleEl.remove();
        this.liveStyleEl = null;
    }
}