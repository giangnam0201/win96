/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Appends the specified fields to the tab page.
 * @param {HTMLDivElement} pageElement Tab page element.
 * @param { { name: String, value: String }[] } fields The fields to add.
 */
function appendFields(pageElement, fields) {
    fields.forEach((p)=>{
        let field = document.createElement('div');
        field.classList.add('field');
        field.innerHTML = `<span class="name">${p.name}:</span><span class="value">${p.value}</span>`;
        pageElement.appendChild(field);
    });
}

/**
 * Shows the properties dialog.
 * @param {ExplorerApplication} app Application instance.
 * @param {String} path The specified path to show the properties dialog for.
 */
async function showPropertiesDialog(app, path) {
    if(!await FS.exists(path)) {
        MsgBoxSimple.error("Error", "Unable to display properties.", "OK");
        return;
    }

    const stat = await FS.stat(path);
    const fname = FSUtil.fname(path);
    const isDrive = fname.trim() == "";
    const isDir = await FS.filetype(path) == 1;
    
    // Preinit general properties fields so they do not have to be reloaded on tab change

    const properties = [
        { name: "Name", value: isDrive ? path.substring(0, 2) : fname },
        { name: "Type", value: isDrive ? "Volume" : (isDir ? "Directory" : "Regular File")},
        { name: "Path", value: path },
        { name: "Size", value: sizeFmt.getSizeStringFromLength(stat.length) + ((stat.length > 1024) ? ` (${stat.length} bytes)` : "") },
        { name: "FS Record", value: ((stat.recordId != null) && (stat.recordId != "_null_")) ? stat.recordId : "Not present" },
    ];

    // Create the properties window
    const propertiesWnd = app.createWindow({
        draggable: true,
        initialHeight: 463,
        initialWidth: 389,
        resizable: false,
        controlBoxStyle: "WS_CBX_CLOSE",
        title: "Properties for " + (isDrive ? path.substring(0, 2) : fname),
        bodyClass: "wexplorer-app-propdlg",
        body: `<div class="tabc"></div>
        <div class="buttons">
            <button class="w96-button apply" disabled>Apply</button>
            <button class="w96-button cancel">Cancel</button>
            <button class="w96-button ok">OK</button>
        </div>`
    }, false);

    // Setup the tab control
    const tabControl = new TabControl();

    // Add the general page
    tabControl.openPage(tabControl.addPage("General", async(e)=>{
        e.innerHTML = `
            <div class="p1">
                <div class="icon" style="background-image: url(${await Theme.getFileIconUrl(path)})"></div>
                <input type="text" class="w96-textbox namebox" value="${isDrive ? path.substring(0, 2): fname}" disabled>
            </div>
            <div class="w96-ui-inset-separator"></div>
            <div class="p2"></div>
        `;

        e.classList.add("tab-general");

        // Iterate through properties and add them to the view
        appendFields(e, properties);
    }));

    // Scenarios
    // These could be specialized tabs
    if(isDrive) addVolumeTab(tabControl, path);
    if(!isDir) await addProgramTab(tabControl, path);

    // Reference window body and setup proper body class
    const body = propertiesWnd.getBodyContainer();
    body.classList.add('propwnd-base'); // Make sure its a properties window as well

    // Assign button events
    body.querySelector(".tabc").replaceWith(tabControl.getElement());
    body.querySelector("button.cancel").addEventListener('click', ()=>propertiesWnd.close());
    body.querySelector("button.ok").addEventListener('click', ()=>propertiesWnd.close()); // Do nothing for now since there are no property pages.

    // Finally, show the user
    propertiesWnd.show();
}