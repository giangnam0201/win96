/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

dzdcPages.push({
    name: "ctest",
    content: `
        <div class="container">
            <div>
                Testing the connection of the specified DevConnector service.<br><br>
                This may take a few moments...<br><br>
            </div>
            <div class="w96-progressbar">
                <div class="progress"></div>
            </div>
        </div>
    `,
    onrender: (app, contentEl)=>{
        // Do the connection test
        let socket;

        try {
            socket = io(installState.dcAddress);

            socket.on('ct_pong', () => {
                socket.close();
                socket = null;

                // Send to connection success page
                app.renderPage("congood");
            });

            socket.emit('ct_ping');

            // Handle connection error
            socket.on('connect_error', (err) => {
                console.error(err);
                socket.close();
                socket = null;
                app.renderPage("confail");
            });
        } catch(e) {
            // Go to connection failed
            console.error(e);
            socket.close();
            socket = null;
            app.renderPage("confail");
        }
    },
    buttons: [
        {
            cls: "next",
            enabled: false,
            onclick: (app)=> {}
        },
        {
            cls: "back",
            enabled: false,
            onclick: (app)=> app.renderPage("address")
        },
        {
            cls: "cancel",
            enabled: true
        }
    ]
});