/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, OpenFileDialog, DialogCreator } = w96.ui;
const { execCmd, execFile } = w96.sys;
const { argParser: ArgParser } = w96.util;

class RunApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        // Create run window
        const runWnd = this.createWindow({
            title: "Run",
            initialHeight: 157,
            initialWidth: 341,
            resizable: false,
            bodyClass: "dlg-run-box",
            controlBoxStyle: "WS_CBX_CLOSE"
        }, true);

        const body = runWnd.getBodyContainer();
        body.innerHTML = `
        <div class="exp">
            <div class="icon" style="background: url(${await Theme.getIconUrl("misc/run")})"></div>
            <div class="text">
                Type the name of a program, folder, document, or command, and Windows 96 will open it for you.
            </div>
        </div>
        <div class="pbox">
            <div class="text">Open: </div>
            <input type="text" class="w96-textbox cmd">
        </div>
        <div class="buttons">
            <button class="w96-button ok">OK</button>
            <button class="w96-button cancel">Cancel</button>
            <button class="w96-button browse">Browse...</button>
        </div>
        `;

        const cmdBox = body.querySelector('input');
        let busy = false;

        const on_click = async ()=>{
            if(cmdBox.value.trim() == "")
                return;

            // Proc cmd
            const fullCmd = cmdBox.value;

            /**
             * https://discord.com/channels/619868741395546117/819002030282637342/851972819947880478
             */
            const deviceNames = ['aux', 'con', 'nul', 'com1', 'com2', 'com3'];
            let devPath = fullCmd.trim().toLowerCase().split('/').slice(1);
            if(deviceNames.includes(devPath[0]) && deviceNames.includes(devPath[1])) {
                renderBSOD(
                    'A fatal exception 0E has occured at 0028:C004D91F in VXD VFAT(01) + 0000B897.' +
                    'The current application will be terminated.'
                );

                return;
            }

            if(await FS.exists(fullCmd)) {
                runWnd.close();
                execFile(fullCmd);
                return;
            } else {
                // Break down into cmd
                const args = ArgParser.parse(fullCmd);
                try {
                    const cmd = args[0].toString();
                    args.splice(0, 1);
                    execCmd(cmd, args).catch((e)=>{
                        DialogCreator.alert(new String(e), {
                            icon: "error",
                            title: "Error",
                            events: {
                                onclose: () =>  {
                                    runWnd.toggleMinimize(true);
                                    // I love hidden async
                                    setTimeout(() => {
                                        runWnd.activate();
                                        cmdBox.focus();
                                    }, 10);
                                }
                            }
                        });
                    });
                    runWnd.toggleMinimize();
                } catch(e) {
                    console.error(e);
                }
            }
        };

        body.querySelector('button.ok').addEventListener('click', ()=>on_click());

        body.querySelector('.w96-textbox').addEventListener('keydown', (e)=>{
            if(e.key == "Enter")
                on_click();
        });

        body.querySelector('button.cancel').addEventListener('click', ()=>{
            runWnd.close();
        });

        body.querySelector('button.browse').addEventListener('click', ()=>{
            new OpenFileDialog("c:/user/desktop", [''], (v)=>{
                if(!v)
                    return;

                cmdBox.value = v;
            }).show();
        });

        runWnd.show();
        body.querySelector('.w96-textbox').focus();

        runWnd.wndObject.style.top = (innerHeight - 201) + "px";
        runWnd.wndObject.style.left = "4px";
    }
}