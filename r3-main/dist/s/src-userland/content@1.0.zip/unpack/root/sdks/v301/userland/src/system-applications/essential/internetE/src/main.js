/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams, sysConf: SCM } = w96;
const { SaveFileDialog, OpenFileDialog, DialogCreator, MenuBar, Theme } = w96.ui;
const { ToolBar, TabControl, GroupBox } = w96.ui.components;
const { INI } = w96.util;
const { execCmd, execFile } = w96.sys;

const CONFIG = {
    homepage: "about:start", // TODO implement about:start
    searchEngine: "about:blank?placeholder&q=%SEARCH_QUERY%"
};

// System url definitions
const systemUrls = [
    {
        url: "about:start",
        title: "Start Page",
        redir: "/system/data/iexploder/syspages/start",
        import_sys: true // Import system resources
    }
];

$$Include("./ui/inet-options.js")

// Some todos
// - check if cors restrictions are a problem
// - if not, allow full functionality

/**
 * Formats a URL.
 * @param {String} u The url to format.
 */
function formatUrl(u) {
    let nu = u;

    if(u.startsWith("about:"))
        return nu;
    else if(u.startsWith("/"))
        return nu;
    else if(!(nu.startsWith("https://") || nu.startsWith("http://")))
        nu = "https://" + nu;

    return nu;
}

/**
 * Version 2 of Internet Exploder (rewritten).
 */
class InternetEApplication extends WApplication {
    constructor() {
        super();

        /**
         * Open file dialog last directory.
         */
        this.ofdLastDir = "C:/user";

        /**
         * Last visited url.
         */
        this.lastUrl = "";

        /**
         * List of favorites.
         */
        this.favorites = [];

        /**
         * Browser history (working set).
         */
        this.history = [];

        /**
         * Persistent browser history (unaltered visiting chain).
         */
        this.persistentHistory = [];

        /**
         * Current history position.
         */
        this.historyPos = -1;

        /**
         * UI state
         */
        this.uiState = {
            nav: {
                btnFwd: null,
                btnBack: null
            }
        };
    }

    /**
     * Program entry point.
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        super.main(argv);
        await this.createUI(argv);
    }

    /**
     * Loads all favorites from disk.
     */
    async loadFavorites() {
        if(!await FS.exists("C:/user/links"))
            await FS.mkdir("C:/user/links"); // TODO load default links

        this.favorites = [];

        for(let f of await FS.readdir("C:/user/links")) {
            if((!await FS.isFile(f)) || (FSUtil.getExtension(f).toLowerCase() !== ".url"))
                continue;

            const fileName = await FSUtil.fname(f);
            
            try {
                this.favorites.push({
                    title: fileName.substring(0, fileName.length - 4),
                    url: INI.parse(await FS.readstr(f)).InternetShortcut.URL
                });
            } catch(e) {
                console.warn(`Unable to parse favorite ${f}`, e);
            }
        }
    }

    /**
     * Clears the browser history.
     */
    clearHistory() {
        this.history = [];
        this.persistentHistory = [];
        this.historyPos = -1;
        this.updateNavButtons();

        // TODO write history changes
    }

    /**
     * Sets up the menu bar for InternetE.
     */
    setupMenuBar() {
        /** @type {HTMLDivElement} */
        const body = this.mainwnd.getBodyContainer();
        const mbar = new MenuBar();

        // File menu bar item
        mbar.addRoot("File", [
            {
                type: "submenu",
                label: "New",
                items: [
                    { type: "normal", label: "Window", onclick: ()=>void execCmd("internete", []) }
                ]
            },
            { type: "normal", label: "Open", onclick: ()=>this.showOpenUI() },
            { type: "normal", label: "Save", onclick: ()=>this.showSaveUI(), disabled: true },
            { type: "separator" },
            { type: "normal", label: "Close", onclick: ()=>this.terminate() }
        ], false);

        // View menu bar item
        mbar.addRoot("View", [
            { type: "normal", label: "Refresh", onclick: ()=>this.navigate(this.lastUrl) },
            { type: "separator" },
            { type: "normal", label: "Internet Options", onclick: ()=>showInternetOptionsWnd(this) }
        ]);

        // Go menu
        mbar.addRoot("Go", [
            { type: "normal", label: "Back", onclick: ()=>this.goBack() },
            { type: "normal", label: "Forward", onclick: ()=>this.goForward() },
            //{ type: "normal", label: "Up One Level", onclick: ()=>void 0 }
            { type: "separator", label: "" },
            { type: "normal", label: "Home Page", onclick: ()=>this.navigate(this.config.homepage) }
        ]);

        // Favorites menu
        mbar.addRoot("Favorites", [
            { type: "normal", label: "Add to Favorites...", onclick: ()=>this.showAddFavoriteUI() },
            { type: "normal", label: "Organize Favorites...", onclick: ()=>void execFile("C:/user/links") },
        ]);

        // Help menu bar item
        mbar.addRoot("Help", [
            { type: "normal", label: "About", onclick: ()=>{
                DialogCreator.alert('<span class="bold-noaa">InternetE</span><br>Version 2.0<br>', {
                    title: "About InternetE",
                    icon: "info"
                });
            }}
        ]);

        body.querySelector('.appbar').replaceWith(mbar.getMenuDiv());
    }

    /**
     * Sets up the toolbar.
     */
    async setupToolBar() {
        /** @type {HTMLDivElement} */
        const body = this.mainwnd.getBodyContainer();
        const tbar = new ToolBar();

        const backBtn = tbar.addItem({
            name: "back",
            text: "Back",
            imageUrl: await Theme.getIconUrl('actions/back', '24x24'),
            onclick: () => {
                fwdBtn.el.removeAttribute('disabled');
                
                this.goBack();

                if(this.historyPos === 0)
                    backBtn.el.setAttribute('disabled', 'true');
            }
        });

        backBtn.el.setAttribute('disabled', 'true');
        this.uiState.nav.btnBack = backBtn;

        const fwdBtn = tbar.addItem({
            name: "forward",
            text: "Forward",
            imageUrl: await Theme.getIconUrl('actions/forward', '24x24'),
            onclick: () => {
                backBtn.el.removeAttribute('disabled');
                
                this.goForward();

                if(this.historyPos + 1 === this.history.length) {
                    fwdBtn.el.setAttribute('disabled', 'true');
                }
            }
        });

        fwdBtn.el.setAttribute('disabled', 'true');
        this.uiState.nav.btnFwd = fwdBtn;

        tbar.addItem({
            name: "stop",
            text: "Stop",
            imageUrl: await Theme.getIconUrl('actions/stop', '24x24'),
            onclick: () => this.navigate("about:blank")
        });

        tbar.addItem({
            name: "refresh",
            text: "Refresh",
            imageUrl: await Theme.getIconUrl('actions/refresh', '24x24'),
            onclick: () => this.navigate(this.lastUrl)
        });

        tbar.addItem({
            name: "home",
            text: "Home",
            imageUrl: await Theme.getIconUrl('actions/home', '24x24'),
            onclick: () => this.navigate(this.config.homepage)
        });

        tbar.addSeparator();

        tbar.addItem({
            name: "search",
            text: "Search",
            imageUrl: await Theme.getIconUrl('actions/search', '24x24'),
            onclick: () => this.showSearchUI()
        });

        tbar.addItem({
            name: "favorites",
            text: "Favorites",
            imageUrl: await Theme.getIconUrl('actions/favorites', '24x24'),
            onclick: () => this.showUtilityPane('favorites')
        });

        tbar.addItem({
            name: "history",
            text: "History",
            imageUrl: await Theme.getIconUrl('actions/history', '24x24'),
            onclick: () => this.showUtilityPane('history')
        });

        tbar.addSeparator();

        tbar.addItem({
            name: "fullscreen",
            text: "Fullscreen",
            imageUrl: await Theme.getIconUrl('actions/fullscreen', '24x24'),
            onclick: () => void this.appFrame.requestFullscreen()
        });

        body.querySelector('.toolbar').replaceWith(tbar.getElement());
    }

    /**
     * Creates the main UI for InternetE.
     * @param {String[]} argv Program arguments
     */
    async createUI(argv) {
        this.mainwnd = this.createWindow({
            bodyClass: "internete-app",
            body: `<div class="w96-ui-inset">
                <div class="appbar"></div>
                <div class="toolbar"></div>
                <div class="nav-box">
                    <div class="text">Address:</div>
                    <input class="w96-textbox" type="text">
                    <!-- <button class="w96-button go">Go</button> -->
                </div>
            </div>
            <div class="combo-panel">
                <div class="left"></div>
                <div class="right">
                    <iframe class="content"></iframe>
                </div>
            </div>
            <div class="w96-footer">
                <div class="cell status">
                    Done
                </div>
                <div class="cell zone">
                    Internet Zone
                </div>
            </div>`,
            initialHeight: 500,
            initialWidth: 640,
            title: "Untitled - InternetE",
            icon: await Theme.getIconUrl("apps/iexploder", '16x16'),
            taskbar: true
        }, true);

        // Load config
        this.config = { ... CONFIG, ... SCM.get("Software/InternetE") };

        if(SCM.get("Software/InternetE") == null)
            await this.commitCurrentConfiguration(); // Set default cfg

        // Setup some things
        this.setupMenuBar();
        this.setupToolBar();
        this.setupIframe();
        await this.loadFavorites();

        // Reference some UI components
        const body = this.mainwnd.getBodyContainer();

        // Setup util pane
        const utilPane = body.querySelector(".combo-panel>.left");
        utilPane.style.display = "none";
        
        /** @type {HTMLIFrameElement} */
        this.appFrame = body.querySelector("iframe");

        /** @type {HTMLInputElement} */
        this.navBox = body.querySelector(".nav-box>input");

        // NavBox enter key event
        this.navBox.addEventListener('keydown', (e) => {
            if(e.key == "Enter")
                this.navigate(this.navBox.value);
        })

        // Show window
        this.mainwnd.show();

        // Check arguments
        if(argv[1] != null)
            this.navigate(argv[1]);
        else
            this.navigate(this.config.homepage);
    }

    /**
     * Commits the current configuration.
     */
    async commitCurrentConfiguration() {
        await SCM.setAndSync("Software/InternetE", this.config); 
    }

    /**
     * Shows the "Add Favorite" UI.
     */
    showAddFavoriteUI() {
        return DialogCreator.prompt(`Please enter the new link name for ${this.lastUrl}`, {
            title: "Add Favorite"
        }, (v)=>{
            if((!v) || (v.trim() == ""))
                return;

            // Create the link
            FS.writestr(`C:/user/links/${v}.url`, INI.stringify({
                InternetShortcut: {
                    URL: formatUrl(this.lastUrl)
                }
            })).then(async()=>this.showUtilityPane('favorites'));
        });
    }

    /**
     * Sets up the iframe to be used for web browsing.
     */
    setupIframe() {
        /** @type {HTMLDivElement} */
        const body = this.mainwnd.getBodyContainer();
        const appFrame = body.querySelector("iframe");
        const statusCell = body.querySelector(".cell.status");

        appFrame.addEventListener('load', ()=> {
            // Set done status text
            statusCell.textContent = `Done`;
        });
    }

    /**
     * Shows a utility pane.
     * @param {"favorites"|"history"} type The type of pane to show.
     */
    async showUtilityPane(type) {
        await this.loadFavorites();

        /** @type {HTMLDivElement} */
        const bodyContainer = this.mainwnd.getBodyContainer();
        const utilPane = bodyContainer.querySelector(".combo-panel>.left");
        utilPane.style.display = "";

        // Create pane container
        const paneContainer = document.createElement('div');
        paneContainer.classList.add('pane-container', 'w96-ui-inset');

        // Clear util panel first
        while(utilPane.firstChild)
            utilPane.removeChild(utilPane.firstChild);

        // Create the mini "window" controls
        const paneBox = document.createElement('div');
        paneBox.classList.add('pane-bar');

        // Setup the pane box with title and close button
        const pbTitle = document.createElement('div');
        pbTitle.classList.add('title');
        paneBox.appendChild(pbTitle);

        // Close button
        const pbCloseBtn = document.createElement('div');
        pbCloseBtn.classList.add('close');
        pbCloseBtn.onclick = ()=> {
            while(utilPane.firstChild)
                utilPane.removeChild(utilPane.firstChild);

            utilPane.style.display = "none";
        }

        paneBox.appendChild(pbCloseBtn);

        // Finally append the pane box titlebar
        paneContainer.appendChild(paneBox);

        // Create content box
        const contentBox = document.createElement('div');
        contentBox.classList.add('content');

        // Show the right utility pane
        switch(type) {
            case "favorites":
                paneContainer.classList.add('favorites');
                pbTitle.textContent = "Favorites";
                
                // Add favorites
                for(let fav of this.favorites) {
                    const favEl = document.createElement('div');
                    favEl.classList.add('favorite');
                    
                    // Add icon element
                    const imageEl = document.createElement('div');
                    imageEl.classList.add('image');
                    Theme.getIconUrl("mime/html", '16x16').then((v)=>imageEl.style.backgroundImage = `url(${v})`);
                    favEl.appendChild(imageEl);

                    // Add separate text element
                    const textEl = document.createElement('div');
                    textEl.classList.add('text');
                    textEl.textContent = fav.title;
                    favEl.appendChild(textEl);
                    favEl.addEventListener('click', ()=> {
                        contentBox.querySelectorAll('.favorite.active').forEach((v)=>v.classList.remove('active'));
                        favEl.classList.add('active');
                        this.navigate(fav.url);
                    });

                    contentBox.appendChild(favEl);
                }
                break;
            case "history":
                // Use same method for history
                paneContainer.classList.add('favorites');
                pbTitle.textContent = "History";
                
                // Add favorites
                for(let x = this.persistentHistory.length - 1; x >= 0; x--) {
                    const hst = this.persistentHistory[x];
                    const favEl = document.createElement('div');
                    favEl.classList.add('favorite');
                    
                    // Add icon element
                    const imageEl = document.createElement('div');
                    imageEl.classList.add('image');
                    Theme.getIconUrl("mime/html", '16x16').then((v)=>imageEl.style.backgroundImage = `url(${v})`);
                    favEl.appendChild(imageEl);

                    // Add separate text element
                    const textEl = document.createElement('div');
                    textEl.classList.add('text');
                    textEl.textContent = hst;
                    favEl.appendChild(textEl);
                    favEl.addEventListener('click', ()=> {
                        contentBox.querySelectorAll('.favorite.active').forEach((v)=>v.classList.remove('active'));
                        favEl.classList.add('active');
                        this.navigate(hst);
                    });

                    contentBox.appendChild(favEl);
                }
                break;
        }

        paneContainer.appendChild(contentBox);
        utilPane.appendChild(paneContainer);
    }

    /**
     * Navigates to a page.
     * @param {String} url The URL to navigate to.
     */
    async navigate(url, options = {}) {
        const params = {
            ...{
                quiet: false,
                addHistory: true
            },
            ...options
        }

        this.lastUrl = url;

        // Play navigation sound
        if(!params.quiet)
            Theme.playSound("navigate");

        // Set loading status text
        this.mainwnd.getBodyContainer().querySelector(".cell.status").innerText = `Loading ${url}`;

        if(params.addHistory) {
            if (this.historyPos + 1 != this.history.length) {
                /*
                 * History has changed, remove next entries.
                 */
                this.history = this.history.slice(0, this.historyPos + 1);
            }

            if (this.history[this.history.length - 1] !== url) {
                this.history.push(url);
                this.historyPos++;
            }

            // Add to persistent history
            if(this.persistentHistory[this.persistentHistory.length - 1] !== url)
                this.persistentHistory.push(url);
        }

        // Check if the URL is a file
        if(await FS.exists(url)) {
            if(url.toLowerCase().endsWith(".url")) {
                const shortcutObj = INI.parse(await FS.readstr(url));

                if(shortcutObj["InternetShortcut"] && shortcutObj["InternetShortcut"].URL) {
                    return this.navigate(shortcutObj["InternetShortcut"].URL, { quiet: true });
                }
            }

            // Create SW url
            //c:/users
            const dp = FSUtil.deconstructFullPath(url);
            return this.navigate(`/_/${dp.prefix[0]}/${url.substring(3)}`, { quiet: true });
        }

        const systemUrlObj = systemUrls.find((x)=>x.url == url);
        this.appFrame.onload = ()=>{}; // Clear event

        if(systemUrlObj) {
            if(!systemUrlObj.title)
                this.mainwnd.setTitle(url + " - InternetE");
            else
                this.mainwnd.setTitle(systemUrlObj.title + " - InternetE");

            this.navBox.value = url;

            if(systemUrlObj.import_sys) {
                this.appFrame.onload = ()=>{
                    this.appFrame.contentWindow.w96 = w96;
                }
            }

            if(systemUrlObj.body)
                this.appFrame.src = `data:text/html;base64,` + btoa(systemUrlObj.body);
            else
                this.appFrame.src = systemUrlObj.redir;

            return;
        }

        const formattedUrl = formatUrl(url);
        this.mainwnd.setTitle(formattedUrl + " - InternetE");
        this.navBox.value = formattedUrl;
        this.appFrame.src = formattedUrl;
        this.updateNavButtons();
    }

    /**
     * Updats nav buttons UI state.
     */
    updateNavButtons() {
        if(this.historyPos + 1 != this.history.length && this.uiState.nav.btnFwd) {
            this.uiState.nav.btnFwd.el.setAttribute('disabled', 'true');
        }

        if(this.history.length !== 0 && this.uiState.nav.btnBack) {
            this.uiState.nav.btnBack.el.removeAttribute('disabled');
        }
    }

    /**
     * Go backwards in history.
     */
    goBack(navigate = true) {
        if (this.history.length > 0 && this.historyPos - 1 >= 0) {
            let p = this.history[--this.historyPos];
            if (navigate) this.navigate(p);
            return p;
        }
    }

    /**
     * Go forwards in history.
     */
    goForward(navigate = true) {
        if (this.history.length > 0 && this.historyPos + 1 < this.history.length) {
            let p = this.history[++this.historyPos];
            if (navigate) this.navigate(p);
            return p;
        }
    }

    /**
     * Shows the save file UI.
     */
    showSaveUI() {
        if(!this.crossIfrCheck()) {
            DialogCreator.alert("Unable to save document due to CORS.", {
                icon: "error",
                title: "InternetE"
            });
        } else {
            // Show save file dialog

        }
    }

    /**
     * Shows the open file UI.
     */
    showOpenUI() {
        new OpenFileDialog(this.ofdLastDir, ["html", "htm", "url"], (fn)=>{
            if(!fn)
                return;

            this.navigate(fn);
            this.mainwnd.activate();
            this.ofdLastDir = FSUtil.getParentPath(fn);
        }).show();
    }

    /**
     * Shows the search engine UI.
     */
    showSearchUI() {
        return DialogCreator.prompt(`Please enter your search query.`, {
            title: "Search with search engine"
        }, (v)=>{
            if((!v) || (v.trim() == ""))
                return;

            this.navigate(this.config.searchEngine.replace("%SEARCH_QUERY%", v));
        });
    }

    /**
     * Checks if the iframe is not CORS blocked.
     */
    crossIfrCheck() {
        try {
            return Boolean(this.appFrame.contentDocument);
        }
        catch(e){
            return false;
        }
    }

    /**
     * Called on app close.
     */
    ontermination() {
        this.mainwnd = null;
        this.appFrame = null;
        this.navBox = null;
        this.uiState = null;
        super.ontermination();
    }
}