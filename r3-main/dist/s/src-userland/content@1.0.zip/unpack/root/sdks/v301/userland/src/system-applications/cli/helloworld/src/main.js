/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

// Easy ref
const term = this.boxedEnv.term;

if(!term)
    return;

/**
 * The template for a terminal application.
 */
class HelloWorldApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        term.writeln('Hello World!');
        term.writeln('Welcome to the most useful app!');

        let firstName = await term.prompt("Enter your first name: ");
        term.writeln('Nice job ' + firstName + '!');

        let lastName = await term.prompt('Last name: ');
        term.writeln(`Hi there ${firstName} ${lastName}!`);
        await term.pause();
    }
}