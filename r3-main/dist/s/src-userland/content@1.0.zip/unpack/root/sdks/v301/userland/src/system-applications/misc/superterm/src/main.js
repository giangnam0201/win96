/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { utils: UIUtils, DialogCreator, MenuBar, Theme } = w96.ui;
const { mkShortcut } = w96.shell;

const RTOP_PORT = 121;

class SuperTermApplication extends WApplication {
	constructor() {
		super();
	}

	async main(argv) {
		super.main(argv);

		this.p3 = w96.net.p3;
		this.connection = {
			address: null,
			name: null,
			socket: null
		}

		const require_connected = _ => !!this.connection.socket;
		const wnd = this.createWindow({
            initialWidth: 520,
            initialHeight: 350,
            title: 'SuperTerm',
            taskbar: true,
            bodyClass: 'superterm',
            icon: await Theme.getIconUrl('apps/superterm', '16x16'),
            controlBoxStyle: 'WS_CBX_MINMAXCLOSE'
        }, true);

		const appbar = new MenuBar();
		appbar.addRoot('File', [
			{
				type: 'normal',
				label: 'Create shortcut',
				onopened: require_connected,
				onclick: () => {
					mkShortcut(
						`c:/user/desktop/${this.connection.name}.link`,
						'apps/superterm',
						`superterm --connection ${this.connection.name}\n${this.connection.address}\n${this.el.term.style.color}\n${this.el.term.style.backgroundColor}`
					);

					DialogCreator.alert('Shortcut created on your desktop.', {
						title: 'Create shortcut',
						icon: 'info'
					});
				}
			},

			{ type: 'separator' },

			{
				type: 'normal',
				label: 'Exit',
				onclick: () => {
					this.ontermination();
				}
			}
		]);

		appbar.addRoot('Connection', [
			{
				type: 'normal',
				label: 'New connection...',
				onclick: () => {
					this._newConnectionDialog();
				}
			},

			{ type: 'separator' },

			{
				type: 'normal',
				label: 'Connect',
				onopened: el => {
					el.textContent = this.connection.socket && this.connection.socket.connected ? 'Disconnect': 'Connect';

					return require_connected();
				},
				onclick: () => {
					if(this.connection.socket.connected)
						this.disconnect(true);
					else
						this.reconnect();
				}
			},

			{
				type: 'normal',
				label: 'End',
				onopened: require_connected,
				onclick: () => {
					this.disconnect();
				}
			}
		]);

		appbar.addRoot('View', [
			{
				type: 'normal',
				label: 'Clear history',
				onclick: () => {
					this.el.term.innerHTML = '';
				}
			},

			{ type: 'separator' },

			{
				type: 'submenu',
				label: 'Color scheme...',
				items: [
					{
						type: 'normal',
						label: 'Green on black',
						onclick: () => this.setTheme('#0f0', '#000')
					},

					{
						type: 'normal',
						label: 'Black on white',
						onclick: () => this.setTheme('#000', '#fff')
					},

					{
						type: 'normal',
						label: 'Light blue on gray',
						onclick: () => this.setTheme('#dff', '#222')
					}
				]
			},
		], false);

		appbar.addRoot('Help', [
			{
				type: 'normal',
				label: 'About',
				onclick: () => {
					DialogCreator.alert(`
						<span class="bold-noaa">SuperTerm</span><br>
						<span>Version 1.0</span>`, {
						title: 'About',
						icon: 'info'
					});
				}
			}
		]);

        const htmlContainer = wnd.getBodyContainer();
		htmlContainer.innerHTML = `
			<div class="appbar"></div>
			<div class="term w96-inset"></div>
			<input type="text" class="input w96-textbox" disabled>
		`;
		let barDiv = appbar.getMenuDiv();
		htmlContainer.querySelector('.appbar').replaceWith(barDiv);

		let activityLight = document.createElement('div');
		activityLight.classList.add('superterm-activity');
		activityLight.title = 'Input/Output';
		barDiv.appendChild(activityLight);

		this.wnd = wnd;
		this.el = {
			term: htmlContainer.querySelector('.term'),
			input: htmlContainer.querySelector('.input'),
			activity: activityLight
		}

		this.el.input.onkeydown = e => {
			if(e.key == 'Enter' && this.connection.socket.connected) {
				this.setActivityLight('input');
				this.connection.socket.send(['input', this.el.input.value.trim()]);

				if(!e.shiftKey)
					this.el.input.value = '';
			}
		}

		if(argv[1] === '--connection') {
			let conn = argv.slice(1).join(' ').split('\n');
			this.connect(conn[0], conn[1]);
			this.setTheme(conn[2], conn[3]);
		}

		this._updateTitle();
        wnd.show();
	}

	/**
	 * Change activity light
	 *
	 * @param {String} type The activity type to set.
	 */
	setActivityLight(type) {
		let color = '#000';

		if(type == 'input')
			color = '#0a0';

		if(type == 'output')
			color = '#a00';

		for(let i = 0; i < 2; i++) {
			setTimeout(() => {
				this.el.activity.style.background = color;
				setTimeout(() => {
					this.el.activity.style.background = '';
				}, 150);
			}, i * 200);
		}
	}

	/**
	 * Open the "New connection" dialog window.
	 */
	async _newConnectionDialog() {
		const wnd = this.createWindow({
            initialWidth: 260,
            initialHeight: 202,
            title: 'New Connection',
            taskbar: false,
            center: true,
            bodyClass: 'superterm',
            controlBoxStyle: 'WS_CBX_CLOSE',
            resizable: false
        }, false);

        const htmlContainer = wnd.getBodyContainer();
		htmlContainer.innerHTML = `
			<div class="mbox">
			<div class="content">
				<div class="icon" style="background-image:url(${await Theme.getIconUrl('apps/superterm', 'normal')}"></div>
				<div class="text">Enter an RToP address and a name for the connection:</div>
			</div>
			</div>

			<div class="inputs">
				<span>Name:</span>
				<input type="text" class="input-name w96-textbox" value="New connection">
				<span>RToP address:</span>
				<input type="text" class="input-url w96-textbox" placeholder="address.ppp">

				<div class="separator w96-inset"></div>
			</div>


			<div class="buttons">
				<button class="w96-button btn-confirm" disabled>OK</button>
				<button class="w96-button btn-cancel">Cancel</button>
			</div>
		`;

		let _validateInput = e => {
			if(inputName.value.trim() && inputUrl.value.trim()) {
				btnConfirm.removeAttribute('disabled');

				if(e.key === 'Enter')
					btnConfirm.click();
			} else
				btnConfirm.setAttribute('disabled', 'true');
		}

		let inputName = htmlContainer.querySelector('.input-name');
		let inputUrl = htmlContainer.querySelector('.input-url');
		inputName.onkeyup = _validateInput;
		inputUrl.onkeyup = _validateInput;

		let btnConfirm = htmlContainer.querySelector('.btn-confirm');
		btnConfirm.onclick = () => {
			let name = inputName.value.trim();
			let address = inputUrl.value.trim();

			if(this.connection.socket) {
				DialogCreator.alert('Are you sure you want to create a new connection? Your current session will be terminated.', {
					buttons: [
						{
							id: 'ok',
							text: 'OK',
							action: ({dlg}) => {
								dlg.close();
								wnd.close();
								this.connect(name, address);
							}
						},

						{
							id: 'cancel',
							text: 'Cancel',
							action: ({dlg}) => {
								dlg.close();
							}
						}
					],
					title: 'Confirm',
					icon: 'question'
		        });
			} else {
				wnd.close();
				this.connect(name, address);
			}
		}

		let btnCancel = htmlContainer.querySelector('.btn-cancel');
		btnCancel.onclick = () => {
			wnd.close();
		}

		wnd.show();
		inputUrl.focus();
	}

	/**
	 * Update the window title.
	 */
	_updateTitle() {
		const { socket } = this.connection;

		if(!this.appWindow)
			return;

		if(this.connection.name) {
			if(socket)
				this.wnd.setTitle(`${this.connection.name} (${socket.connected ? 'connected': 'disconnected'}) - SuperTerm`);
			else
				this.wnd.setTitle(`${this.connection.name} (dialing) - SuperTerm`);
		} else
			this.wnd.setTitle('SuperTerm');
	}

	_onmessage([type, msg]) {
		this.setActivityLight('output');

		if(type === 'text') {
			if(msg instanceof Array) {
				msg.forEach(block => {
					let text = document.createElement('span');

					if(typeof block == 'object') {
						text.style.color = block.color;
						text.style.backgroundColor = block.background;
						text.textContent = block.text ?? '';

						if(typeof block.onclick == 'string') {
							text.onclick = () => {
								if(this.connection.socket.connected) {
									this.setActivityLight('input');
									this.connection.socket.send(['click', block.onclick]);
								}
							}

							text.classList.add('clickable');
						}
					}

					if(typeof block == 'string') {
						text.textContent = block;
					}

					this.el.term.appendChild(text);
				});
			}

			if(typeof msg == 'string') {
				let text = document.createElement('span');
				text.textContent = msg;
				this.el.term.appendChild(text);
			}

			return this.el.term.scrollTop = this.el.term.scrollHeight;
		}

		if(type == 'resize') {
			const {clientWidth, clientHeight} = document.body;
			let [width, height] = msg;

			if(isNaN(width) || isNaN(height))
				return;

			if(width > clientWidth)
				width = clientWidth;

			if(height > clientHeight)
				height = clientHeight;

			return this.wnd.setSize(parseInt(width, 10), parseInt(height, 10));
		}

		if(type == 'clear')
			return this.el.term.innerHTML = '';

		if(type == 'focus')
			return this.el.input.focus();
	}

	/**
	 * Create a new connection and connect to
	 * the specified address.
	 *
	 * @param {String} name The connection name.
	 * @param {String} address The RToP address to connect to.
	 */
	async connect(name, address) {
		let socket;

		if(this.connection.socket)
			this.connection.socket.disconnect();

		let url = new URL(`http://${address}`);

		/**
		 * Set the default RToP port if
		 * not specified.
		 */
		if(!url.port) {
			url.port = RTOP_PORT;
			address = url.host;
		}

		this.connection = {
			name,
			address,
			socket: null
		}

		this.el.term.innerHTML = '';
		this._updateTitle();

		if(!this.p3.connected && !(await UIUtils.p3Connect())) {
			this.connection.name = null;
			this.connection.address = null;

			return;
		}

		socket = this.p3.createConnection(address);
		this.connection.socket = socket;
		socket.on('message', m => this._onmessage(m));
		socket.on('disconnect', () => {
			this._updateTitle();
			this.el.input.setAttribute('disabled', 'true');
		});

		try {
			await socket.connect();
			this.el.input.removeAttribute('disabled');
			this._updateTitle();
		} catch(err) {
			DialogCreator.alert(`Error while connecting to ${this.connection.address}:\n${err.toString()}`, {
				title: 'Error',
				icon: 'error'
			});

			this._updateTitle();
		}
	}

	/**
	 * Close the connection.
	 */
	disconnect(noDestroyConnection = false, updateTitle = true) {
		if(this.connection.socket && this.connection.socket.connected)
			this.connection.socket.disconnect();

		if(!noDestroyConnection) {
			this.connection.name = null;
			this.connection.address = null;
			this.connection.socket = null;
		}

		if(updateTitle)
			this._updateTitle();
	}


	/**
	 * Set the SuperTerm color scheme.
	 *
	 * @param {String} fg HTML color code for foreground
	 * @param {String} bg HTML color code for background
	 */
	setTheme(fg, bg) {
		this.el.term.style.color = fg;
		this.el.term.style.backgroundColor = bg;
	}


	/**
	 * Close the socket connection then reconnect.
	 */
	async reconnect() {
		if(this.connection.socket)
			return await this.connect(this.connection.name, this.connection.address);
	}

	/**
	 * Close the program.
	 */
	ontermination() {
		super.ontermination();
		this.disconnect(true, false);
	}
}