Friday night funkin game
https://github.com/ninjamuffin99/Funkin