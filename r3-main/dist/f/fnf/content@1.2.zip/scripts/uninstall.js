// Ran upon package uninstallation
