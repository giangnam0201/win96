/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { MsgBoxSimple, Theme } = w96.ui;
const { clampNum } = w96.util;

class Multiplayer96Application extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        
        if(window._mpactive)
            return;
        else
            window._mpactive = true;

        this._createWindow();
    }

    async _createWindow() {
        this.players = {};
        window._mpactive = true;
        var params = new WindowParams();
        params.title = "Windows 96 Multiplayer";
        params.initialWidth = 320;
        params.initialHeight = 270;
        params.resizable = true;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<div>
        Welcome to Windows 96 Multiplayer. Please enter your server details below (keep this default if you're hosting and running the server software locally).
        <br>
        <br>
        <a href="/dl/96mp-v1.0-bin.zip">Download server software</a>
        </div>
        <br>

        <span class="bold-noaa">Server IP/Host</span>
        <input class="w96-textbox ip" type="text" value="ws://127.0.0.1:2020" style="margin-bottom: 12px;">

        <span class="bold-noaa">Nickname (16 chars max)</span>
        <input class="w96-textbox nick" type="text" value="Anonymouse">

        <span class="status">Status: <span class="bold-noaa">Disconnected</span></span>
        <div class="bgrp">
            <button role="host-connect" class="w96-button">Connect as Host</button>
            <button role="usr-connect" class="w96-button">Connect as User</button>
            <button role="disconnect" class="w96-button" disabled>Disconnect</button>
        </div>`);

        const htmlContainer = mainwnd.wndObject.querySelector(".window-html-content");
        htmlContainer.classList.add("winmp-app");

        this.statusLabel = htmlContainer.querySelector(".status>.bold-noaa");
        const hostBox = htmlContainer.querySelector('input.ip');
        const nickBox = htmlContainer.querySelector('input.nick');
        
        const hostConnectBtn = htmlContainer.querySelector('button[role="host-connect"]');
        const userConnectBtn = htmlContainer.querySelector('button[role="usr-connect"]');
        const disconnectBtn = htmlContainer.querySelector('button[role="disconnect"]');

        this.hostConnectBtn = hostConnectBtn;
        this.userConnectBtn = userConnectBtn;
        this.disconnectBtn = disconnectBtn;
        this.nickBox = nickBox;
        this.hostBox = hostBox;
        
        hostConnectBtn.onclick = ()=>{
            let validNick = this._nickCheck(nickBox.value);
            if(!validNick)
                return;

            userConnectBtn.disabled = true;
            hostConnectBtn.disabled = true;
            disconnectBtn.disabled = true;
            nickBox.disabled = true;
            hostBox.disabled = true;

            this.status("Connecting as host...");

            try {
                this._createSocket(hostBox.value);
                this.connectAsHost();
            } catch(e) {
                this.status(e, "error");
            }
        }

        userConnectBtn.onclick = ()=>{
            let validNick = this._nickCheck(nickBox.value);
            if(!validNick)
                return;

            hostConnectBtn.disabled = true;
            userConnectBtn.disabled = true;
            disconnectBtn.disabled = true;
            nickBox.disabled = true;
            hostBox.disabled = true;
            
            this.status("Connecting...");

            try {
                this._createSocket(hostBox.value);
                this.connectAsUser();
            } catch(e) {
                this.status(e, "error");
            }
        }

        disconnectBtn.onclick = ()=>this.revertState();

        mainwnd.onclose = ()=>{
            this.revertState();

            if(this.io) {
                this.io.removeAllListeners();
                this.io.close();
                this.io = null;
            }

            window._mpactive = false;

            if(this.logArea) {
                this.logArea.remove();
                this.logArea = null;
            }
        }

        const logArea = document.createElement('div');
        logArea.classList.add('wmp-notif');
        document.body.appendChild(logArea);

        this.logArea = logArea;
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/winmp", '16x16'));

        // Start the app
        mainwnd.show();
        mainwnd.center();
    }

    status(message, type = "idle") {
        this.statusLabel.innerText = message;
        this.statusLabel.className = "bold-noaa " + type;
    }

    awaitPing() {
        return new Promise((resolve)=>{
            const tm = setTimeout(()=>resolve(false), 1500);

            this.io.once('_pong', ()=>{
                resolve(true);
                clearTimeout(tm);
            })

            this.io.emit('_ping');
        });
    }

    connectAsHost() {
        const serverOnline = this.awaitPing();

        if(serverOnline) {
            this.status("Authenticating...");
        } else {
            this.status("Cannot reach server", "error");
            this.revertState();
            return;
        }

        // Authenticate as host
        this.io.emit('logon', { nick: this.nickBox.value, isHost: true });
    }

    connectAsUser() {
        const serverOnline = this.awaitPing();

        if(serverOnline) {
            this.status("Authenticating...");
        } else {
            this.status("Cannot reach server", "error");
            this.revertState();
            return;
        }

        // Authenticate as user
        this.io.emit('logon', { nick: this.nickBox.value, isHost: false });
    }

    revertState() {
        this.hostConnectBtn.disabled = false;
        this.userConnectBtn.disabled = false;
        this.disconnectBtn.disabled = true;
        this.nickBox.disabled = false;
        this.hostBox.disabled = false;

        if(this.io) {
            this.io.removeAllListeners();
            this.io.close();
            this.io = null;
        }

        this.players = {};

        if(this._usrWindow) {
            this._usrWindow.close();
            this._usrWindow = null;
        }

        this.status("Disconnected", "");

        document.querySelectorAll('.wmp-cursor').forEach((e)=>e.remove());
    }

    _createUserWindow() {
        const params = new WindowParams();
        params.initialHeight = 350;
        params.initialWidth = 400;
        params.title = "96 Multiplayer Control Window";
        params.resizable = true;
        params.draggable = true;

        this._usrWindow = this.createWindow(params, false);
        this._usrWindow.registerWindow();
        this._usrWindow.onclose = ()=>this.revertState();
        this._usrWindow.setHtml(`<span class="bold-noaa">Server:</span> ${this.hostBox.value}<br><span class="bold-noaa">Nickname:</span> ${this.nickBox.value}<br><br><button class="w96-button" onclick="this.parentElement.requestPointerLock()">Recapture cursor</button>`);

        /** @type {HTMLDivElement} */
        const htmlContainer = this._usrWindow.wndObject.querySelector(".window-html-content");
        htmlContainer.classList.add("winmp-usr-window");

        htmlContainer.onclick = ()=>{
            if(!document.pointerLockElement)
                htmlContainer.requestPointerLock();

            this.io.emit('mouse click');
        }

        htmlContainer.ondblclick = (e)=>{
            this.io.emit('mouse dblclick');
        }

        htmlContainer.onmousedown = (e)=>{
            this.io.emit('mouse down', e.button);
        }

        htmlContainer.onclick = (e)=>{
            this.io.emit('mouse click', e.button);
        }

        htmlContainer.onmouseup = (e)=>{
            this.io.emit('mouse up', e.button);
        }

        htmlContainer.onmousemove = (e)=>{
            this.io.emit('mouse move', e.movementX, e.movementY, e.button);
            //console.log(e.movementX + ", " + e.movementY);
        }

        this._usrWindow.onshown = ()=>{
            htmlContainer.requestPointerLock();
        }

        this._usrWindow.center();
        this._usrWindow.show();
    }

    _createSocket(host) {
        if(this.io) {
            this.io.removeAllListeners();
            this.io.close();
            this.io = null;
        }

        this.io = io(host);

        this.io.on('no host', ()=>{
            MsgBoxSimple.warning("No Host", "Please wait for a desktop host to connect first.", "OK");
            this.status("no host desktop to use as arena.", "error");
            this.revertState();
        });

        this.io.on('host defined', ()=>{
            MsgBoxSimple.warning("Already hosted", "Somebody is already hosting their desktop.", "OK");
            this.status("host is already present.", "error");
            this.revertState();
        });

        this.io.on('welcome user', (data)=>{
            this.disconnectBtn.disabled = false;

            this.io.on('disconnect', ()=>{
                this.status("server closed", "error");
                this.revertState();
            });

            // Open user control window with status, x, y, etc.
            this.status("Active on " + data.host.nick + "'s desktop.", "success");

            // Create user window
            this._createUserWindow();
        });

        this.io.on('welcome host', ()=>{
            this.disconnectBtn.disabled = false;

            this.io.on('disconnect', ()=>{
                this.status("server closed", "error");
                this.revertState();
            });

            this.io.on('player join', (p)=>{
                let logEntry = document.createElement('div');
                logEntry.classList.add('join-msg');
                logEntry.innerText = p.nick + " joined the desktop.";
                this.logArea.appendChild(logEntry);

                setTimeout(()=>logEntry.remove(), 3000);

                // Create player cursor
                const cursorEl = document.createElement('div');
                cursorEl.classList.add('wmp-cursor');

                const cursorImage = document.createElement('div');
                cursorImage.classList.add('image');
                cursorEl.appendChild(cursorImage);

                const cursorTag = document.createElement('div');
                cursorTag.classList.add('nick');
                cursorTag.innerText = p.nick;
                cursorTag.style.backgroundColor = "#" + Math.floor(Math.random()*16777215).toString(16);
                cursorEl.appendChild(cursorTag);

                document.body.appendChild(cursorEl);

                this.players[p.id] = {
                    id: p.id,
                    nick: p.nick,
                    cursor: cursorEl
                };
            });

            this.io.on('player leave', (p)=>{
                let logEntry = document.createElement('div');
                logEntry.classList.add('leave-msg');
                logEntry.innerText = p.nick + " left the desktop.";
                this.logArea.appendChild(logEntry);

                setTimeout(()=>logEntry.remove(), 3000);

                // Delete player cursor
                this.players[p.id].cursor.remove();
                this.players[p.id] = null;
            });

            // Add mouse events

            let lastElementOver = document.body;

            this.io.on('mouse move', (mX, mY, button, playerId)=>{
                const nx = clampNum(0, window.innerWidth, this.players[playerId].cursor.offsetLeft + mX);
                const ny = clampNum(0, window.innerHeight, this.players[playerId].cursor.offsetTop + mY);
                
                this.players[playerId].cursor.style.left = nx + "px";
                this.players[playerId].cursor.style.top = ny + "px";

                const elementOver = document.elementFromPoint(nx, ny);

                if(lastElementOver != elementOver) {
                    let event = new MouseEvent('mouseleave', {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        button: button,
                        x: nx,
                        y: ny,
                        clientX: nx,
                        clientY: ny
                    });

                    if(lastElementOver)
                        lastElementOver.dispatchEvent(event);

                    lastElementOver = elementOver;

                    let me_event = new MouseEvent('mouseenter', {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        x: nx,
                        y: ny,
                        clientX: nx,
                        clientY: ny
                    });

                    if(elementOver)
                        elementOver.dispatchEvent(me_event);
                }
            });

            this.io.on('mouse dblclick', (playerId)=>{
                const mouseX = this.players[playerId].cursor.offsetLeft;
                const mouseY = this.players[playerId].cursor.offsetTop;

                var event = new MouseEvent('dblclick', {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    x: mouseX,
                    y: mouseY,
                    clientX: mouseX,
                    clientY: mouseY
                });

                const el = document.elementFromPoint(mouseX, mouseY);
                
                if(el)
                    el.dispatchEvent(event);
            });

            this.io.on('mouse down', (playerId, button)=>{
                const mouseX = this.players[playerId].cursor.offsetLeft;
                const mouseY = this.players[playerId].cursor.offsetTop;

                const el = document.elementFromPoint(mouseX, mouseY);

                var event = new MouseEvent('mousedown', {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    button: button,
                    x: mouseX,
                    y: mouseY,
                    clientX: mouseX,
                    clientY: mouseY
                });
                
                if(el)
                    el.dispatchEvent(event);
                    
                if(document.activeElement != el)
                    el.focus();
            });

            this.io.on('mouse up', (playerId, button)=>{
                const mouseX = this.players[playerId].cursor.offsetLeft;
                const mouseY = this.players[playerId].cursor.offsetTop;

                const el = document.elementFromPoint(mouseX, mouseY);
                
                var event = new MouseEvent('mouseup', {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    button: button,
                    x: mouseX,
                    y: mouseY,
                    clientX: mouseX,
                    clientY: mouseY
                });

                if(el)
                    el.dispatchEvent(event);
            });

            this.io.on('mouse click', (playerId, button)=>{
                const mouseX = this.players[playerId].cursor.offsetLeft;
                const mouseY = this.players[playerId].cursor.offsetTop;

                const el = document.elementFromPoint(mouseX, mouseY);
                
                var event = new MouseEvent('click', {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    button: button,
                    x: mouseX,
                    y: mouseY,
                    clientX: mouseX,
                    clientY: mouseY
                });

                if(el)
                    el.dispatchEvent(event);
            });

            this.status("Server active - you are hosting", "success");
        });
    }

    _nickCheck(n) {
        if(n.length > 16) {
            MsgBoxSimple.warning("Nickname Error", "Your nickname must not be longer than 16 characters!", "OK");
            return false;
        } else if(n.length < 1) {
            MsgBoxSimple.warning("Nickname Error", "Please enter a nickname.", "OK");
            return false;
        } else if(n.trim() == "") {
            MsgBoxSimple.warning("Nickname Error", "Your nickname must not be empty!", "OK");
            return false;
        }

        return true;
    }
}