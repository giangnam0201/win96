/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { DialogCreator, Theme } = w96.ui;
const { rel: OSRelease, flags, kInfo } = w96.sys;
const { sideloadZip } = w96.util;

// Terminal reference
let term = this.boxedEnv.term;

/**
 * Gets the installation version.
 */
async function getInstallState() {
    try {
        return JSON.parse(await FS.readstr("C:/system/etc/inststate.json"));
    } catch(e) {
        // Write new inst state
        // Normally this would be written by oobe but if there is no state, it means it was likely installed without oobe
        const state = {
            rootfs: kInfo.rootfsUrl,
            version: await OSRelease.getVersionString(),
            installDate: new Date().toUTCString()
        };

        await FS.writestr("C:/system/etc/inststate.json", JSON.stringify(state, null, 4));

        return state;
    }
}

/**
 * Checks whether an update is required.
 */
async function isUpdateRequired() {
    try {
        return (await getInstallState()).version != (await OSRelease.getVersionString());
    } catch(e) {
        console.error(e);        
    }
    
    return false;
}

class SysUpdApp extends WApplication {
    constructor() {
        super();
    }

    /**
     * Entry point.
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        await super.main(argv);

        argv.shift();
        
        switch(argv[0]) {
            default:
                this.log("Invalid argument.");
                break;
            case "1stboot":
                // 1st boot checks
                await this.checkKernelImage();
                break;
            case "check":
                if(!flags.has("no_update_notifs"))
                    await this.performCheck();
                break;
        }

        // Close service
        this.terminate();
    }

    /**
     * Checks for the kernel image.
     */
    async checkKernelImage() {
        try {
            // Fetch kernel if its not stored yet
            if(!kutil.sysrom.exists("kernel.js")) {
                this.log("No stored kernel found, downloading...");

                // Push kernel to SysROM
                const data = await fetch(location.origin + '/system/libraries/kernel/sys-base/kernel.js', { cache: "no-store" }).then(s => s.text());
                kutil.sysrom.write("kernel.js", data);
                this.log("Download complete.");
            }

            // Put default kernel loader config in sysrom if it does not exist
            if(!kutil.sysrom.exists("KLoader.txt")) {
                this.log("Updating KLoader boot configuration... please wait.");

                kutil.sysrom.write("KLoader.txt", JSON.stringify({
                    config: {
                        defaultItem: "Win96"
                    },
                    items: [
                        {
                            id: "Win96",
                            file: "kernel.js"
                        }
                    ]
                }));

                this.log("Update complete.");
            }
        } catch(e) {
            console.error(e);
            this.log(new String(e));
        }
    }

    /**
     * Performs a system update check.
     */
    async performCheck() {
        // New system update available
        if(await isUpdateRequired()) {
            const wnd = this.createWindow({
                title: "System Update Notification",
                bodyClass: "sysupd-notif-wnd",
                body: `
                    <div class="top">
                        <div class="winlogo"></div>
                        <div class="text">
                            A new OS version is available for your system. It is strongly recommended that you install this update now to stay up-to-date.<br><br>
                            If you choose to postpone this for any reason, your system may become unstable over time.<br><br>
                            Any update postponement will last until the next reboot.<br><br>
                            Version Upgrade: <span class="bold-noaa">${(await getInstallState()).version} -&gt; ${OSRelease.getVersionString()}</span>
                        </div>
                    </div>
                    <div class="bottom">
                        <button class="w96-button cancel">Notify Me Later</button>
                        <button class="w96-button accept">Update &amp; Restart</button>
                    </div>
                `,
                controlBoxStyle: "WS_CBX_CLOSE",
                taskbar: false,
                resizable: false,
                icon: null,
                initialHeight: 230,
                initialWidth: 432
            }, false);

            const body = wnd.getBodyContainer();

            body.querySelector(".cancel").addEventListener('click', ()=>wnd.close());
            body.querySelector(".accept").addEventListener('click', async()=>{
                wnd.close();

                // Show status dialog
                const dlg = DialogCreator.progress("Processing system update, please wait...", {
                    title: "System Updater",
                    icon: await Theme.getIconUrl("apps/updater")
                });

                dlg.wnd.setControlBoxStyle("WS_CBX_NONE");
                
                // Get the install state
                const installState = await getInstallState();

                // Make sure there is a rootfs specification in the install state json
                if(!installState.rootfs) {
                    const alertBox = DialogCreator.alert("This system cannot be updated with this method.", {
                        icon: "error",
                        title: "System Update Error"
                    });

                    await alertBox.wait();
                    dlg.close();
                    return;
                }
                
                localStorage.setItem("ot-update-url", installState.rootfs || "/system/images/rootfs/rootfs.zip");
                await FS.rm("C:/system/wupd/sys_dl.lock");

                // Update install state
                await FS.writestr("C:/system/etc/inststate.json", JSON.stringify({
                    ... installState,
                    ... {
                        version: OSRelease.getVersionString()
                    }
                }, null, 4));

                w96.sys.reboot();
            });

            wnd.show();
            wnd.center();
            await wnd.wait();
        }
    }

    /**
     * Log some text (for debug purposes).
     * @param {String} text The text to log.
     */
    log(text) {
        if(term)
            term.println(text);
    }
}