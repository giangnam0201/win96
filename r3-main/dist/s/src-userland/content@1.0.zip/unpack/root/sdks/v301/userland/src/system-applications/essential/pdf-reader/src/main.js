/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MenuBar, Theme, OpenFileDialog } = w96.ui;

class PDFReaderApplication extends WApplication {
    constructor() {
        super();

        this.currentBlob = null;
        this.lastDir = "c:/user/documents";

        const mainwnd = this.createWindow({
            title: "PDF Reader",
            initialWidth: 780,
            initialHeight: 665,
            resizable: true,
            taskbar: true,
            body: `
                <div class="appbar"></div>
                <iframe src="/system/apps/pdf"></iframe>
                <footer class="w96-footer" style="margin-top: 2px">
                    <div class="cell">
                        &lt;unknown file&gt;
                    </div>
                </footer>
            `,
            bodyClass: "pdf-reader-app"
        }, true);

        Theme.getIconUrl("mime/pdf", '16x16').then((i)=>mainwnd.setWindowIcon(i));

        const body = mainwnd.getBodyContainer();
        const iframe = body.querySelector("iframe");

        const appMenu = new MenuBar();

        appMenu.addRoot("File", [
            {
                type: "normal",
                label: "Open",
                onclick: ()=>this.openFileUI()
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>mainwnd.close()
            }
        ]);

        appMenu.addRoot("View", [
            {
                type: "normal",
                label: "Presentation Mode",
                onclick: ()=>iframe.contentWindow.PDFViewerApplication.requestPresentationMode()
            }
        ]);

        appMenu.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>alert("<span class=\"bold-noaa\">PDF Reader</span><br>Version 1.0<br><br>Uses pdf.js, available from <a href=\"https://github.com/mozilla/pdf.js\" target=\"_blank\">https://github.com/mozilla/pdf.js</a>", { icon: "info" })
            }
        ]);

        body.querySelector(".appbar").replaceWith(appMenu.getMenuDiv());

        this.mainwnd = mainwnd;
    }

    /**
     * Shows the open file UI.
     */
    openFileUI() {
        new OpenFileDialog(this.lastDir, ["pdf", "PDF"], (v)=>{
            if((v != null) && (v.trim() !== ""))
                this.loadFile(v);
        }).show()
    }

    /**
     * Loads a file into the viewer.
     * @param {String} path The path of the file to load.
     */
    async loadFile(path) {
        if(!await FS.exists(path))
            return alert("Cannot load file.", { icon: "error" });

        if(this.currentBlob) {
            URL.revokeObjectURL(this.currentBlob);
            this.currentBlob = null;
        }

        const wndBody = this.mainwnd.getBodyContainer();
        const ifrWnd = wndBody.querySelector("iframe").contentWindow;

        try {
            this.currentBlob = URL.createObjectURL(await FS.toBlob(path));
            this.lastDir = FSUtil.getParentPath(path);

            // Show full path in footer
            wndBody.querySelector("footer .cell").textContent = path;

            this.mainwnd.setTitle(`${FSUtil.fname(path)} - PDF Reader`);
            
            ifrWnd.PDFViewerApplication.open(this.currentBlob);
        } catch(e) {
            console.error(e);
        }
    }

    async main(argv) {
        super.main(argv);

        this.mainwnd.show();

        const wndBody = this.mainwnd.getBodyContainer();
        const ifrWnd = wndBody.querySelector("iframe").contentWindow;

        ifrWnd.onload = async ()=>{
            if(argv[1] !== null) {
                if(!await FS.exists(argv[1]))
                    return alert("Error: File not found.", { icon: "error" });
                else
                    this.loadFile(argv[1]);
            }

            ifrWnd.document.querySelector("#openFile").addEventListener('click', ()=>this.openFileUI());
        }
    }
}