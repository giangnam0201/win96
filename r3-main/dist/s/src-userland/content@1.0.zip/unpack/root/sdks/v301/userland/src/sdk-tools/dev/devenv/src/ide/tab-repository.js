/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates the tab with the specified ID.
 * @param {string} id The ID of the tab to open.
 * @param {boolean} open Whether to open the tab.
 */
function createStandardTab(id, open = false) {
    let outId;

    switch(id) {
        case "start-page":
            outId = appInstance.ide.mainTabCtl.addPage({
                label: "Start Page",
                ondraw: (e)=>{
                    e.classList.add("wde-tab-start-page");
                    e.innerHTML = appInstance.getTextResource("UI/StartPage")
                }
            });
            break;
        case "web-browser":
            outId = appInstance.ide.mainTabCtl.addPage({
                label: "Web Browser",
                ondraw: (e)=>{
                    e.classList.add("wde-tab-web-browser");
                    e.innerHTML = appInstance.getTextResource("UI/Tab/WebBrowser")

                    /** @type {HTMLInputElement} */
                    const input = e.querySelector("input");
                    const iframe = e.querySelector("iframe");

                    input.addEventListener('keyup', async(tEvt) => {
                        if(tEvt.key == "Enter") {
                            // Process url
                            let url = input.value;

                            if(/^([a-zA-Z]:)/.test(url)) {
                                let letter = url[0];

                                url = `/_/${letter}/${url.substring(3)}`;
                            }
                            else if(url.startsWith("about:") || url.startsWith("/"))
                                noop();
                            else if(!(url.startsWith("http:") || url.startsWith("https:")))
                                url = "http://" + url;

                            input.value = url;
                            iframe.src = url;
                        }
                    });
                }
            });
            break;
    }

    if(open)
        appInstance.ide.mainTabCtl.activate(outId);
}