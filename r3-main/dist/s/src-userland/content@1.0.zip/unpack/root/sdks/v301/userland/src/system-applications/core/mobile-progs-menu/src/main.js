/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { execFile } = w96.sys;
const { Theme } = w96.ui;

class ImmersiveProgramsMenu extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        w96.wmem.mobStart = this;

        this.wnd = this.createWindow({
            resizable: false,
            draggable: false,
            initialHeight: 100,
            initialWidth: 100,
            initialX: 0,
            initialY: 0,
            title: "Programs",
            mobResize: true,
            animations: {
                windowClose: null,
                windowOpen: null
            }
        }, true);

        this.wnd.registerWindow();
        this.wnd.setControlBoxStyle("WS_CBX_CLOSE");

        const body = this.wnd.getBodyContainer();
        body.classList.add('app-mbprograms');
        body.innerHTML = `
            <div class="title">Programs</div>
            <div class="icons"></div>
            <div class="title">Utilities</div>
            <div class="icons-aux"></div>
        `;

        if(!await FS.exists("c:/system/etc/mobsupport/programs"))
            await FS.mkdir("c:/system/etc/mobsupport/programs");

        await this.populateView("c:/system/programs");
        await this.populateView("c:/system/etc/mobsupport/programs", false, ".icons-aux");

        this.wnd.show();
    }

    async populateView(path, clearItems = true, viewClass = ".icons") {
        const iconsView = this.wnd.getBodyContainer().querySelector(viewClass);

        while(iconsView.firstChild && clearItems)
            iconsView.removeChild(iconsView.firstChild);

        for(let item of await FS.walk(path)) {
            if((!await FS.isFile(item)) || (!item.endsWith(".link")))
                continue;

            const container = document.createElement('div');
            container.classList.add('item');

            // Create icon

            const button = document.createElement('button');
            button.classList.add('w96-button');
            button.style.backgroundImage = `url(${await Theme.getFileIconUrl(item)})`;
            button.addEventListener('click', ()=> execFile(item));
            container.appendChild(button);

            // Set text

            const text = document.createElement('div');
            text.classList.add('text');
            let fn = FSUtil.fname(item);
            text.innerText = fn.substring(0, fn.lastIndexOf('.'));
            container.appendChild(text);

            // Resolve icon
            try {
                const linkData = await FS.readstr(item);
                const link = JSON.parse(linkData);

                if(link.icon) {
                    let url = await Theme.getIconUrl(link.icon);

                    if(link.icon.startsWith("http:") || link.icon.startsWith("https:") || link.icon.startsWith("data:"))
                        url = link.icon;

                    button.style.backgroundImage = `url(${url})`;
                }

                iconsView.appendChild(container);
            } catch(e) {
                console.warn(e);
            }
        }
    }
}