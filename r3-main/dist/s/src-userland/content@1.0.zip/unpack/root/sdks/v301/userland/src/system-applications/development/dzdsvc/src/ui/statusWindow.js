/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

let statusBox = null;

/**
 * Shows the status window.
 * @param {DZDSvcApplication} app App instance.
 */
function showStatusBox(app) {
    if(statusBox)
        return;

    statusBox = document.createElement('div');
    statusBox.classList.add('dzdsvc-status-box');
    statusBox.innerHTML = `
        <div class="header"></div>
        <div class="box">
            <div class="bold-noaa">Connector Status</div>
            <div class="status">Unknown</div>
            
            <br>

            <div class="bold-noaa">Service Control</div>
            <div class="actions">
                <a class="conctl" href="#">Disconnect</a><br>
                <a class="launchwiz" href="#">Launch Wizard</a><br>
                <a class="quit" href="#">Quit</a>
            </div>

            <br>

            <div class="bold-noaa">Statistics</div>
            <div>
                Socket Ops: <span class="stat-sockops">0</span><br>
                File Transfers: <span class="stat-ftrans">0</span><br>
            </div>
        </div>
        <div class="footer">OS Ver: ${OSRelease.getVersionString()} | DC Server: ${SCM.get("Software/DevConnector/dcAddress")}</div>
    `;

    // Set some events
    statusBox.querySelector("a.quit").addEventListener('click', () => prgmFinishCallback());
    statusBox.querySelector("a.launchwiz").addEventListener('click', () => {
        closeStatusBox();
        execCmd("dzdcon", []);
    });

    statusBox.querySelector(".conctl").addEventListener('click', () => {
        if(socket)
            app.disconnectSocket();
        else
            app.beginSockListen().then(()=>updateStatus())

        updateStatus();
    });

    updateStatus();

    document.body.appendChild(statusBox);
}

/**
 * Closes the status box.
 */
function closeStatusBox() {
    if(!statusBox)
        return;

    statusBox.remove();
    statusBox = null;
}

/**
 * Updates the status box status.
 */
function updateStatus() {
    if(!statusBox)
        return;

    // Online/offline status label
    const statusLbl = statusBox.querySelector(".status");

    // Disconnect/Connect label
    const conctlLbl = statusBox.querySelector(".conctl");

    // Socket is undefined if connection is closed
    if(socket) {
        statusLbl.textContent = "Working";
        statusLbl.style.color = "green";

        // Set labels
        conctlLbl.textContent = "Disconnect";
    } else {
        statusLbl.textContent = "Offline";
        statusLbl.style.color = "red";
        conctlLbl.textContent = "Connect";
    }

    // Set counters
    statusBox.querySelector(".stat-ftrans").textContent = sockStats.fileOps;
    statusBox.querySelector(".stat-sockops").textContent = sockStats.sockOps;
}