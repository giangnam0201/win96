/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, OpenFileDialog, SaveFileDialog, Theme, MenuBar, DialogCreator } = w96.ui;
const { sysConf: SCM } = w96;

class TextpadApplication extends WApplication {
    constructor() {
        super();
        this.lastDir = "c:/";

        this.uiState = {
            wordWrapItem: null,
        };

        // Modifiers
        this.wordWrap = true;
    }

    async main(argv) {
        super.main(argv);

        if(argv[1] == null)
            this.currentFile = null;
        else
            this.currentFile = argv[1];

        const mainwnd = this.createWindow({
            title: ((argv[1] == null) ? "Untitled" : FSUtil.fname(argv[1])) + " - Textpad",
            initialHeight: 400,
            initialWidth: 600,
            taskbar: true,
            bodyClass: "textpad-app",
            icon: await Theme.getIconUrl("apps/textpad", '16x16')
        }, true);

        const wContainer = mainwnd.getBodyContainer();
        const appBar = new MenuBar();

        // File menu
        appBar.addRoot("File", [
            { type: "normal", label: "New", onclick: ()=>{ this.currentFile = null; this.loadDocument(null); } },
            { type: "separator" },
            { type: "normal", label: "Open", onclick: ()=>{
                new OpenFileDialog(this.lastDir, ["txt", "log", "json"], (fn)=>{
                    if(!fn)
                        return;
                    this.currentFile = fn;
                    this.loadDocument(fn);
                    this.appWindow.activate();
                    this.lastDir = FSUtil.getParentPath(fn);
                }).show();
            } },
            { type: "normal", label: "Save", onclick: ()=>{ 
                if(this.currentFile != null) {
                    // Save contents to existing file
                    FS.writestr(this.currentFile, this.textArea.value).catch((e)=>{
                        MsgBoxSimple.error("File Save Error", "Failed to write to [" + this.currentFile + "]!\nReason: " + e, "OK");
                    });
                } else {
                    this._saveAs();
                }
            } },
            { type: "normal", label: "Save As", onclick: ()=>{ this._saveAs(); } },
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{ this.terminate(); } }
        ]);

        // Edit menu
        appBar.addRoot("Edit", [
            this.uiState.wordWrapItem = {
                type: "normal",
                label: "Word Wrap",
                checked: this.wordWrap,
                onclick: ()=>this.setWordWrap(!this.wordWrap)
            }
        ]);

        // Help menu
        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About Textpad",
                onclick: ()=>DialogCreator.alert('<span class="bold-noaa">Textpad</span><br>Version 1.0 <br>', {
                    title: "About Textpad",
                    icon: "info"
                })
            }
        ]);

        const textArea = document.createElement('textarea');
        textArea.classList.add('main-editor');

        const footer = document.createElement('footer');
        footer.classList.add('w96-footer');
        
        const footerCell = document.createElement('div');
        footerCell.classList.add('cell');
        footer.appendChild(footerCell);

        wContainer.appendChild(appBar.getMenuDiv());
        wContainer.appendChild(textArea);
        wContainer.appendChild(footer);

        // Start the app
        mainwnd.show();
        mainwnd.center();

        this.mainwnd = mainwnd;
        this.textArea = textArea;
        this.footerCell = footerCell;
        this.loadDocument(this.currentFile);

        // Set some settings
        if(!SCM.get("Software/Textpad"))
            await SCM.setAndSync("Software/Textpad/WordWrap", this.wordWrap);

        this.setWordWrap(SCM.get("Software/Textpad/WordWrap"));
    }

    /**
     * Sets the word wrap.
     * @param {Boolean} value Whether to use word wrap.
     */
    setWordWrap(value) {
        if(value)
            this.textArea.classList.add('word-wrap');
        else
            this.textArea.classList.remove('word-wrap');

        this.uiState.wordWrapItem.checked = value;
        this.wordWrap = value;

        // Sync value in SCM
        SCM.setAndSync("Software/Textpad/WordWrap", value);
    }

    /**
     * On app termination.
     */
    ontermination() {
        super.ontermination();

        this.textArea = null;
        this.footerCell = null;
        this.mainwnd = null;
        this.uiState = null;
    }

    /**
     * Loads a document.
     * @param {String} fp The path of the file to load.
     * @returns 
     */
    loadDocument(fp) {
        if(fp == null) {
            // Clear textbox
            this.textArea.value = "";
            this._setWinTitle(null);
            this.footerCell.textContent = "Untitled";
            return;
        }

        FS.readstr(fp).then((text)=>{
            this.textArea.value = text;
            this.footerCell.textContent = fp;
            this._setWinTitle(fp);
        });
    }

    /**
     * Sets the window title.
     * @param {String} fp The path of the file to use for the window title.
     */
    _setWinTitle(fp) {
        this.mainwnd.setTitle(((fp == null) ? "Untitled" : FSUtil.fname(fp)) + " - Textpad");
    }

    /**
     * Show save as dialog.
     */
    _saveAs() {
        // Show save as dialog
        new SaveFileDialog(this.lastDir, ["txt", "log", "json"], (fn)=>{
            if(!fn)
                return;
            FS.writestr(fn, this.textArea.value).then(()=>{
                this.currentFile = fn;
                this._setWinTitle(fn);
                this.footerCell.textContent = fn;
                this.lastDir = FSUtil.getParentPath(fn);
            }).catch((e)=>{
                MsgBoxSimple.error("File Save Error", "Failed to write to [" + fn + "]!\nReason: " + e, "OK");
            });
        }).show();
    }
}