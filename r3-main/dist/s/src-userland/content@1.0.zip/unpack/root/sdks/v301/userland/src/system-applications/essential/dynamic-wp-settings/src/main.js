/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, MsgBoxSimple, OpenFileDialog } = w96.ui;
const { execFile } = w96.sys;
const { WindowParams } = w96;

class DynamicWPSettings extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(!(await FS.exists("c:/system/wallpapers/dynamic")))
            await FS.mkdir("c:/system/wallpapers/dynamic");

        const params = new WindowParams();
        params.initialHeight = 315;
        params.initialWidth = 292;
        params.title = "Dynamic Wallpaper Settings";
        params.resizable = false;

        this.wnd = this.createWindow(params, true);
        this.wnd.registerWindow();
        this.wnd.registerAppBar();
        this.wnd.setControlBoxStyle("WS_CBX_CLOSE");
        this.wnd.setWindowIcon(await Theme.getIconUrl("apps/dynwp", '16x16'));

        const body = this.wnd.getBodyContainer();
        
        body.classList.add('dynwp-app');
        body.innerHTML = `<span class="bold-noaa">
            Preview
        </span>
        
        <iframe class="preview" src="data:text/html;base64,PHN0eWxlPmJvZHkge2JhY2tncm91bmQ6YmxhY2s7fTwvc3R5bGU+"></iframe>
        <div class="field">
            <span class="bold-noaa">
                Built-in dynwallpapers
            </span>
            <select class="w96-textbox dwp-default-box">
                <!--<option value="C:/system/wallpapers/dynamic/classic.dwp">classic.dwp</option>-->
            </select>
        </div>
        <div class="field custom">
            <span class="bold-noaa">Custom dynwallpaper</span>
            <div>
                <input class="w96-textbox custom" type="text" readonly>
                <button class="w96-button browse">Browse</button>  
            </div>
        </div>
        <div class="buttons">
            <button class="w96-button left inspect">Inspect...</button>
            <button class="w96-button cancel">Cancel</button>
            <button class="w96-button apply">Apply</button>
        </div>`;

        /** @type {HTMLSelectElement} */
        const select = body.querySelector(".dwp-default-box");

        for(let wp of (await FS.readdir("c:/system/wallpapers/dynamic"))) {
            let fname = FSUtil.fname(wp);
            const opt = document.createElement('option');
            opt.value = wp;
            opt.innerText = fname;
            select.appendChild(opt);
        }

        select.addEventListener('change', (e)=>{
            const item = select.options[select.selectedIndex].value;
            this.loadWpPreview(item);
        });

        if(select.options[select.selectedIndex] != null) {
            const item = select.options[select.selectedIndex].value;
            this.loadWpPreview(item);
        }

        body.querySelector("button.inspect").addEventListener('click', ()=>{
            if(this.selectedWpPath)
                execFile(this.selectedWpPath);
        });

        body.querySelector("button.cancel").addEventListener('click', ()=>this.terminate());

        body.querySelector("button.browse").addEventListener('click', ()=>{
            new OpenFileDialog("c:/system/wallpapers/dynamic", [".dwp", ".DWP"], (v)=>{
                if(v) {
                    this.loadWpPreview(v);
                    body.querySelector('input.custom').value = v;
                }
            }).show();
        });

        body.querySelector("button.apply").addEventListener('click', async()=>{
            if(!this.selectedWpPath)
                return;

            // Writes should be manual so they can be in sync
            await w96.evt.shell.emit('config-modify', {
                background: { type: "iframe", bg: this.selectedWp.url }
            });
        });

        this.wnd.show();
        this.wnd.center();
    }

    async loadWpPreview(path) {
        try {
            const json = await FS.readstr(path);
            const obj = JSON.parse(json);
            this.selectedWp = obj;
            this.selectedWpPath = path;

            if(!obj.properties)
                obj.properties = {};

            this.wnd.getBodyContainer().querySelector('iframe').src = obj.url + "?opts=" + encodeURIComponent(btoa(JSON.stringify(obj.properties)));
        } catch(e) {
            MsgBoxSimple.error("Error", "Failed to load wallpaper.", "OK");
        }
    }
}