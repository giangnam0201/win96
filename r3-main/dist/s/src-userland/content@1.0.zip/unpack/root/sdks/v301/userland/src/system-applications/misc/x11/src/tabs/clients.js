/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

app program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

app program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with app program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates the clients tab.
 * @param {TabControl} tabc Tab controller.
 * @param {X11Application} app The app instance.
 */
function createClientsTab(tabc, app) {
    tabc.addPage("Clients", (e) => {
        e.innerHTML = `<div class="pg-content clients">
            <div class="list"></div>
            <div class="controls">
                <button class="w96-button disconnect">Disconnect</button>
            </div>
        </div>`;

        // Create list box of clients
        const lbox = new ListBox();

        // Add addresses
        const redraw = () => {
            lbox.clear();

            for(let cl of app.activeClients)
                lbox.addItem(cl.address, cl.address);
        }

        redraw();

        // Commit element
        e.querySelector(".list").replaceWith(lbox.getElement());

        // Disconnect handler
        let selectedId = "";

        // Add disconnect listener
        lbox.onitemselected = (id) => {
            selectedId = id;
        }

        // Register event.
        e.querySelector(".disconnect").addEventListener('click', ()=>{
            const sessionClient = app.activeClients.find(x => x.address == selectedId);
            selectedId = "";

            if(!sessionClient)
                return;

            app.disconnect(sessionClient);
            redraw();
        });
    });
}