/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { requiresCredentials, WinLogon, askSetPassword, setSAMPath, klog, coverUtil } = current.boxedEnv;
const { WindowSystem } = w96;

class LoginApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * The main entry point
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        await super.main(argv);

        const preInitDesktop = document.createElement('div');
        preInitDesktop.style.backgroundColor = "rgb(0, 128, 128)";
        preInitDesktop.style.width = "100vw";
        preInitDesktop.style.height = "100vh";
        preInitDesktop.style.position = "absolute";
        preInitDesktop.style.top = "0px";
        preInitDesktop.style.left = "0px";
        preInitDesktop.style.zIndex = "8";
        preInitDesktop.style.overflow = "hidden";
        preInitDesktop.classList.add('w96-predesk-ui');

        setSAMPath('c:/system/config/SAM.json');

        if(await requiresCredentials()) {
            klog.println("[desktop] Preparing log on system...");
            document.body.appendChild(preInitDesktop);
            WindowSystem.setWindowContainer(preInitDesktop);
            await coverUtil.hideCover();
            const result = await WinLogon.displayLogonUIAsync();
            
            if(!result) {
                klog.error("Auth error -- refusing to boot.");
                return;
            }
            
            await coverUtil.showCover();
            preInitDesktop.remove();
        } /*
        not sure what this does
        else {
            if(zbuild.sam_enforce && !(await requiresCredentials())) {
                preInitDesktop.style.backgroundPosition = '50% 50%';
                preInitDesktop.style.backgroundRepeat = 'no-repeat';
                preInitDesktop.style.backgroundImage = 'url(/system/resource/misc/setup.png)';

                document.body.appendChild(preInitDesktop);
                WindowSystem.setWindowContainer(preInitDesktop);
                await coverUtil.hideCover();
                await askSetPassword();
                await askSetRCON();
                await coverUtil.showCover();
                preInitDesktop.remove();
            }
        }*/

        w96.evt.sys.emit('logon');
        this.terminate();
    }
}