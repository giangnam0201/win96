/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const appsToDeliver = [];

// These apps may cause issues
const disallowedApps = ["/apps/setup/uinit_stage3"];

let statusWnd;

/**
 * Creates the toast container
 */
function createStatusContainer() {
    statusWnd = new StandardWindow({
        title: "App Delivery Status",
        bodyClass: "app-delivery-wnd",
        body: `<div class="ad-status"></div>`,
        initialWidth: 300,
        initialHeight: 69,
        animations: {
            windowClose: "anim-null",
            windowOpen: "anim-null"
        },
        controlBoxStyle: "WS_CBX_NONE",
        taskbar: false,
        resizable: false,
        showCommentsBtn: false
    });

    statusWnd.show();

    statusWnd.onshown = () => {
        if(statusWnd) { // Race
            statusWnd.wndObject.style.left = "auto";
            statusWnd.wndObject.style.top = "10px";
            statusWnd.wndObject.style.right = "10px";
        }
    }

    return statusWnd.getBodyContainer().querySelector(".ad-status");
}

/**
 * Delivers an app to Windows 96.
 * @param {String} path The path of the app to deliver.
 * @returns 
 */
async function deliverApp(path, icon) {
    if(appsToDeliver.includes(path) || disallowedApps.includes(path))
        return; // Do not allow app delivery until first instance is done
    else
        appsToDeliver.push(path);

    let statusListContainer = document.querySelector(".ad-status");
    const APP_NAME = FSUtil.fname(path);

    if(!statusWnd)
        statusListContainer = createStatusContainer();

    // Push app item
    const appItem = document.createElement('div');
    appItem.classList.add('app-item');
    
    // App icon
    const appIcon = document.createElement('div');
    appIcon.classList.add('icon');

    if(icon)
        appIcon.style.backgroundImage = `url(${await Theme.getIconUrl(icon)})`;
    else
        appIcon.style.backgroundImage = `url(${await Theme.getIconUrl("mime/executable", '32x32')})`;

    appItem.appendChild(appIcon);

    // Status container
    const statContainer = document.createElement('div');
    statContainer.classList.add('stat-container');
    appItem.appendChild(statContainer);

    // App name
    const appName = document.createElement('div');
    appName.classList.add('bold-noaa', 'name');
    appName.textContent = APP_NAME;
    statContainer.appendChild(appName);

    // Xferd status
    const xferdStatus = document.createElement('div');
    xferdStatus.classList.add('xferd');
    xferdStatus.textContent = "0 KB / 0 KB";
    statContainer.appendChild(xferdStatus);

    statusListContainer.appendChild(appItem);

    // Do the downloading
    const appText = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        xhr.addEventListener('load', () => {
            resolve(xhr.responseText);
        });

        xhr.addEventListener('error', () => {
            reject();
        })

        xhr.addEventListener('progress', (e) => {
            if(e.lengthComputable)
                xferdStatus.textContent = `${(e.loaded / 1024).toFixed(2)} KB / ${(e.total / 1024).toFixed(2)} KB (${((e.loaded / e.total) * 100).toFixed(2)}%)`;
            else
                xferdStatus.textContent = `(no size info available)`;
        });
    
        xhr.open("GET", `http://${SCM.get("Software/DevConnector/dcAddress")}/build/ul${path}`);
        xhr.send();
    });

    // Write app
    await FS.writestr(`c:/system/local/bin/${APP_NAME}`, appText);

    sockStats.fileOps++;
    updateStatus();

    // Remove from queue
    const index = appsToDeliver.findIndex(x => x == path);

    if(index != -1)
        appsToDeliver.splice(index, 1);

    appItem.remove();

    // Close window if queue empty
    if(appsToDeliver.length == 0) {
        statusWnd.close();
        statusWnd = null;
    }
}