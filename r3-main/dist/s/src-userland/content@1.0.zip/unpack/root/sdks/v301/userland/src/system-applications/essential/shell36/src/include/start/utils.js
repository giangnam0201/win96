/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates a context menu from a folder.
 * @param {String} path The folder path.
 */
async function folder2ContextMenu(path, folderIcon = "places/folder") {
    var ctxMenuItems = [];
    const ents = await FS.readdir(path);

    const files = await ents.aFilter(async(ent)=>await FS.isFile(ent));
    const dirs = await ents.aFilter(async(ent)=>(!await FS.isFile(ent)));

    const sortFn = function(a, b){
        if(FSUtil.fname(a) < FSUtil.fname(b)) { return -1; }
        if(FSUtil.fname(a) > FSUtil.fname(b)) { return 1; }
        return 0;
    }

    files.sort(sortFn);
    dirs.sort(sortFn);

    await dirs.aForEach(async(dirPath)=>{
        ctxMenuItems.push({
            type: "submenu",
            id: (Math.floor(Math.random() * 1000)).toString(),
            label: FSUtil.fname(dirPath),
            icon: await Theme.getIconUrl(folderIcon, "16x16"),
            items: await folder2ContextMenu(dirPath),
            onclick: e => {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    });

    await files.aForEach(async(filePath)=>{
        var icn = await Theme.getFileIconUrl(filePath, "16x16");
        var nm = FSUtil.fname(filePath);

        if(filePath.endsWith(".link")) {
            try {
                nm = nm.split('.').slice(0, -1).join('.');
                const linkObject = JSON.parse(await FS.readstr(filePath));

                if(linkObject.icon_small) {
                    if(linkObject.icon_small.startsWith("data:"))
                        icn = linkObject.icon_small;
                    else
                        icn = await Theme.getIconUrl(linkObject.icon_small);
                }
                else
                {
                    if(linkObject.icon) {
                        if(linkObject.icon.startsWith("data:"))
                            icn = linkObject.icon;
                        else
                            icn = await Theme.getIconUrl(linkObject.icon, "16x16", (linkObject.iconFmt != null ? linkObject.iconFmt : "png"));
                    } else if(await FS.exists(linkObject.action))
                        icn = await Theme.getFileIconUrl(linkObject.action, '16x16', (linkObject.iconFmt != null ? linkObject.iconFmt : "png"));
                }
            } catch(e) {
                console.log(e);
                icn = "system/resource/misc/missing.png";
            }
        }

        ctxMenuItems.push({ type: "normal", icon: icn, label: nm, onclick: (a,b)=>{
            execFile(b);
            startClose();
        }, tag: filePath });
    });

    return ctxMenuItems;
}