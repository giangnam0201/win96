// WDT install script

// Step 1. Remove old versions from path
const pathenv = w96.sys.env.getEnv("path").split(';');

pathenv.forEach((p, i) => {
    if(p.startsWith("C:/sdks") && p.endsWith("wdt/bin"))
        pathenv.splice(i, 1);
});

// Step 2. Add to path
pathenv.push(`C:/sdks/v301/wdt/bin`);

w96.sys.env.setEnv("path", pathenv.join(';'));