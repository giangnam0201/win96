/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { CheckBox } = w96.ui.components;
const { sysConf: SCM } = w96;

class WelcomeApplication extends WApplication {
	constructor() {
		super();

		this.opts = {
			showOnStart: true
		}
	}

    // certainly replace the text of this later
	static defaultItem = {
		heading: "Welcome",
		contents: "<p>Welcome to the exciting new world of Windows 96, where your computer desktop meets the Internet!</p><p>Sit back and relax as you take a brief tour of the options available on this screen.</p><p>If you want to explore an option, just click it.</p>",
		image: "welcome.png"
	};

	static sidebar = [
		{
			shortName: "Register Now",
			heading: "Register Now!",
			contents: "<p>Registering your copy of Windows 96 opens the doors to full Internet support for your system. Better product support, free product enhancements, free tips and tricks, and the coolest Windows add-ons are just a mouse-click away by registering.</p>",
			image: "register_now.png",
			onclick: ()=>{}
		},
		{
			shortName: "Connect to the Internet",
			heading: "Connect to the Internet",
			contents: "<p>On the Internet, you can correspond through electronic mail (e-mail), get the latest news and financial information, and visit Web sites around the world.</p><p>Windows 96 makes getting connected to the Internet quick and simple.</p>",
			image: "connect_to_the_internet.png",
			onclick: ()=>{}
		},
		{
			shortName: "Discover Windows 96",
			heading: "Discover Windows 96",
			contents: "<p>\"Computer Essentials\" introduces first-time users to basic computing.</p><p>\"Windows 96 Overview\" offers step-by-step lessons for new Windows users.</p><p>\"What's New\" highlights the features of Windows 96.</p>",
			image: "discover.png",
			onclick: ()=>{}
		},
		{
			shortName: "Maintain Your Computer",
			heading: "Maintain Your Computer",
			contents: "<p>Speed up your computer! For top-notch performance, schedule regular maintenance that frees up hard disk space, makes your programs run faster, and optimizes the performance of your hard disk.</p>",
			image: "maintain_your_computer.png",
			onclick: ()=>{}
		}
	];

	/**
	 * Entry point.
	 * @param {String[]} argv Arguments.
	 */
	async main(argv) {
		super.main(argv);

		this.mainwnd = this.createWindow({
			title: "Welcome to Windows 96",
			icon: "system/resource/shell/start-icn.png",
			body: `
				<div class="welcome96-header" style="height:60px;padding-bottom:21px;">
					<div class="welcome96-hr" style="position:relative;top:44px;"></div>
					<img src="/system/resource/app/welcome/logo.png" style="position:relative;top:15px;left:36px;">
				</div>
				<div class="welcome96-body">
					<div class="welcome96-sidebar">
						<div class="welcome96-sidebar-item welcome96-sidebar-header"><span>C O N T E N T S</span></div>
					</div>
					<div class="welcome96-content"></div>
				</div>
				<div class="welcome96-footer">
					<div class="welcome96-autostart-checkbox"></div>
					<button class="w96-button welcome96-close-btn">Close</button>
				</div>
			`,
			bodyClass: "welcome96-app",
			minWidth: 477,
			minHeight: 343,
			initialWidth: 477,
			initialHeight: 343,
			center: true,
			resizable: false,
			taskbar: true,
			controlBoxStyle: "WS_CBX_CLOSE"
		}, true);

		this.opts.showOnStart = await FS.exists("c:/system/startup/welcome.link");

		const body = this.mainwnd.getBodyContainer();
		const sidebar = body.querySelector(".welcome96-sidebar");

		// Set events

		body.querySelector(".welcome96-autostart-checkbox").replaceWith(new CheckBox({
			label: "Show this screen each time Windows 96 starts.",
			checked: this.opts.showOnStart,
			onchange: (e)=>this.opts.showOnStart = e.checked,
			displayAsBlock: false
		}).getElement());

		body.querySelector("button.welcome96-close-btn").onclick = ()=>{ this.terminate(); };

		// Sidebar setup
		sidebar.onmouseleave = ()=>this.setContent();

		WelcomeApplication.sidebar.forEach(item => {
			const sideElem = document.createElement("div");
			sideElem.className = "welcome96-sidebar-item";
			sideElem.innerText = item.shortName;
			sideElem.onclick = item.onclick;
			sideElem.onmouseenter = ()=>{ this.setContent(item); };
			sidebar.appendChild(sideElem);
		});

		this.setContent();
		this.music = new Audio("/system/resource/app/welcome/music.ogg");
		this.music.play();

		// this.mainwnd.onclose = () => {
		// 	try {
		// 		if(this.opts.showOnStart) {
		// 			await FS.writestr("c:/system/startup/welcome.link", JSON.stringify({
		// 				action: "welcome",
		// 				icon: "misc/logo"
		// 			}));
		// 		} else {
		// 			if(await FS.exists("c:/system/startup/welcome.link"))
		// 				await FS.rm("c:/system/startup/welcome.link")
		// 		}
		// 	} catch(e) {
		// 		console.error(e);
		// 	}
		// }

		this.mainwnd.show();
	}

	/**
	 * Sets the content.
	 */
	setContent(item = WelcomeApplication.defaultItem) {
		const body = this.mainwnd.getBodyContainer();
		const content = body.querySelector(".welcome96-content");

		body.style.backgroundImage = `url(/system/resource/app/welcome/${item.image}), url(/system/resource/app/welcome/background.png)`;

		while(content.firstChild)
			content.removeChild(content.firstChild);

		content.innerHTML = `<h1 style="margin-top:0;">${item.heading}</h1>${item.contents}`;
	}

	/**
	 * On app close.
	 */
	async ontermination() {
		super.ontermination();
		// Destroy objects

		this.mainwnd = null;
		this.music.pause();
		this.music.removeAttribute("src");
		this.music.load();
	}
}