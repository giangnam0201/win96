/*
Windows 96 exit prompt.
*/

window.onbeforeunload = function() {
    return 'Please check if you have any unsaved work in Windows 96.';
};