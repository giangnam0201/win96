// Ran upon package installation
w96.WRT.runFile("c:/system/boot/mod-eprompt.js"); // Register ext on install