/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, MsgBoxSimple } = w96.ui;

class UploaderApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow();
    }

    async _createWindow() {
        var params = new WindowParams();
        params.title = "Uploader";
        params.initialWidth = 300;
        params.initialHeight = 150;
        params.resizable = false;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setControlBoxStyle("WS_CBX_CLOSE");
        mainwnd.setHtml(`Choose files below and press "Start" to upload them.<br><br>The uploaded files will be saved to the desktop.
        <br>
        <input type="file" class="w96-textbox" multiple=""><br>
        <button class="w96-button start">Start</button>`);

        const htmlContainer = mainwnd.wndObject.querySelector(".window-html-content");
        htmlContainer.classList.add("uploader-app");

        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/uploader", '16x16'));
        
        const startButton = htmlContainer.querySelector(".start");
        const fileInput = htmlContainer.querySelector("input");

        startButton.onclick = async()=> {
            startButton.disabled = true;

            const mbx = MsgBoxSimple.idleProgress("Upload in progress", "The selected files are being saved, please wait...");
            mbx.show();

            for(let x = 0; x < fileInput.files.length; x++) {
                const file = fileInput.files.item(x);
                console.log("Writing " + "c:/user/desktop/" + file.name);
                const arr = new Uint8Array(await file.arrayBuffer());
                await FS.writebin("c:/user/desktop/" + file.name, arr);
            }

            setTimeout(()=>{
                startButton.disabled = false;
                mbx.closeDialog();
            }, 250);
        }

        // Start the app
        mainwnd.show();
        mainwnd.center();
    }
}