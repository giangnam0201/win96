/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, MenuBar } = w96.ui;
const { ListView } = w96.ui.components;

const VMs = [
    {
        label: "Version 2.0 [Service Pack 2]",
        thumb: "/system/resource/app/vm/screenshots/v2sp2.png",
        url: "https://rel2sp2.windows96.net/",
        icon: "misc/logo",
        releaseDate: "29 June 2021"
    },
    {
        label: "Version 2.0 [Service Pack 1]",
        thumb: "/system/resource/app/vm/screenshots/v2sp1.png",
        url: "https://rel2sp1.windows96.net/",
        icon: "misc/logo",
        releaseDate: "4 April 2021"
    },
    {
        label: "Version 2.0",
        thumb: "/system/resource/app/vm/screenshots/v2.png",
        url: "https://rel2.windows96.net/",
        icon: "misc/logo",
        releaseDate: "5 February 2021"
    },
    {
        label: "Version 1.0",
        thumb: "/system/resource/app/vm/screenshots/v1.png",
        url: "https://rel1.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "15 August 2019"
    },
    {
        label: "Version 0.5",
        thumb: "/system/resource/app/vm/screenshots/v05.png",
        url: "https://rel05.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "7 July 2019"
    },
    {
        label: "Version 0.4",
        thumb: "/system/resource/app/vm/screenshots/v04.png",
        url: "https://rel04.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "(no exact date)"
    },
    {
        label: "Version 0.3",
        thumb: "/system/resource/app/vm/screenshots/v03.png",
        url: "https://rel03.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "(no exact date)"
    },
    {
        label: "Version 0.2",
        thumb: "/system/resource/app/vm/screenshots/v02.png",
        url: "https://rel02.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "1 May 2019"
    },
    {
        label: "Version 0.1",
        thumb: "/system/resource/app/vm/screenshots/v01.png",
        url: "https://rel01.windows96.net/",
        icon: "misc/logo-ancient",
        releaseDate: "20 April 2019"
    }
]

class VMApplication extends WApplication {
    constructor() {
        super();
        this.selectedIndex = 0;
    }

    async main(argv) {
        super.main(argv);
        
        const mainwnd = this.createWindow({
            title: "Version Browser",
            initialHeight: 361,
            initialWidth: 540,
            resizable: true,
            taskbar: true,
            bodyClass: "verbrowser-app",
            body: `
                <div class="split-panel">
                    <div class="listview"></div>
                    <div class="preview">
                        <span class="bold-noaa header">Preview</span>
                        <div class="preview-container">
                            <img class="img-container" draggable="false">
                        </div>
                        <span class="bold-noaa header">Actions</span>
                        <div class="actions">
                            <div class="w96-link enlarge">View Screenshot</div>
                            <div class="w96-link launch">Launch</div>
                            <div class="w96-link url">Open as URL</div>
                        </div>
                    </div>
                </div>
                <div class="w96-footer">
                    <div class="cell">
                        Current Version: ${await w96.sys.rel.getVersionString()}
                    </div>
                </div>
            `,
            icon: await Theme.getIconUrl("misc/logo", '16x16')
        }, true);

        // Reference body
        const body = mainwnd.getBodyContainer();
        
        // Setup app layout

        // Create menu
        const menuBar = new MenuBar();

        menuBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        menuBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>void w96.sys.execCmd("about-ui", [])
            }
        ]);

        body.prepend(menuBar.getMenuDiv());

        // Create list view
        const lvw = new ListView();

        lvw.addColumnHeader("Name", 80);
        lvw.addColumnHeader("Release Date", 150);
        lvw.addColumnHeader("Standalone URL");

        // Add versions
        for(let ver of VMs) {
            const i = lvw.pushData([ver.label, ver.releaseDate, ver.url], await Theme.getIconUrl(ver.icon, '16x16'));
            i.addEventListener('click', ()=>this.selectVM(VMs.indexOf(ver)));
            i.addEventListener('dblclick', ()=>this.createVMWindow(VMs.indexOf(ver)));
        }

        body.querySelector(".listview").replaceWith(lvw.getElement());

        // Add events
        body.querySelector(".enlarge").addEventListener("click", ()=>void w96.urlopen(VMs[this.selectedIndex].thumb));
        body.querySelector(".url").addEventListener("click", ()=>void w96.urlopen(VMs[this.selectedIndex].url));
        body.querySelector(".launch").addEventListener("click", ()=>this.createVMWindow(this.selectedIndex));

        mainwnd.show();
        this.mainwnd = mainwnd;

        // Select first item
        lvw.select(0);
        this.selectVM(0);
    }

    /**
     * Creates a VM window.
     * @param {Number} id The VM id.
     */
    async createVMWindow(id) {
        const vmWindow = this.createWindow({
            title: `[${VMs[id].label}]`,
            icon: await Theme.getIconUrl(VMs[id].icon, '16x16'),
            initialHeight: 480,
            initialWidth: 640,
            bodyClass: "if-app",
            body: `<iframe src="${VMs[id].url}"></iframe>`,
            taskbar: true
        });

        vmWindow.show();
    }

    /**
     * Selects a VM.
     * @param {Number} i The VM index.
     */
    selectVM(i) {
        this.selectedIndex = i;
        this.updatePreview();
    }

    /**
     * Updates the preview.
     */
    updatePreview() {
        const vm = VMs[this.selectedIndex];
        this.mainwnd.getBodyContainer().querySelector(".img-container").src = vm.thumb;
    }

    // async _createWindow() {
    //     var params = new WindowParams();
    //     params.title = "Version Browser";
    //     params.initialWidth = 540;
    //     params.initialHeight = 361;
    //     params.resizable = true;

    //     var mainwnd = this.createWindow(params, true);
    //     mainwnd.registerWindow();
    //     mainwnd.registerAppBar();
    //     mainwnd.setHtml(`<div class="main">
    //         <p style="margin-top: 0;">
    //             <span class="bold-noaa">Official Releases</span>
    //         </p>
    //     </div>`);

    //     const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
    //     wContainer.classList.add('vm-app');
    //     mainwnd.setWindowIcon(await Theme.getIconUrl("misc/logo", '16x16'));

    //     const main = wContainer.querySelector('.main');
        
    //     for(let vm of VMs) {
    //         const vmButton = document.createElement('button');
    //         vmButton.classList.add('w96-button', 'vm');

    //         const imgEl = document.createElement('img');
    //         imgEl.src = vm.thumb;

    //         vmButton.appendChild(imgEl);
    //         vmButton.appendChild(document.createElement('br'));
    //         vmButton.appendChild(new Text(vm.label));

    //         vmButton.addEventListener('click', async()=>{
    //             // Create VM Window
    //             const _p = new WindowParams();
    //             _p.initialHeight = 380;
    //             _p.initialWidth = 540;
    //             _p.title = "[" + vm.label + "]";
    //             _p.resizable = true;

    //             const vmWnd = this.createWindow(_p, false);
    //             vmWnd.registerWindow();
    //             vmWnd.registerAppBar();

    //             vmWnd.setWindowIcon(await Theme.getIconUrl("misc/logo", '16x16'));

    //             const vmWndContainer = vmWnd.getBodyContainer();
    //             vmWndContainer.classList.add('subvm-app');

    //             const vmIfr = document.createElement('iframe');
    //             vmIfr.src = vm.url;
    //             vmWndContainer.appendChild(vmIfr);

    //             vmWnd.ondarkenelements = ()=>{
    //                 vmIfr.style.pointerEvents = "none";
    //             }
        
    //             vmWnd.onlightenelements = ()=>{
    //                 vmIfr.style.pointerEvents = "";
    //             }

    //             vmWnd.show();
    //         });

    //         main.appendChild(vmButton);
    //     }

    //     this.mainwnd = mainwnd;

    //     // Start the app
    //     mainwnd.show();
    // }
}