/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * LS command.
 * @param {SCMCApp} app App instance.
 * @param {String[]} argv Program arguments.
 */
async function cmd_LS(app, argv) {
    argv.shift();

    let sortOrder = "RKV";
    let typeFilter = null;

    // Detect sort order
    if((argv.length > 1) && argv.includes("-s")) {
        const sortArg = argv[argv.indexOf("-s") + 1];

        if(sortArg)
            sortOrder = sortArg;
    }

    if((argv.length > 1) && argv.includes("-t")) {
        const typeFilterArg = argv[argv.indexOf("-t") + 1];

        if(typeFilterArg)
            typeFilter = typeFilterArg.toLowerCase();
    }

    // Process
    const path = argv[0] || "";
    const results = SCM.ls(path).filter(x => {
        if(typeFilter)
            return (typeof SCM.get(`${path}/${x.name}`)).toLowerCase() == typeFilter;

        return true;
    });

    const keys = results.filter(x => x.type == "key");
    const roots = results.filter(x => x.type == "root");
    const values = results.filter(x => x.type == "value");

    term.println(`Listing for \u001b[33m${(path == "") ? "<root>" : path}\u001b[0m\n`);

    if(results.length == 0) {
        term.println("<empty>");
        return 0;
    }

    // Show results
    for(let c of sortOrder.split('')) {
        switch(c) {
            case "R":
                for(let i of roots)
                    term.println(`<\u001b[31mROOT\u001b[0m>   ${i.name}`);

                    break;
            case "K":
                for(let i of keys)
                    term.println(`<\u001b[33mKEY\u001b[0m>    ${i.name}`);

                break;
            case "V":
                for(let i of values)
                    term.println(`<\u001b[35mVALUE\u001b[0m>  ${i.name}`);

                break;
        }
    }
    
    return 0;
}