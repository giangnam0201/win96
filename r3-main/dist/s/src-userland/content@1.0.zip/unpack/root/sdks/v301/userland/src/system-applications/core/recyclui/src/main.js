/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, DialogCreator, OperationDialog } = w96.ui;
const systemFolders = ["/trash", "/system"];
const systemDrive = "C:";
const trashPath = `${systemDrive}/trash`;

/**
 * Fix drive letter case.
 */
function pathFix(p) {
    return p.replaceAt(0, p[0].toUpperCase());
}

/**
 * Recycle UI application.
 */
class RecycleUIApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        argv.shift();

        // Path fix all args
        argv.forEach((v, i, a)=>a[i] = pathFix(v));

        // Create trash folder if it does not exist.
        if(!await FS.exists(trashPath))
            await FS.mkdir(trashPath);

        if(argv.length == 0)
            return; // No items were specified.

        // Preliminary check - ensure all queued deletions are in the same parent path
        // If this check is not done, we have catastrophic failure.
        const parentReq = FSUtil.getParentPath(argv[0]);

        for(let path of argv) {
            const parent = FSUtil.getParentPath(path);

            if(parent !== parentReq) {
                const dlg = DialogCreator.create({
                    title: "Error",
                    body: "General failure.",
                    icon: "error" 
                });

                await dlg.wait();
                return 1;
            }
        }
        
        // Determine deletion type
        // Can be trash or permanent, depends on where the file is located.
        // TODO check if permanent parameter is present in argv
        let deleteType = "permanent";

        for(let path of argv) {
            // Check if the paths are legal
            if((path == null) || (!await FS.exists(path))) {
                const dlg = DialogCreator.create({
                    title: "Error",
                    body: "Invalid argument.",
                    icon: "error" 
                });

                await dlg.wait();
                return 1;
            }   

            const dp = await FSUtil.deconstructFullPath(path);

            // Check for funny paths.
            if(dp.path == "/") {
                const dlg = DialogCreator.create({
                    title: "Error",
                    body: "You cannot recycle a drive root.",
                    icon: "error"
                });

                await dlg.wait();
                return 1;
            } else if((dp.prefix == systemDrive) && (systemFolders.includes(dp.path))) {
                const dlg = DialogCreator.create({
                    title: "Error",
                    body: "Unable to delete system folder.",
                    icon: "error"
                });

                await dlg.wait();
                return 1;
            }

            // Determine deletion type
            if(!path.startsWith(`${trashPath}/`))
                deleteType = "trash";
        }

        // Window vars
        let icon;
        let title;
        let text;

        // For singular deletion
        if(argv.length == 1) {
            const isFile = await FS.isFile(argv[0]);
            
            if(deleteType == "trash") {
                icon = await Theme.getIconUrl(`status/trash-${isFile ? 'file' : 'dir'}`, '32x32');
                text = `Are you sure you want to send '${FSUtil.fname(argv[0])}' to the Recycle Bin?`;
            }
            else
                text = `Are you sure you want to delete '${FSUtil.fname(argv[0])}'?`;

            title = `Confirm ${isFile ? "File" : "Folder"} Delete`;
        } else { // For multiple
            title = "Confirm Multiple Item Delete";

            if(deleteType == "trash") {
                icon = await Theme.getIconUrl(`status/trash-dir`, '32x32');
                text = `Are you sure you want to send these ${argv.length} items to the Recycle Bin?`
            } else
                text = `Are you sure you want to delete these ${argv.length} items?`
        }

        // Show file destruction icon
        if(deleteType == "permanent")
            icon = await Theme.getIconUrl('actions/delete-permanent')

        // Create the window
        const mainwnd = this.createWindow({
            title,
            taskbar: false,
            resizable: false,
            controlBoxStyle: "WS_CBX_CLOSE",
            initialWidth: 412,
            initialHeight: 145,
            center: true,
            bodyClass: "app-dlg-recycle",
            body: `<div class="content">
                <div class="icon" style="background-image: url(${icon})"></div>
                <div class="text">${text}</div>
            </div>
            <div class="buttons">
                <button class="w96-button yes">Yes</button>
                <button class="w96-button no">No</button>
            </div>`,
            animations: {
                windowClose: "anim-null",
                windowOpen: "anim-null"
            }
        }, true);

        const body = mainwnd.getBodyContainer();
        const yesBtn = body.querySelector('.buttons>.yes');
        
        yesBtn.addEventListener('click', ()=>this.processDeletions(argv, deleteType));
        body.querySelector('.buttons>.no').addEventListener('click', ()=>mainwnd.close());

        mainwnd.onshown = ()=>yesBtn.focus();

        mainwnd.show();
        this.mainwnd = mainwnd;
    }

    /**
     * Process item deletions.
     */
    async processDeletions(paths, deleteType) {
        this.mainwnd.setVisible(false);

        try {
            if(deleteType == "trash")
                await OperationDialog.recycle(paths);
            else
                await OperationDialog.delete(paths, "trash");
        } catch(e) {
            DialogCreator.create({
                title: "Error",
                body: `${e}`,
                icon: "error"
            });

            return 0;
        }

        this.mainwnd.close();
        this.terminate();
    }

    /**
     * Ensure application gets closed.
     */
    ontermination() {
        super.ontermination();
    }
}