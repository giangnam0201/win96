/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/** @type {HTMLDivElement} */
let taskbar;

/**
 * Sets up the taskbar.
 */
function setupTaskbar() {
    taskbar = document.createElement('div');
    taskbar.classList.add("user-taskbar", "slideInUp");
    
    // Setup notification area
    const notifyArea = document.createElement('div');
    notifyArea.classList.add('taskbar-notify');
    
    // Add clock to notify area
    const notifyClock = document.createElement('span');
    notifyClock.classList.add("notify-time", "notify-item");
    notifyClock.innerText = "00:00";
    notifyArea.appendChild(notifyClock);

    // Add notify area to taskbar
    taskbar.appendChild(notifyArea);

    // Add tasks container and separator
    const tasksContainer = document.createElement('div');
    tasksContainer.classList.add("taskbar-tasks");
    taskbar.appendChild(tasksContainer);

    const separator = document.createElement("div");
    separator.classList.add("separator");
    taskbar.appendChild(separator);

    // Add start button
    const startButton = document.createElement("button");
    startButton.classList.add("start_button", "w96-button");

    startButton.addEventListener('click', ()=>{
        StartMenu.toggle();

        if(StartMenu.isOpen())
            startButton.classList.add('sb-active');
        else
            startButton.classList.remove('sb-active');
    });

    taskbar.appendChild(startButton);
}