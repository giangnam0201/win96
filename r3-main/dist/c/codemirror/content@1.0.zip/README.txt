CodeMirror Windows 96 edition (C) windows96.net 2022.

CodeMirror (C) http://codemirror.net
 * See LICENSE.txt in c:/local/cmirror for CodeMirror license.