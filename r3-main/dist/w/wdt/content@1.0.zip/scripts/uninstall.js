// WDT remove script

// Step 1. Remove from path
const pathenv = w96.sys.env.getEnv("path").split(';');

pathenv.forEach((p, i) => {
    if(p.startsWith("C:/sdks") && p.endsWith("wdt/bin"))
        pathenv.splice(i, 1);
});

w96.sys.env.setEnv("path", pathenv.join(';'));