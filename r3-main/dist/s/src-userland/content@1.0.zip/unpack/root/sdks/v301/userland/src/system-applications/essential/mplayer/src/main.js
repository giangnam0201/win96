/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

$$Include("./backends/HTMLAudio.js")
$$Include("./backends/HTMLVideo.js")


const { OpenFileDialog, Theme, DialogCreator, MenuBar } = w96.ui;

class MPlayerApplication extends WApplication {
    constructor() {
        super();
    }

    static backends = [
        MPlayer_HTMLAudio,
        MPlayer_HTMLVideo
    ]

    static resources = {
        play: "W:/system/resource/app/mplayer/icons/play.png",
        pause: "W:/system/resource/app/mplayer/icons/pause.png",
        stop: "W:/system/resource/app/mplayer/icons/stop.png",
        eject: "W:/system/resource/app/mplayer/icons/eject.png",
        previousMark: "W:/system/resource/app/mplayer/icons/previousMark.png",
        rewind: "W:/system/resource/app/mplayer/icons/rewind.png",
        fastForward: "W:/system/resource/app/mplayer/icons/fastForward.png",
        nextMark: "W:/system/resource/app/mplayer/icons/nextMark.png",
        startSelection: "W:/system/resource/app/mplayer/icons/startSelection.png",
        endSelection: "W:/system/resource/app/mplayer/icons/endSelection.png",
        thumb: "W:/system/resource/app/mplayer/icons/thumb.png",
        thumbActive: "W:/system/resource/app/mplayer/icons/thumb-active.png"
    }

    secondsToString(time) {
        const timeFloor = Math.floor(time);

        let hours = Math.floor(timeFloor / 3600);
        let minutes = Math.floor((timeFloor - (hours * 3600)) / 60);
        let seconds = timeFloor - (hours * 3600) - (minutes * 60);

        if (hours < 10) { hours = "0" + hours; };
        if (minutes < 10) { minutes = "0" + minutes; };
        if (seconds < 10) { seconds = "0" + seconds; };

        return hours + ':' + minutes + ':' + seconds;
    }

    async loadResources() {
        this.resources = {};

        for(let key in this.constructor.resources) {
            let blob = new Blob([await FS.readbin(this.constructor.resources[key])], { type: 'image/png' });
            this.resources[key] = URL.createObjectURL(blob);
        }
    }

    revokeResources() {
        for(let key in this.resources) {
            URL.revokeObjectURL(this.resources[key]);
        }
    }

    async main(argv) {
        super.main(argv);

        this.player = null;
        this.currentFile = null;
        try {
            await this.loadResources();
        } catch(err) {
            DialogCreator.alert('Failed to load media player icons.', {
                icon: 'error',
                title: 'Error'
            });
            return console.error('[Media Player]', err);
        }

        this.mainwnd = this.createWindow({
            title: "Media Player",
            icon: await Theme.getIconUrl('apps/mplayer', '16x16'),
            body: `
                <div class="mplayer-menubar"></div>
                <div class="mplayer-main">
                    <div class="mplayer-progress">
                        <div class="mplayer-progress-bar">
                            <div class="slider"></div>
                        </div>
                        <div class="mplayer-timestamps">
                            <div class="ts ts-start"></div>
                            <div class="ts ts-end"></div>
                        </div>
                    </div>
                    <div class="w96-ui-inset-separator"></div>
                    <div class="mplayer-buttons">
                        <div class="mplayer-button-group">
                            <button class="w96-button mplayer-play-pause" disabled><img src="${this.resources.play}"></button>
                            <button class="w96-button mplayer-stop" disabled><img src="${this.resources.stop}"></button>
                            <button class="w96-button mplayer-eject" disabled><img src="${this.resources.eject}"></button>
                        </div>
                        <div class="mplayer-button-group">
                            <button class="w96-button mplayer-previous_mark" disabled><img src="${this.resources.previousMark}"></button>
                            <button class="w96-button mplayer-rewind" disabled><img src="${this.resources.rewind}"></button>
                            <button class="w96-button mplayer-fast_forward" disabled><img src="${this.resources.fastForward}"></button>
                            <button class="w96-button mplayer-next_mark" disabled><img src="${this.resources.nextMark}"></button>
                        </div>
                        <div class="mplayer-button-group">
                            <button class="w96-button mplayer-start_selection" disabled><img src="${this.resources.startSelection}"></button>
                            <button class="w96-button mplayer-end_selection" disabled><img src="${this.resources.endSelection}"></button>
                        </div>
                        <input type="text" class="w96-textbox mplayer-status" readonly>
                    </div>
                </div>
            `,
            minWidth: 392,
            minHeight: 111,
            initialWidth: 392,
            initialHeight: 111,
            taskbar: true
        }, true);
        this.videownd = null;

        const body = this.mainwnd.getBodyContainer();
        const menuBar = new MenuBar();

        this.statusBar = body.querySelector(".mplayer-status");
        this.progressBar = body.querySelector(".mplayer-progress-bar");
        this.thumb = body.querySelector(".mplayer-progress-bar>.slider");

        this.progressBar.onmousedown = e => {
            if (!this.player) return;
            this.progMouseDown = true;
            this._mouseMoveListener(e);
            this.thumb.style.background = `url(${this.resources.thumbActive})`;
        };

        this._mouseMoveListener = e => {
            if (this.progMouseDown) {
                let offsetX = e.clientX - this.progressBar.getBoundingClientRect().left;
                if (offsetX > this.progressBar.offsetWidth) {
                    offsetX = this.progressBar.offsetWidth;
                }

                this.player.time(offsetX / this.progressBar.offsetWidth * this.player.duration());
            }
        };

        this._mouseUpListener = e => {
            this.progMouseDown = false;
            this.thumb.style.background = `url(${this.resources.thumb})`;
        };

        document.body.addEventListener('mousemove', this._mouseMoveListener);
        document.body.addEventListener('mouseup', this._mouseUpListener);

        this.thumb.style.background = `url(${this.resources.thumb})`;

        this.buttons = {
            playPause: body.querySelector(".mplayer-play-pause"),
            stop: body.querySelector(".mplayer-stop"),

            previousMark: body.querySelector(".mplayer-previous_mark"),
            rewind: body.querySelector(".mplayer-rewind"),
            fastForward: body.querySelector(".mplayer-fast_forward"),
            nextMark: body.querySelector(".mplayer-next_mark"),

            startSelection: body.querySelector(".mplayer-start_selection"),
            endSelection: body.querySelector(".mplayer-end_selection"),
        };

        this.buttons["playPause"].onclick = ()=>{
            if (this.player.state() !== 1)
                this.player.play();
            else
                this.player.pause();
        };

        this.buttons["stop"].onclick = ()=>{
            this.player.stop();
        };

        this.buttons["previousMark"].onclick = () => {
            this.player.time(0);
        };

        this.buttons["fastForward"].onclick = () => {
            this.player.time(this.player.time() + (this.player.duration() / 16));
        };

        this.buttons["rewind"].onclick = () => {
            this.player.time(this.player.time() - (this.player.duration() / 16));
        };

        menuBar.addRoot("File", [
            {
                type: "normal",
                label: "Open...",
                onclick: ()=>{
                    const openFileDialog = new OpenFileDialog("C:/user", this.constructor.backends.map(backend => backend.fileExtensions).flat(), path => {
                        if (path) {
                            this.openFile(path).catch(err => {
                                console.error(err);

                                DialogCreator.alert(
                                    "An error occurred while loading the file.",
                                    {
                                        title: "Media Player - Error",
                                        icon: "error"
                                    }
                                );
                            });
                        }
                    });

                    openFileDialog.show();
                }
            },
            {
                type: "normal",
                label: "Close",
                onclick: ()=>{ this.closeFile(); }
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>{ this.terminate(); }
            }
        ]);

        menuBar.addRoot("Edit", [
            {
                type: "normal",
                label: "Copy Object",
                onclick: ()=>{
                    w96.wmem.clipboard.items = [this.currentFile];
                    w96.wmem.clipboard.action = "copy";
                }
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Options",
                onclick: ()=>{},
                disabled: true
            },
            {
                type: "normal",
                label: "Selection...",
                onclick: ()=>{},
                disabled: true
            }
        ]);

        // Of course these will be replaced in the final
        menuBar.addRoot("Device", [
            ...this.constructor.backends.map((backend, index) => ({
                type: "normal",
                label: `${index + 1} ${backend.backendName}`,
                onclick: ()=>{
                    const openFileDialog = new OpenFileDialog("C:/user", backend.fileExtensions, path => {
                        if (path) {
                            this.openFile(path).catch(err => {
                                console.error(err);

                                DialogCreator.alert(
                                    "An error occurred while loading the file.",
                                    {
                                        title: "Media Player - Error",
                                        icon: "error"
                                    }
                                );
                            });
                        }
                    });

                    openFileDialog.show();
                }
            })),
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Properties",
                onclick: ()=>{},
                disabled: true
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Volume Control",
                onclick: ()=>{
                    // DialogCreator.alert(
                    //     "how the fuck do i make the slider work properly when rotated by 240°",
                    //     {
                    //         title: "long answer",
                    //         icon: "question"
                    //     }
                    // );
                    // sorry dark cant implement since my 98 vm mcfucking died :D
                },
                disabled: true
            }
        ]);

        menuBar.addRoot("Scale", [
            {
                type: "normal",
                label: "Time",
                onclick: ()=>{}
            },
            {
                type: "normal",
                label: "Frames",
                onclick: ()=>{}
            },
            {
                type: "normal",
                label: "Tracks",
                onclick: ()=>{}
            }
        ]);

        menuBar.addRoot("Help", [
            {
                type: "normal",
                label: "Help Topics",
                onclick: ()=>{},
                disabled: true
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "About Media Player",
                onclick: ()=>DialogCreator.alert('<span class="bold-noaa">MPlayer</span><br>Version 1.0<br>', {
                    title: "About Media Player",
                    icon: "info"
                })
            }
        ]);

        body.querySelector(".mplayer-menubar").replaceWith(menuBar.getMenuDiv());

        this.mainwnd.show();
        if (argv[1]) {
            let ok = await this.openFile(argv[1]);
            if (!ok) return;
            this.player.play();
        }
    }

    async openFile(path) {
        this.closeFile();

        const fileExt = FSUtil.getExtension(path).toLowerCase().substring(1);
        const suitableBackend = this.constructor.backends.find(backend => backend.fileExtensions.includes(fileExt));
        // Ask which one if there's multiple?

        if (!suitableBackend) {
            DialogCreator.alert(
                "Unsupported file type: " + fileExt,
                {
                    title: "Media Player - Error",
                    icon: "error"
                }
            );
            return false;
        }

        try {
            this.mainwnd.setTitle(`Media Player - ${FSUtil.fname(path)} (loading)`);

            this.player = new suitableBackend();

            this.player.onloaded = async () => {
                this.mainwnd.setTitle(`Media Player - ${this.player.getName()} (stopped)`);
                this.thumb.style.left = '';

                for (let button in this.buttons) {
                    this.buttons[button].disabled = false;
                }

                this.buttons["stop"].disabled = true;

                if (this.player.duration() < 60)
                    this.statusBar.value = "0.00 (sec)";
                else
                    this.statusBar.value = "00:00:00 (hrs:min:sec)";

                let video = this.player.getVideoElement();

                if (video) {
                    this.videownd = this.createWindow({
                        title: "Media Player - Video",
                        icon: await Theme.getIconUrl('apps/mplayer', '16x16'),
                        body: "",
                        minWidth: 320,
                        minHeight: 160,
                        initialWidth: Math.min(640, video.videoWidth),
                        initialHeight: Math.min(480, video.videoHeight),
                        taskbar: true
                    }, false);

                    let vbody = this.videownd.getBodyContainer();
                    vbody.classList.add("mplayer-video");
                    vbody.appendChild(video);

                    this.videownd.show();
                }
            };

            // With the HTML players when the media is stopped it does pause first then ended GRRRRRRRR JUST DO ONLY STOP
            this.player.onplay = () => {
                this.mainwnd.setTitle(`Media Player - ${this.player.getName()} (playing)`);
                this.buttons["playPause"].children[0].src = this.resources.pause;

                if (!this.player.time())
                    this.buttons["stop"].disabled = false;
            };

            this.player.onpause = () => {
                this.buttons["playPause"].children[0].src = this.resources.play;
                this.mainwnd.setTitle(`Media Player - ${this.player.getName()} (paused)`);

                if (!this.player.time())
                    this.buttons["stop"].disabled = true;
            };

            this.player.onended = () => {
                this.buttons["playPause"].children[0].src = this.resources.play;
                this.mainwnd.setTitle(`Media Player - ${this.player.getName()} (stopped)`);

                this.buttons["stop"].disabled = true;
                this.player.time(0);
            };

            this.player.ondurationchange = duration => {
                // this.progressBar.max = duration;
            };

            this.player.ontimeupdate = currentTime => {
                if (!this.player)
                    return; // i hate the media api GRRRRRRR SKJH RGHIUKESWJGH RTHJRE

                this.thumb.style.left = `calc(${(currentTime / this.player.duration())*100}% - 5px)`;

                if (this.player.duration() < 60)
                    this.statusBar.value = currentTime.toFixed(2) + " (sec)";
                else
                    this.statusBar.value = this.secondsToString(currentTime) + " (hrs:min:sec)";
            };

            // there's a thing for seeking too so maybe i should do seeking events

            this.player.onerror = e => {
                DialogCreator.alert(
                    e.message,
                    {
                        title: "Media Player - Error",
                        icon: "error"
                    }
                );

                this.closeFile();
            };

            await this.player.load(path);
            this.currentFile = path;
            return true;
        } catch (err) {
            DialogCreator.alert(
                err.message,
                {
                    title: "Media Player - Error",
                    icon: "error"
                }
            );

            this.closeFile();
            return false;
        }
    }

    closeFile() {
        for (let button in this.buttons) {
            this.buttons[button].disabled = true;
        }

        this.buttons["playPause"].children[0].src = this.resources.play;

        this.mainwnd.setTitle("Media Player");

        this.thumb.style.left = '';
        this.statusBar.value = "";

        if (this.player)
            this.player.unload();

        this.player = null;

        if (this.videownd) {
            this.videownd.close();
            this.videownd = null;
        }
    }

    ontermination() {
        super.ontermination();

        if (this.player)
            this.player.unload();

        this.player = null;
        this.revokeResources();
        document.body.removeEventListener('mousemove', this._mouseMoveListener);
        document.body.removeEventListener('mouseup', this._mouseUpListener);
    }
}