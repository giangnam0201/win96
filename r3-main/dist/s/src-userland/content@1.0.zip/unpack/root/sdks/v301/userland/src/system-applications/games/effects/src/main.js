/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { Theme, MessageBox } = w96.ui;
const { setEnv } = w96.sys.env;

function _clsAdd_mgfx(c) {
    const maingfx = document.querySelector("#maingfx");
    maingfx.classList.add(c);
}

function _clsRemove_mgfx(c) {
    const maingfx = document.querySelector("#maingfx");
    maingfx.classList.remove(c);
}

function _clsAdd_body(c) {
    const _body = document.querySelector("body");
    _body.classList.add(c);
}

function _clsRemove_body(c) {
    const _body = document.querySelector("body");
    _body.classList.remove(c);
}

const fxMap = {
    hue: {
        start: function() {
            _clsAdd_body('fx-hue');
        },
        stop: function() {
            _clsRemove_body('fx-hue');
        }
    },
    spinner: {
        start: function() {
            _clsAdd_body('fx-spin');
        },
        stop: function() {
            _clsRemove_body('fx-spin');
        }
    },
    "upside-down": {
        start: function() {
            _clsAdd_body('fx-upside-down');
        },
        stop: function() {
            _clsRemove_body('fx-upside-down');
        }
    },
    zoom: {
        start: function() {
            _clsAdd_body('fx-zoom');
        },
        stop: function() {
            _clsRemove_body('fx-zoom');
        }
    },
    deepfryer: {
        start: function() {
            _clsAdd_body('fx-deepfryer');
        },
        stop: function() {
            _clsRemove_body('fx-deepfryer');
        }
    },
    grayscale: {
        start: function() {
            _clsAdd_body('fx-grayscale');
        },
        stop: function() {
            _clsRemove_body('fx-grayscale');
        }
    },
    invert: {
        start: function() {
            _clsAdd_body('fx-invert');
        },
        stop: function() {
            _clsRemove_body('fx-invert');
        }
    },
    blur: {
        start: function() {
            _clsAdd_body('fx-blur');
        },
        stop: function() {
            _clsRemove_body('fx-blur');
        }
    },
    disco: {
        start: function() {
            var deskOverlay = document.querySelector('.fx-desk-overlay');
            if(!deskOverlay) {
                deskOverlay = document.createElement('div');
                deskOverlay.classList.add('fx-desk-overlay', 'fx-hue');
                document.querySelector('.user-desktop').appendChild(deskOverlay);
            }
        },
        stop: function() {
            var fxDeskOverlay = document.querySelector('.fx-desk-overlay');
            if(fxDeskOverlay)
                fxDeskOverlay.remove();
        }
    },
    neon: {
        start: function() {
            var neonStyleEl = document.querySelector(".fx-neon-css");

            if(!neonStyleEl) {
                neonStyleEl = document.createElement('style');
                neonStyleEl.classList.add('fx-neon-css');
                document.body.appendChild(neonStyleEl);
            }

            neonStyleEl.innerHTML = `
            .window-dlg:not(.ui-sortable-helper) {
                box-shadow: 0 0 12px 6px #c725d4 !important;
            }
            
            .start-menu {
                box-shadow: 0px 0px 20px 4px lime !important;
            }
            
            .wcontext-menu {
                box-shadow: 0 0 11px 0px cyan !important;
            }`;
        },
        stop: function() {
            var neonStyleEl = document.querySelector(".fx-neon-css");
            if(neonStyleEl)
                neonStyleEl.remove();
        }
    },
    sepia: {
        start: function() {
            _clsAdd_body('fx-sepia');
        },
        stop: function() {
            _clsRemove_body('fx-sepia');
        }
    },
    bright: {
        start: function() {
            _clsAdd_body('fx-bright');
        },
        stop: function() {
            _clsRemove_body('fx-bright');
        }
    },
    bw: {
        start: function() {
            _clsAdd_body('fx-bw');
        },
        stop: function() {
            _clsRemove_body('fx-bw');
        }
    }
}

class FXApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow();
        this.fxQueue = [];
        setEnv("fxQueue", this.fxQueue);
    }

    getFxNames() {
        var outputHtml = "";

        const fxMapNames = Object.keys(fxMap).sort(function(a, b) {
            if(a > b) return 1;
            if(a < b) return -1;
            return 0;
        });

        fxMapNames.forEach((v)=>{
            outputHtml += '<option name="' + v + '">' + v + '</option>\n';
        })
        return outputHtml;
    }

    _resetFx() {
        this.fxQueue.forEach((fxN)=>{
            fxMap[fxN].stop();
        });

        this.fxQueue = [];
    }

    async _createWindow() {
        this.appDlg = new MessageBox("Effects", `Select an effect below:<br><br>
<select class="w96-select" style="width: 100%">
    ${this.getFxNames()}
</select>`, '../apps/effects', "OK", ()=>{});
        this.appDlg.dlg.registerAppBar();
        this.appDlg.dlg.setWindowIcon(await Theme.getIconUrl("apps/effects", "16x16"));

        const buttons = this.appDlg.dlg.wndObject.querySelector(".buttons");
        buttons.innerHTML = `<button class="w96-button btnappend">Append</button>
        <button class="w96-button btnapply">Apply</button>
        <button class="w96-button btnreset">Reset</button>`;

        const selector = this.appDlg.dlg.wndObject.querySelector('select');

        const applyButton = buttons.querySelector('.btnapply');
        const resetButton = buttons.querySelector('.btnreset');
        const appendButton = buttons.querySelector('.btnappend');

        applyButton.onclick = ()=> {
            this._resetFx();
            this.fxQueue = [selector.value];
            setEnv("fxQueue", this.fxQueue);
            fxMap[selector.value].start();
        }

        resetButton.onclick = ()=> {
            this._resetFx();
        }

        appendButton.onclick = ()=> {
            if(this.fxQueue.includes(selector.value))
                return;

            this.fxQueue.push(selector.value);
            setEnv("fxQueue", this.fxQueue);
            fxMap[selector.value].start();
        }

        this.appDlg.setSize(320, 130);
        this.appDlg.show();
        this.appDlg.dlg.center();
    }
}