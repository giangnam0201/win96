/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, Theme } = w96.ui;
const { RadioBox } = w96.ui.components;
const { WizardBaseApplication } = w96.app.templates;

class ResetWizardApp extends WizardBaseApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        const introPage = this.findPage("intro");
        introPage.titleText = "Welcome to the Reset Wizard";
        introPage.graphic = "/system/resource/app/resetwiz/graphic.png";
        introPage.body = `This wizard will help you to completely reset your current installation.<br>
        <br>
        Please ensure you have a backup of any important data before starting, should anything happen at all.
        <br>
        <br>
        <span class="bold-noaa">WARNING: If you choose to delete everything, the data will NOT be recoverable!</span>`;
        introPage.buttons[1].onclick = ()=>this.openPage("reset-select", []);

        // Variable for radio box
        let radioActSelect = "clear-user";

        // Reset options selection page
        this.pages.push({
            id: "reset-select",
            type: "page",
            body: `Select an action:
                <div class="w96-radiobox"></div>`,
            graphic: "/system/resource/app/resetwiz/graphic-top.png",
            titleText: "What would you like to reset?",
            description: "Choose carefully what you would like to reset.",
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("intro", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{
                        if(radioActSelect == "clear-user")
                            this.openPage("reset-user", []);
                        else
                            this.openPage("reset-all", []);
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{
                const opts = new RadioBox([
                    {
                        label: "Reset everything but keep user files (c:/user)",
                        id: "clear-user",
                        onselect: ()=>{ radioActSelect = "clear-user"; },
                        selected: true
                    },
                    {
                        label: "Completely reset the current installation",
                        id: "clear-all",
                        onselect: ()=>{ radioActSelect = "clear-all"; },
                        selected: false
                    }
                ]);

                page.querySelector('.w96-radiobox').replaceWith(opts.getElement());
            }
        });

        // Reset but keep user files page
        this.pages.push({
            id: "reset-user",
            type: "page",
            body: `
                <div>
                    To begin resetting everything but keeping user files, you may press Next.<br>
                    <br>Ensure that any unsaved files are saved, and that any programs which might be using the disk are closed.<br><br>
                    <span class="bold-noaa">All installed programs, program data, and custom system configurations will be removed.</span>
                </div>
            `,
            graphic: "/system/resource/app/resetwiz/graphic-top.png",
            titleText: "Begin the reset",
            description: `Read the information below carefully.`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("reset-select", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: async()=>{
                        MsgBoxSimple.idleProgress("Reset Wizard", "Working - please wait...");

                        this.mainwnd.wndObject.style.display = "none";

                        for(let i of await FS.readdir("c:/")) {
                            if(i.toLowerCase() == "c:/user")
                                continue;

                            try {
                                if(await FS.isFile(i)) {
                                    await FS.rm(i);
                                } else {
                                    await FS.rmdir(i);
                                }
                            } catch(e) {

                            }
                        }

                        localStorage.clear();

                        this.mainwnd.close();
                        document.location.reload();
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{}
        });

        // Reset all page
        this.pages.push({
            id: "reset-all",
            type: "page",
            body: `
                <div>
                    To begin resetting everything, you may press Next.<br>
                    <br>
                    <span class="bold-noaa">Everything will be lost, and nothing can be recovered. Back up any data you care about.</span>
                </div>
            `,
            graphic: "/system/resource/app/resetwiz/graphic-top.png",
            titleText: "Begin a full reset",
            description: `Read the information below carefully.`,
            buttons: [
                {
                    class: "back",
                    onclick: ()=>this.openPage("reset-select", []),
                    enabled: true,
                    text: "Back"
                },
                {
                    class: "next",
                    onclick: ()=>{
                        let idbid = localStorage.getItem('storeid');
                        localStorage.clear();
                        if(indexedDB) {
                            const dbReq = indexedDB.deleteDatabase(idbid);

                            dbReq.onsuccess = ()=> {
                                console.log("DB clear successful!");
                                localStorage.setItem('storeid', idbid);
                                document.location.reload();
                            };

                            dbReq.onerror = ()=> {
                                console.error("DB clear failed!");
                                localStorage.setItem('storeid', idbid);
                                document.location.reload();
                            };

                            dbReq.onblocked = ()=> {
                                console.error("Operation blocked - cannot clear DB.");
                                localStorage.setItem('storeid', idbid);
                                document.location.reload();
                            };
                        } else {
                            document.location.reload();
                        }
                    },
                    enabled: true,
                    text: "Next"
                },
                {
                    class: "cancel",
                    onclick: ()=>this.quit(),
                    enabled: true,
                    text: "Cancel"
                }
            ],
            onopen: (page, args)=>{}
        });

        this.openPage("intro", []);
        this.mainwnd.setTitle("Reset Wizard");
        this.mainwnd.setWindowIcon(await Theme.getIconUrl("apps/resetwiz", '16x16'));
        this.mainwnd.center();
    }
}