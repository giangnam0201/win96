/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, DialogCreator, Theme } = w96.ui;

class GameingRunnerApplication extends WApplication {
    constructor() {
        super();

        this.blobUrls = [];
    }

    async fsMkBlob(path) {
        const url = URL.createObjectURL(await FS.toBlob(path));
        this.blobUrls.push(url);
        return url;
    }

    async main(argv) {
        super.main(argv);

        if(argv[1] == null) {
            await DialogCreator.alert("Gameing Runner v1.0<br><br>Usage: gameing-runner &lt;version&gt;", {
                icon: "info",
                title: "Gameing"
            }).wait();

            return;
        }

        let loadingUrl = "";

        const versionDir = `c:/user/appdata/gameing/versions/${argv[1].trim()}`;

        if(!await FS.exists(versionDir)) {
            await DialogCreator.alert("The target version is not installed.", {
                icon: "error",
                title: "Gameing"
            }).wait();
            return;
        }

        const fsProgress = MsgBoxSimple.idleProgress("Gameing", "Loading game data...");
        fsProgress.dlg.getBodyContainer().querySelector(".icon").style.backgroundImage = `url(${await Theme.getIconUrl("apps/gameing")})`;

        // Load data from FS

        try {
            // Create required BLOBs
            const blob = {
                code: await this.fsMkBlob(versionDir + "/bin/code"),
                data: await this.fsMkBlob(versionDir + "/bin/data"),
                framework: await this.fsMkBlob(versionDir + "/bin/framework"),
                URT: await this.fsMkBlob(versionDir + "/scripts/URT.js"),
                bg: await this.fsMkBlob(versionDir + "/bg.jpg")
            };

            // Modify the temporary build JSON
            const bjs_regexReplace = [
                {
                    expr: /\$DATA_URL\$/g,
                    val: blob.data
                },
                {
                    expr: /\$WASM_URL\$/g,
                    val: blob.code
                },
                {
                    expr: /\$FRAMEWORK_URL\$/g,
                    val: blob.framework
                },
                {
                    expr: /\$BACKGROUND_URL\$/g,
                    val: blob.bg
                }
            ]

            let buildJson = await FS.readstr(versionDir + "/build.json");
            
            for(let rpl of bjs_regexReplace)
                buildJson = buildJson.replace(rpl.expr, rpl.val);

            // Create a temporary directory
            const randUrl = `c:/system/temp/gameing${Math.floor(Math.random() * 10000)}`
            await FS.mkdir(randUrl);

            // Write the temporary build json file
            
            await FS.writestr(randUrl + "/build.json", buildJson);
            const newBuildJsonUrl = await this.fsMkBlob(randUrl + "/build.json");

            // Read and modify included index file
            let indexFileContent = await FS.readstr(versionDir + "/index.html");
            
            const index_regexReplace = [
                {
                    expr: /\$BUILD_URL\$/g,
                    val: newBuildJsonUrl
                },
                {
                    expr: /\$URT_JS\$/g,
                    val: blob.URT
                }
            ]

            for(let rpl of index_regexReplace)
                indexFileContent = indexFileContent.replace(rpl.expr, rpl.val);

            // Create temporary index file
            await FS.writestr(randUrl + "/index.html", indexFileContent);

            // Set the loading URL
            loadingUrl = await this.fsMkBlob(randUrl + "/index.html");

            fsProgress.closeDialog();
        } catch(e) {
            console.error(e);
            alert(e, { icon: "error" });
            fsProgress.closeDialog();
            return;
        }

        const mainwnd = this.createWindow({
            title: "Gameing",
            body: `
                <iframe src="${loadingUrl}"></iframe>
            `,
            bodyClass: "gameing-app",
            taskbar: true,
            icon: await Theme.getIconUrl("apps/gameing", '16x16'),
            initialWidth: 640,
            initialHeight: 441
        }, true);

        const body = mainwnd.getBodyContainer();
        const appFrame = body.querySelector("iframe");

        appFrame.onload = ()=> {
            
        }

        mainwnd.show();
    }

    ontermination() {
        super.ontermination();

        for(let url of this.blobUrls)
            URL.revokeObjectURL(url);
    }
}