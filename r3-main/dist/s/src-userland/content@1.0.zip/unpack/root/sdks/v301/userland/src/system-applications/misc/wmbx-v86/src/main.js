/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, OpenFileDialog, SaveFileDialog, DialogCreator, Theme, MenuBar} = w96.ui;

class WMBoxRunner extends WApplication {
    constructor() {
        super();

        this.emulatorConfig = {
            disable_keyboard: true,
            disable_mouse: true,
            bios: {
                url: "/system/apps/wmbox/libs/v86/bios/seabios.bin"
            },
            network_adapter: null,
            vga_bios: {
                url: "/system/apps/wmbox/libs/v86/bios/vgabios.bin"
            } // TODO let user specify custom emulator config and bios
        };

        this.blobsToUnregister = [];
    }

    async main(argv) {
        super.main(argv);

        if(argv[1] == null) {
            DialogCreator.create({
                title: "WMBox",
                body: `No WMX file was specified to run.`,
                icon: "error"
            });
            return;
        }

        const mainwnd = this.createWindow({
            title: " - WMBox",
            icon: await Theme.getIconUrl("apps/wmbox", '16x16'),
            initialWidth: 728,
            initialHeight: 473,
            taskbar: true,
            resizable: true,
            bodyClass: "wmbx-runner-app",
            body: `<div class="appbar"></div>
            <iframe class="vm" src="/system/apps/wmbox/vm.html"></iframe>
            <footer class="w96-footer">
                <div class="cell">Visible Viewport &lt;0x0&gt;</div>
            </footer>`,
            center: true,
            mobResize: true
        }, true);

        mainwnd.setTitle("<null> - WMBox");

        const body = mainwnd.getBodyContainer();

        // Setup UI
        const appBar = new MenuBar();

        appBar.addRoot("File", [
            /*{
                type: "normal",
                label: "Stop Execution",
                onclick: ()=>{}
            },
            {
                type: "separator"
            },*/
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate() // TODO gracefully terminate to save user data
            }
        ]);

        appBar.addRoot("Machine", [
            {
                type: "normal",
                label: "Pause",
                onclick: ()=>{
                    try {
                        this.emu.stop();
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to pause this machine.`,
                            icon: "error"
                        });
                    }
                }
            },
            {
                type: "normal",
                label: "Resume",
                onclick: ()=>{
                    try {
                        this.emu.run();
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to resume this machine.`,
                            icon: "error"
                        });
                    }
                }
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Reset",
                onclick: ()=>{
                    try {
                        this.emu.restart();
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to restart this machine.`,
                            icon: "error"
                        });
                    }
                }
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Save State",
                onclick: ()=>{
                    try {
                        this.emu.save_state((err, state)=>{
                            if(err) {
                                DialogCreator.create({
                                    title: "WMBox",
                                    body: `Unable to save this machine's state: ${err}`,
                                    icon: "error"
                                });
                            } else {
                                new SaveFileDialog("c:/user/documents", [".wms"], async(v)=>{
                                    if(v && (v.trim() != "")) {
                                        const stat = MsgBoxSimple.idleProgress("WMBox", "Saving state...");

                                        try {
                                            await FS.writebin(v, new Uint8Array(state));
                                        } catch(fex) {
                                            DialogCreator.create({
                                                title: "WMBox",
                                                body: `Unable to save this machine's state: ${fex}`,
                                                icon: "error"
                                            });
                                        }

                                        stat.closeDialog();
                                    }
                                }).show();
                            }
                        })
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to save this machine's state.`,
                            icon: "error"
                        });
                    }
                }
            },
            {
                type: "normal",
                label: "Load State",
                onclick: ()=>{
                    try {
                        new OpenFileDialog("c:/user/documents", [".wms"], async(v)=>{
                            if(v && (v.trim() != "")) {
                                const stat = MsgBoxSimple.idleProgress("WMBox", "Loading state...");

                                try {
                                    this.emu.restore_state(await FS.readbin(v));
                                } catch(fex) {
                                    DialogCreator.create({
                                        title: "WMBox",
                                        body: `Unable to load this machine's state: ${fex}`,
                                        icon: "error"
                                    });
                                }

                                stat.closeDialog();
                            }
                        }).show();
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to load this state.`,
                            icon: "error"
                        });
                    }
                }
            }
        ]);

        appBar.addRoot("View", [
            {
                type: "normal",
                label: "Enter Fullscreen",
                onclick: ()=>this.appFrame.requestFullscreen()
            },
            {
                label: "Scale Mode",
                type: "submenu",
                items: [
                    {
                        type: "normal",
                        label: "Aspect",
                        onclick: ()=>this.setViewMode('aspect')
                    },
                    {
                        type: "normal",
                        label: "Scaled",
                        onclick: ()=>this.setViewMode('scaled')
                    }
                ]
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Take Screenshot",
                onclick: ()=>{
                    try {
                        const canvas = this.appFrame.contentDocument.querySelector('canvas');

                        canvas.toBlob(async(b)=>{
                            const ua = new Uint8Array(await b.arrayBuffer());

                            new SaveFileDialog("c:/user/documents", [".png"], async(v)=>{
                                if(v && (v.trim() != "")) {
                                    try {
                                        await FS.writebin(v, ua);
                                    } catch(e) {
                                        DialogCreator.create({
                                            title: "WMBox",
                                            body: `Unable to take screenshot.`,
                                            icon: "error"
                                        });
                                    }
                                }
                            }).show();
                        }, 'image/png');
                    } catch(e) {
                        DialogCreator.create({
                            title: "WMBox",
                            body: `Unable to take screenshot.`,
                            icon: "error"
                        });
                    }
                }
            }
        ], false);

        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>DialogCreator.alert('<span class="bold-noaa">WMBox with v86 Backend (wmbxrun-v86)</span><br>Version 1.0<br><br>v86 is made possible by <a href="https://copy.sh">copy.sh</a>', {
                    title: "About WMBox",
                    icon: "info"
                })
            }
        ]);

        body.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        const appFrame = body.querySelector("iframe");

        appFrame.onload = async()=> {
            try {
                appFrame.contentWindow.app.init({
                    instance: this,
                    onresize: (sz)=>{
                        body.querySelector('footer .cell').innerText = `Visible Viewport: <${sz.width}x${sz.height}>`;
                    }
                });

                await this.readWMX(argv[1]);
                this.startVM(); // TODO make runner not run without args
            } catch(e) {
                DialogCreator.create({
                    title: "WMBox",
                    body: `An error occurred: ${e}<br><br>VM execution has been halted.`,
                    icon: "error"
                });

                this.terminate();
            }
        }

        mainwnd.show();
        this.mainwnd = mainwnd;
        this.appFrame = appFrame;
    }

    async readWMX(path) {
        const wmx = JSON.parse(await FS.readstr(path));

        if(!wmx.backend)
            throw new Error("This VM has no backend specified.");

        if(wmx.backend !== "v86")
            throw new Error("This runner only supports VMs using the v86 backend.");

        if((!wmx.meta)
        || (!wmx.meta.name)
        || (!wmx.memory_size)
        || (!wmx.vga)
        || (!wmx.vga.memory_size)
        || (!wmx.attachments))
            throw new Error("Malformed WMX file.");

        this.mainwnd.setTitle(`${wmx.meta.name} <v86> - WMBox`);

        if(wmx.meta.icon)
            this.mainwnd.setWindowIcon(`/system/resource/app/wmbox/icons/${wmx.meta.icon}.png`);

        // Set basic config values
        this.emulatorConfig.disable_keyboard = (wmx.attachments.find(x=>x.type == "keyboard") == null);
        this.emulatorConfig.disable_mouse = (wmx.attachments.find(x=>x.type == "mouse") == null);

        // Set base WMX path
        const baseWmxPath = FSUtil.getParentPath(path);
        this.baseWmxPath = baseWmxPath;

        // Check for cdrom
        const cdromAttachment = wmx.attachments.find(x => x.type == "cdrom");

        if(cdromAttachment) {
            const resolvedPath = FSUtil.resolvePath(baseWmxPath, cdromAttachment.path);

            this.emulatorConfig.cdrom = {
                url: (await FS.exists(resolvedPath)) ? (await FS.toURL(resolvedPath)) : resolvedPath
            }; // TODO check if path is in FS

            this.blobsToUnregister.push(this.emulatorConfig.cdrom.url);
        }

        // Check for fda
        const fdaAttachment = wmx.attachments.find(x => x.type == "fda");

        if(fdaAttachment) {
            const resolvedPath = FSUtil.resolvePath(baseWmxPath, fdaAttachment.path);

            this.emulatorConfig.fda = {
                url: (await FS.exists(resolvedPath)) ? (await FS.toURL(resolvedPath)) : resolvedPath
            };

            this.blobsToUnregister.push(this.emulatorConfig.fda.url);
        }

        // Resolve miscellaneous "url" paths
        await this.resolveUrlField(wmx, "bios");
        await this.resolveUrlField(wmx, "vga_bios");
        await this.resolveUrlField(wmx, "hdd");

        // Assign miscellaneous values
        this.emulatorConfig.memory_size = wmx.memory_size;
        this.emulatorConfig.vga_memory_size = wmx.vga.memory_size;
        this.emulatorConfig.boot_order = wmx.boot_order || undefined;
        this.emulatorConfig.acpi = wmx.acpi || undefined;
        this.emulatorConfig.cmdline = wmx.cmdline || undefined;
        this.emulatorConfig.v86 = wmx.v86 || undefined;
    }

    async resolveUrlField(object, propName) {
        const fieldObj = object[propName];

        if(fieldObj) {
            const resolvedPath = FSUtil.resolvePath(this.baseWmxPath, fieldObj.path);

            this.emulatorConfig[propName] = {
                url: (await FS.exists(resolvedPath)) ? (await FS.toURL(resolvedPath)) : resolvedPath
            };

            this.blobsToUnregister.push(this.emulatorConfig[propName].url);
        }
    }

    startVM() {
        this.appFrame.contentWindow.app.hookEvents();

        const emu = this.appFrame.contentWindow.app.createEmulator({
            ...this.emulatorConfig,
            autostart: true
        });

        this.emu = emu;
    }

    setViewMode(mode) {
        if(mode == "scaled") {
            this.appFrame.contentDocument.body.classList.add('view-scaled');
        } else {
            this.appFrame.contentDocument.body.classList.remove('view-scaled');
        }
    }

    ontermination() {
        try {
            this.emu.destroy();
        } catch(e) {}

        for(let b of this.blobsToUnregister)
            URL.revokeObjectURL(b);

        this.mainwnd = null;
        this.appFrame = null;
        this.emu = null;

        super.ontermination();
    }
}