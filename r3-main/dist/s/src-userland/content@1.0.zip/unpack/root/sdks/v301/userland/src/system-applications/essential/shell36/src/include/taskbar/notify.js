/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/** @type {Number} */
let clockInt = 0;
let errorNI;

/**
 * Initializes the error notifier.
 */
function initializeErrorNotifyIcon() {
    // TODO convert to OS service called "ErrorHost"
    // TODO use different way to handle events
    window.onerror = async function(e) {
        if(Flags.has("exclaim_exceptions")) {
            // TODO use dialogCreator
            MsgBoxSimple.error("JavaScript Runtime Error", `An exception has occured during the current session of Windows 96.<br><br>
            <div style="border-style: inset; border-width: 1px; height: 30px; overflow: auto;" class="w96-panel">
            Exception: ${e}
            </div>`, "OK").setSize(320, 156);
        }

        if(errorNI == null) {
            errorNI = new NotifyIcon({
                iconUrl: await Theme.getIconUrl("status/error", '16x16')
            });

            Taskbar.registerNotifyIcon(errorNI);
        }

        errorNI.onclick = function() {
            MsgBoxSimple.error("JavaScript Runtime Error", `An exception has occured during the current session of Windows 96.<br><br>
            <div style="border-style: inset; border-width: 1px; height: 30px; overflow: auto;" class="w96-panel">
            Exception: ${escapeHtml(new String(e))}
            </div>`, "OK").setSize(320, 156);
        }

        // Ensure to log to system log
        w96.sys.log.log("Exception Caught: " + new String(e), "System", "error");
    };
}

/**
 * Checks a time digit.
 * @param {String} t The time digit. 
 */
function chkTimeDigit(t) {
    if(t < 10)
        return "0" + t;

    else return t;
}

/**
 * Initializes the taskbar clock.
 */
function initializeClock() {
    if(clockInt !== 0) return; // Do not initialize twice

    /**
     * Clock update callback.
     */
    const updateClock = ()=>{
        // TODO fix
        const date = new Date();
        const timeEl = taskbar.querySelector(".notify-time");

        if (WindowSystem.getConfig().features.use12hTime) {
            var h = date.getHours();
            var b = (h>12?(h-12):h);
            timeEl.innerHTML = `${b===0?12:b}:${chkTimeDigit(date.getMinutes())} &nbsp;${(h>=12?"PM":"AM")}`;
        } else
            timeEl.innerText = `${chkTimeDigit(date.getHours())}:${chkTimeDigit(date.getMinutes())}`;
        
    }

    clockInt = setInterval(updateClock, 1000);

    // Update now
    updateClock();
}