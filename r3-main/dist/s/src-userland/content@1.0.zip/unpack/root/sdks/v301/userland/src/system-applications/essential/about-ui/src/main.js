/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { rel, execCmd, execFile } = w96.sys;

class WinVerApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        await super.main(argv);

        const mainwnd = this.createWindow({
            title: "About Windows 96",
            initialWidth: 419,
            initialHeight: 347,
            controlBoxStyle: "WS_CBX_CLOSE",
            bodyClass: "app-winver",
            body: `<div class="header"></div>
            <div class="body">
            Mikesoft Windows 96
            Version ${w96.sys.rel.getVersionString()} (${await w96.sys.rel.getBuildId()})
            Copyright (C) SYS36 2019 - ${1900 + new Date().getYear()}.

            Windows 95 & 98 icons (C) Microsoft Corporation.
            Windows(tm) is a registered trademark of Microsoft Corporation.
            Other trademarks and logos are property of their respective owners.

            <a class="oss" href="#">Open Source Licenses</a>
            <a class="cred" href="#">View Credits</a>
            <a class="support" href="#">Support Us</a>
            </div>
            <div class="buttons">
                <button class="w96-button ok">OK</button>
            </div>`,
            taskbar: false,
            center: true,
            resizable: false
        }, true);

        const body = mainwnd.getBodyContainer();
        
        // Set events
        body.querySelector('button.ok').addEventListener('click', ()=>mainwnd.close());
        body.querySelector('a.oss').addEventListener('click', ()=>execFile("C:/system/credits.txt"));
        body.querySelector('a.cred').addEventListener('click', ()=>execCmd("credits", []));
        body.querySelector('a.support').addEventListener('click', ()=>execCmd("donation-ui", []));

        mainwnd.show();
    }
}