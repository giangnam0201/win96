/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const alphaSortFn = function (a, b) {
    if (a.getAttribute("name").toLowerCase() < b.getAttribute("name").toLowerCase()) { return -1; }
    if (a.getAttribute("name").toLowerCase() > b.getAttribute("name").toLowerCase()) { return 1; }
    return 0;
};

/**
 * Checks if the specified function is a class.
 */
function isClass(v) {
    return typeof v === 'function' && /^\s*class\s+/.test(v.toString());
}

/**
 * Checks if the specified function is an asynchronous function.
 */
function isAsyncFunction(v) {
    return typeof v === 'function' && /^\s*async\s+/.test(v.toString());
}