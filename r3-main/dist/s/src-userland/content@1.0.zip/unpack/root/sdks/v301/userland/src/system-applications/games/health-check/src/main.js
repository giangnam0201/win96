/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { execCmd } = w96.sys;
const { Theme, DialogCreator } = w96.ui;

class HealthCheckApp extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        const mainwnd = this.createWindow({
            title: "PC Health Check",
            initialHeight: 672,
            initialWidth: 672,
            icon: await Theme.getIconUrl("apps/pchc", '16x16'),
            center: true,
            taskbar: true,
            bodyClass: "health-app",
            body: `
                <div class="top">
                    <div class="title">
                        PC health at a glance
                    </div>
                </div>
                <div class="mid">
                    <div class="left">
                        <div class="device"></div>
                        <div class="device-title">DESKTOP-MCRO96</div>
                        <div class="specs">
                            <div class="spec">32 MB RAM</div>
                            <div class="spec">512 MB HDD</div>
                            <div class="spec">26 years old</div>
                        </div>
                    </div>
                    <div class="content">
                        <div class="upgrade-notify-box">
                            <div>
                                <span class="bold-noaa">INTRODUCING WINDOWS 97</span>
                            </div>
                            <div class="ex">
                                Let's check if this PC meets the system requirements.<br>
                                If it does, you can get the free upgrade when it's available.
                            </div>
                            <button class="w96-button check-now">Check now</button>
                        </div>

                        <div class="check-items">
                            <div class="item account">
                                <div class="top">
                                    <div class="icon"></div>
                                    <div class="title"><span class="bold-noaa">Backup and Sync</span></div>
                                    <div class="action alert">Attention required</div>
                                </div>

                                <div class="explanation">
                                    <span class="title">Sign in with a Mikesoft account to get started</span>
                                    <div>
                                        <div style="display: inline-block;width: calc(100% - 75px);">
                                            Keep your preferences in sync across devices, and set up MikeDrive to sync your files too. It will only cost you your precious soul and data.
                                        </div>
                                        <button class="w96-button sign-in" style="display: inline-block; vertical-align: top; width: 68px; margin-left: 2px;">Sign in</button>
                                    </div>
                                </div>
                            </div>

                            <div class="item update">
                                <div class="top">
                                    <div class="icon"></div>
                                    <div class="title"><span class="bold-noaa">Windows Update</span></div>
                                    <div class="action">You are up to date</div>
                                </div>
                            </div>

                            <div class="item storage">
                                <div class="top">
                                    <div class="icon"></div>
                                    <div class="title"><span class="bold-noaa">Storage Capacity</span></div>
                                    <div class="action">50% full</div>
                                </div>
                            </div>

                            <div class="item startup">
                                <div class="top">
                                    <div class="icon"></div>
                                    <div class="title"><span class="bold-noaa">Startup Time</span></div>
                                    <div class="action">Ok</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bottom">
                    <span class="text">Related Links</span>

                    <div class="right">
                        <button class="w96-button tips" disabled>Tips on PC health</button>
                        <button class="w96-button more-w97">More on Windows 97</button>
                    </div>
                </div>
            `
        }, true);

        const body = mainwnd.getBodyContainer();

        body.querySelector(".w96-button.check-now").addEventListener('click', ()=>{
            DialogCreator.create({
                title: "This PC can't run Windows 97",
                icon: "error",
                body: "The processor isn't supported for Windows 97. <br>While this PC doesn't meet the system requirements to run Windows 97,<br> you'll keep getting Windows 96 updates."
            });
        });

        body.querySelector(".w96-button.sign-in").addEventListener('click', ()=>{
            DialogCreator.create({
                title: "Sign in error",
                icon: "error",
                body: "Unable to contact the Mikesoft Cloud servers. This is probably your fault."
            });
        });

        body.querySelector(".w96-button.more-w97").addEventListener('click', ()=>{
            DialogCreator.create({
                title: "Error",
                icon: "error",
                body: "General failure"
            });
        });

        mainwnd.show();
    }
}