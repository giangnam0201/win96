/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MenuBar, Theme, DialogCreator, SaveFileDialog } = w96.ui;
const { ListView } = w96.ui.components;
const { log } = w96.sys;

class SysLogApplication extends WApplication {
    constructor() {
        super();
        this.state = {
            _sfdInitialDir: "C:/user"
        }
    }

    /**
     * Entry point.
     * @param {String[]} argv Program arguments.
     */
    async main(argv) {
        await super.main(argv);

        const iconMap = {
            error: await Theme.getIconUrl("status/error", '16x16'),
            warning: await Theme.getIconUrl("status/warning", '16x16'),
            info: await Theme.getIconUrl("status/info", '16x16'),
            none: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
        }

        const mainwnd = this.createWindow({
            title: "System Log",
            icon: await Theme.getIconUrl("apps/syslog", '16x16'),
            initialHeight: 380,
            initialWidth: 550,
            bodyClass: "systemlog-app",
            body: `
                <div class="appbar"></div>
                <div class="content">
                    <div class="table"></div>
                    <div class="description w96-textbox" readonly></div>
                </div>
                <footer class="w96-footer">
                    <div class="cell">
                        0 items.
                    </div>
                </footer>
            `,
            taskbar: true
        }, true);

        this.mainwnd = mainwnd;

        // Setup window
        const body = mainwnd.getBodyContainer();
        
        // Create menu bar
        const appBar = new MenuBar();

        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Dump To File...",
                onclick: ()=>new SaveFileDialog(this.state._sfdInitialDir, [".json", ".slg"], (v) =>{
                    if(v) {
                        this.state._sfdInitialDir = FSUtil.getParentPath(v);
                        FS.writestr(v, JSON.stringify(log.events));
                    }
                }).show()
            },
            {
                type: "separator"
            },
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.terminate()
            }
        ]);

        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: async()=>DialogCreator.alert("<span class=\"bold-noaa\">System Event Log</span><br>Version 1.0", {
                    title: "About",
                    icon: await Theme.getIconUrl("apps/syslog")
                })
            }
        ]);

        body.querySelector(".appbar").replaceWith(appBar.getMenuDiv());

        // Create list view
        const lvw = new ListView();
            
        lvw.addColumnHeader("Level", 80);
        lvw.addColumnHeader("Source", 100);
        lvw.addColumnHeader("Date/Time");

        // Populate list
        // Use reverse order
        for(let i = (log.events.length - 1); i >= 0; i--) {
            const e = log.events[i];
            let severityString;

            // Get severity string and icon
            switch(e.severity) {
                case "info":
                    severityString = "Information";
                    break;
                case "warning":
                    severityString = "Warning";
                    break;
                case "error":
                    severityString = "Error";
                    break;
                case "none":
                    severityString = "Other";
                    break;
            }

            const itemEl = lvw.pushData([severityString, e.source, e.date], iconMap[e.severity] || null);
            
            itemEl.addEventListener('click', () => {
                this.displayDescription(e);
            });
        }

        body.querySelector(".table").replaceWith(lvw.getElement());

        // Select first item
        if(log.events.length > 0) {
            lvw.select(0);
            this.displayDescription(log.events[log.events.length - 1]);
        }

        // Update counter
        body.querySelector(".cell").textContent = (log.events.length == 1) ? "1 item" : `${log.events.length} items`;

        mainwnd.onshown = () => {
            if(log.silenced) {
                DialogCreator.alert("The system event log has been silenced, nothing to see here.", {
                    title: "System Event Log",
                    icon: "error"
                });
            }
        }

        mainwnd.show();
    }

    /**
     * Displays the description for the specified item.
     * @param {*} item Event log item.
     */
    displayDescription(item) {
        const descriptionPane = this.mainwnd.getBodyContainer().querySelector(".description");
        descriptionPane.textContent = `Source: ${item.source}\n\nDate: ${new Date(item.date).toString()}\n\nMessage: ${item.message}`;
    }

    /**
     * On application close.
     */
    async ontermination() {
        await super.ontermination();
        this.mainwnd = null;
    }
}