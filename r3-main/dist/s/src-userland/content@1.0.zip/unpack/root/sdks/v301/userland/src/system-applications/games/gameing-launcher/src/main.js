/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, DialogCreator, Theme } = w96.ui;
const { GroupBox } = w96.ui.components;
const { sideloadZip, wait } = w96.util;
const { execCmd } = w96.sys;
const { mkShortcut } = w96.shell;

const SERVE_URL = "https://serve01.windows96.net/gameing";

class GameingLauncherApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(document.querySelector(".gameing-launcher-app")) return;

        // Fetch remote builds
        const progress = MsgBoxSimple.idleProgress("Launcher", "Fetching latest game builds...");
        
        let gameBuilds = [];
        
        try {
            const response = await fetch(SERVE_URL + "/builds.json");
            gameBuilds = await response.json();
        } catch(e) {
            console.error(e);

            await DialogCreator.alert("Failed to fetch builds!", {
                icon: "error"
            }).wait();
        }

        progress.closeDialog();

        // Show main launcher UI

        const mainwnd = this.createWindow({
            title: "Gameing Launcher",
            body: `
                <div class="intro">
                    Gameing is a sandbox game which you can download + play or stream.<br>
                    <br>
                    Note: Downloading requires more system RAM whilst streaming requires less RAM but more network bandwidth.
                </div>
                <div class="main">
                    <div class="group-box"></div>
                </div>
                <div class="buttons">
                    <button class="w96-button quit">Quit</button>

                    <button class="w96-button dlp">Play</button>
                    <button class="w96-button stream">Stream</button>
                </div>
            `,
            bodyClass: "gameing-launcher-app",
            center: true,
            taskbar: true,
            resizable: false,
            controlBoxStyle: "WS_CBX_MINCLOSE",
            icon: await Theme.getIconUrl("apps/gameing", '16x16'),
            initialWidth: 417,
            initialHeight: 233
        }, true);

        const body = mainwnd.getBodyContainer();

        const gbox = new GroupBox({
            title: "Game Options",
            body: `
                <div class="field">
                    <span class="name">Game Version:</span>
                    <select class="w96-textbox version-sel"></select>
                </div>
                <a href="#" class="mk-shortcut">Create shortcut</a>
            `
        });

        body.querySelector(".group-box").replaceWith(gbox.getElement());

        const select = body.querySelector('select');

        // Add items
        for(let build of gameBuilds) {
            const opt = document.createElement('option');
            opt.value = build;
            opt.innerText = build;
            select.appendChild(opt);
        }

        if(gameBuilds.length == 0) {
            DialogCreator.alert("No builds were found!", {
                icon: "error"
            });

            body.querySelectorAll('button:not(.quit)').forEach((v)=>v.disabled = true);
        } else
            select.selectedIndex = select.options.length - 1;

        // Assign events
        body.querySelector('button.quit').addEventListener('click', ()=>mainwnd.close());

        body.querySelector('button.stream').addEventListener('click', ()=>{
            execCmd("gameing-streamed", [gameBuilds[select.selectedIndex]]);
            mainwnd.close();
        });

        body.querySelector('button.dlp').addEventListener('click', ()=>this.processLocal(gameBuilds[select.selectedIndex]));

        body.querySelector(".mk-shortcut").addEventListener('click', ()=>{
            if(!gameBuilds[select.selectedIndex]) return;
            mkShortcut("c:/user/desktop/" + gameBuilds[select.selectedIndex] + ".link", "apps/gameing", "gameing-runner " + gameBuilds[select.selectedIndex]);
            DialogCreator.alert("A shortcut was placed on the desktop.", { icon: "info" });
        });

        mainwnd.show();
        this.mainwnd = mainwnd;
    }

    async processLocal(buildCode) {
        const rootFldr = `c:/user/appdata/gameing/versions/${buildCode}`;
        const dlRoot = `https://serve01.windows96.net/gameing/versions/${buildCode}/dl`;

        if(await FS.exists(rootFldr + "/build.json")) {
            // Launch the runner and quit.
            execCmd("gameing-runner", [buildCode]);
            this.mainwnd.close();
            return;
        }

        // Do the downloading
        const body = this.mainwnd.getBodyContainer();
        body.classList.add('busy');
        body.querySelectorAll('button').forEach((v)=>v.disabled = true);

        // Create download dialog
        const downloadDlg = DialogCreator.create({
            title: "Game Download",
            body: `Retrieving version ${buildCode}, this may take some time...
            <br>
            <br>
            <div class="w96-progressbar">
                <div class="progress" style="width: 0%;animation: none;"></div>
            </div>
            <br>
            <div class="status">
                Downloading null [0 / 7] (100K / 200K complete)
            </div>`,
            buttons: [],
            icon: "info" // Replace with gameing icon
        });

        downloadDlg.wnd.setControlBoxStyle("WS_CBX_NONE");

        const dlBody = downloadDlg.wnd.getBodyContainer();
        dlBody.querySelector(".icon").style.backgroundImage = `url(${await Theme.getIconUrl("apps/gameing")})`;

        const progress = dlBody.querySelector(".progress");
        const status = dlBody.querySelector(".status");

        const filesToDownload = [
            // We can simply use the sideloadZip function for this: "resources.zip",
            "bin/code",
            "bin/framework",
            "bin/data"
        ];

        try {
            status.innerText = "Downloading resources...";
            await sideloadZip(dlRoot + "/resources.zip");

            status.innerText = "Downloading additional files...";

            let c = 0;

            for(let f of filesToDownload) {
                status.innerText = "Downloading " + f;
                const buf = await fetch(dlRoot + "/" + f).then((v)=>v.arrayBuffer());
                let data = new Uint8Array(buf);
                await FS.writebin(rootFldr + "/" + f, data);
                data = null;
                c++;
                progress.style.width = `${Math.floor(c / filesToDownload.length * 100)}%`;
            }

            status.innerText = "Download complete, launching game in 3 seconds...";
            await wait(3000);
            execCmd("gameing-runner", [buildCode]);
        } catch(e) {
            console.error(e);
            alert(e, { icon: "error" });
        }

        downloadDlg.close();
        this.mainwnd.close();
    }

    ontermination() {
        super.ontermination();
        this.mainwnd = null;
    }
}