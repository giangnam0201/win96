DOOM Copyright (C) 1993 Id Software.

This is the shareware version, not the full game.

In order to play the full game, you need to purchase the original and load the WAD into the ZIP file.