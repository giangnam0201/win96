/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { MsgBoxSimple, DialogCreator } = w96.ui;
const { ZipReadOnlyFileSystem } = w96.fstype;
const { execCmd } = w96.sys;

class ZipMountApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);

        if(!argv[1]) {
            DialogCreator.alert("No ZIP file was specified.", { icon: "error" });
            return;
        }

        if(!await FS.exists(argv[1])) {
            DialogCreator.alert("ZIP file does not exist.", { icon: "error" });
            return;
        }

        const letter = FS.nextLetter();

        if(!letter) {
            DialogCreator.alert("Out of drive letters.", { icon: "error" });
            return;
        }

        const progressDlg = MsgBoxSimple.idleProgress("ZIP Mounter", "Mounting ZIP file, please wait...");
        
        try {
            const fso = new ZipReadOnlyFileSystem(letter, await FS.readbin(argv[1]));
            fso.volumeLabel = FSUtil.fname(argv[1]);
            await FS.mount(fso);
        } catch(e) {
            DialogCreator.alert(e, { icon: "error" });
        }

        progressDlg.closeDialog();

        execCmd("explorer", [letter + "/"]);
    }
}