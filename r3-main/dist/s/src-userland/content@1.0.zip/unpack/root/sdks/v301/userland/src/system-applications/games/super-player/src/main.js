/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams } = w96;
const { MsgBoxSimple, OpenFileDialog, MenuBar, Theme } = w96.ui;

class SuperPlayerApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        this._createWindow(argv);
        this.loadedBlobs = [];
    }

    async loadSwf(path) {
        if(!await FS.exists(path)) {
            MsgBoxSimple.error("Error", "SWF file does not exist.", "OK");
            return;
        }

        const blob = URL.createObjectURL(await FS.toBlob(path));
        this.loadedBlobs.push(blob);

        this.appWindow.setTitle(FSUtil.fname(path) + " - Super Player");
        
        this.appFrame.contentWindow.load(blob);
    }

    async _createWindow(argv) {
        var params = new WindowParams();
        params.title = "Super Player";
        params.initialWidth = 500;
        params.initialHeight = 420;

        var mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.registerAppBar();
        mainwnd.setHtml(`<div class="appbar"></div><iframe src="/system/apps/super-player"></iframe>`);

        const wContainer = mainwnd.wndObject.querySelector('.window-html-content');
        wContainer.classList.add('super-player-app');
        mainwnd.setWindowIcon(await Theme.getIconUrl("apps/super-player", '16x16'));

        const appBar = new MenuBar();
        
        appBar.addRoot("File", [
            { type: "normal", label: "Open SWF", onclick: ()=>{
                new OpenFileDialog("c:/user/desktop", ["swf", "SWF"], (v)=>{
                    if((!v) || (v.trim() == ""))
                        return;

                    this.loadSwf(v);
                }).show();
            } },
            { type: "separator" },
            { type: "normal", label: "Exit", onclick: ()=>{
                this.mainwnd.close();
            }}
        ]);

        appBar.addRoot("Help", [
            { type: "normal", label: "Read me please", onclick: ()=>{
                MsgBoxSimple.warning ("Read me", 'Please note: not all games work in Ruffle.', "OK");
            } },
            { type: "separator" },
            { type: "normal", label: "About", onclick: ()=>{
                MsgBoxSimple.info ("About Super Player", '<span class="bold-noaa">Super Player</span><br>Version 1.0<br><br>Powered by <a href="https://ruffle.rs/">Ruffle</a>', "OK").dlg.setSize(320, 140);
            }}
        ])

        wContainer.querySelector('.appbar').replaceWith(appBar.getMenuDiv());

        const appFrame = mainwnd.wndObject.querySelector("iframe");

        mainwnd.ondarkenelements = ()=>{
            appFrame.style.pointerEvents = "none";
        }

        mainwnd.onlightenelements = ()=>{
            appFrame.style.pointerEvents = "";
        }

        appFrame.onload = ()=>{
            if(argv[1] != null)
                this.loadSwf(argv[1]);
        }

        this.appFrame = appFrame;
        this.mainwnd = mainwnd;

        // Start the app
        mainwnd.show();
    }

    ontermination() {
        super.ontermination();
        for(let b in this.loadedBlobs)
            URL.revokeObjectURL(b);
    }
}