/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

class IDE {
    /**
     * Shows the start window.
     * @param {MDevEnvApplication} app The app instance.
     */
    constructor(app) {
        this.app = app;
    }

    /**
     * Inits the menu bar.
     */
    async initMenuBar() {
        const body = this.ideWnd.getBodyContainer();
        const appBar = new MenuBar();

        // -- File menu
        appBar.addRoot("File", [
            {
                type: "normal",
                label: "Exit",
                onclick: ()=>this.ideWnd.close()
            }
        ]);

        // -- View menu
        appBar.addRoot("View", [
            {
                type: "normal",
                label: "Start Page",
                onclick: ()=>createStandardTab("start-page", true)
            },
            {
                type: "separator",
            },
            {
                type: "submenu",
                label: "Other Windows",
                items: [
                    {
                        type: "normal",
                        label: "Web Browser",
                        icon: await Theme.getIconUrl("objects/world", '16x16'),
                        onclick: ()=>createStandardTab("web-browser", true)
                    }
                ]
            }
        ], false);

        // -- Help menu
        appBar.addRoot("Help", [
            {
                type: "normal",
                label: "About",
                onclick: ()=>createAboutWindow(this.app)
            }
        ]);

        body.querySelector(".appbar").replaceWith(appBar.getMenuDiv());
    }

    /**
     * Inits the toolbar.
     */
    async initToolBar() {
        const body = this.ideWnd.getBodyContainer();
        const toolbar = new ToolBar({
            iconSize: 20,
            defaults: {
                itemTextPosition: "right"
            },
            compact: true
        });

        // Add items
        toolbar.addItem({
            imageUrl: await Theme.getIconUrl('mime/executable', '16x16'),
            text: "Testing"
        });

        body.querySelector(".toolbar").replaceWith(toolbar.getElement());
    }

    /**
     * Initializes the main view tab control.
     */
    async initTabControl() {
        const body = this.ideWnd.getBodyContainer();
        const tabc = new ExtendedTabControl();
        this.mainTabCtl = tabc;

        createStandardTab("start-page", true);

        body.querySelector(".tab-ctrl").replaceWith(tabc.getElement());
    }

    /**
     * Constructs the window.
     */
    async constructWindow() {
        this.ideWnd = this.app.createWindow({
            title: "Mikesoft DevEnv",
            bodyClass: "wde-app-ide",
            body: `
            <div class="w96-ui-inset">
                <div class="appbar"></div>
                <div class="toolbar"></div>
            </div>

            <div class="content">
                <div class="split-pane">
                    <div class="left">
                        <!-- Main View -->
                        <div class="tab-ctrl"></div>
                    </div>
                    <div class="right">
                        <div class="tool-container">
                            <div class="title">
                                Solution Browser
                            </div>
                            <div class="content">
                                TODO
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mini-window-drawer">

                </div>
            </div>

            <footer class="w96-footer">
                <div class="cell">
                    Ready
                </div>
            </footer>
            `,
            icon: await Theme.getIconUrl("mime/executable", '16x16'),
            taskbar: true,
            resizable: true,
            initialWidth: 800,
            initialHeight: 600
        }, true);

        await this.initMenuBar();
        await this.initToolBar();
        await this.initTabControl();
    }

    /**
     * Starts the IDE environment.
     */
    async begin() {
        await this.constructWindow();

        this.ideWnd.show();
        await this.ideWnd.wait();

        // Cleanup
        this.app = null;
        this.ideWnd = null;
        this.mainTabCtl = null;
    }
}