/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * Creates the about tab.
 * @param {TabControl} tabc Tab controller.
 * @param {X11Application} app The app instance.
 */
function createAboutTab(tabc, app) {
    tabc.addPage("About", (e) => {
        e.innerHTML = `<div class="pg-content">
            <div class="explanation">
                Windows 96 X11/Xpra Client Version 1.0.<br>
                <div class="logo"></div>
                <br>
                This project makes use of Xpra, which can be found at <a href="http://xpra.org/" target="_blank">xpra.org</a>. 
                You can find its license <a href="https://github.com/Xpra-org/xpra-html5/blob/master/LICENSE" target="_blank">here</a>.
                <br>
                <br>
                Minimum tested Xpra version: v4.5
            </div>
        </div>`;
    });
}