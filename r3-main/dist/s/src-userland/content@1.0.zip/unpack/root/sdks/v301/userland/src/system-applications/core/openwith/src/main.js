/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { CheckBox } = w96.ui.components;
const { WindowParams } = w96;
const { getShellAppRegistry } = w96.sys.reg;
const { execCmd } = w96.sys;
const { argParser: ArgParser, escapeHtml } = w96.util;
const { Theme, MsgBoxSimple } = w96.ui;

const hiddenApps = [
    "openwith",
    "about-ui",
    "__exe",
    "wasmrt",
    "devtools",
    "__lnk",
    "__support-us",
    "dd",
    "hterm",
    "dynwp-prefs",
    "mpmenu",
    "wpa",
    "credits",
    "runlnk42",
    "effects",
    "dyk",
    "uploader",
    "jslinux",
    "terminal",
    "settings",
    "wiki96",
    "blocks",
    "win96-chat",
    "gltest",
    "gameing",
    "vm",
    "server-stat",
    "shareboard",
    "notron",
    "youare",
    "pumkin",
    "avabot",
    "winspector",
    "bsod",
    "meme-man",
    "matrix",
    "winmp96",
    "base64",
    "welcome"
];

const ASSOC_CONFIG_PATH = "c:/system/config/assocs.json";

class OpenWithApplication extends WApplication {
    constructor() {
        super();
    }

    async getAssocs(){
        let assocs = {};
        try {
            if(!w96.isRecovery&&await FS.exists(ASSOC_CONFIG_PATH))
                assocs = JSON.parse(await FS.readstr(ASSOC_CONFIG_PATH));
            else if (!w96.isRecovery)
                await FS.writestr(ASSOC_CONFIG_PATH, "{}");
        } catch(err) {
            console.warn('failed to read file associations');
        }
        return assocs;
    }

    async setAssocs(app, ext, assocs){
        console.log('setAssocs', ...arguments);
        assocs[ext] = app;
        await FS.writestr(ASSOC_CONFIG_PATH, JSON.stringify(assocs));
    }

    async main(argv) {
        super.main(argv);
        argv.shift();
        this.args = argv;

        if(argv[0] == null) {
            MsgBoxSimple.error("Error", "You are doing this wrong.", "wat");
            return;
        } else if(!await FS.exists(argv[0])) {
            MsgBoxSimple.error("Error", "Cannot find the file to open!", "OK");
            return;
        }

        let assocs = await this.getAssocs();
        let fileName = FSUtil.fname(argv[0]);
        let fileExt = null;

        if (fileName.includes('.')){
            let a = fileName.split('.');
            fileExt = '.' + a[a.length-1];
        }

        this.fileExt = fileExt;
        this.assocs = assocs;

        if (fileExt&&assocs[fileExt]){
            try{
                await execCmd(assocs[fileExt][0], [...assocs[fileExt][1], ...argv]);
            }catch(e){
                await this.setAssocs(undefined, fileExt, assocs);
                MsgBoxSimple.error("Error", String(e), "OK", (()=>execCmd("openwith", this.args)).bind(this));
            }
            return this.terminate();
        }

        const params = new WindowParams();

        params.initialHeight = 400;
        params.initialWidth = 430;
        params.title = "Open With";
        params.resizable = false;

        const mainwnd = this.createWindow(params, true);

        mainwnd.registerWindow();
        mainwnd.setControlBoxStyle("WS_CBX_CLOSE");

        const body = mainwnd.getBodyContainer();
        body.classList.add('openwith-app');

        body.innerHTML = `<div class="top">
            <div class="icon" style="background: url(${await Theme.getIconUrl('mime/unknown')})"></div>
            <div class="text">
                Choose the program you want to use to open this file:<br>
                <br>
                File: ${escapeHtml(fileName)}
            </div>
        </div>

        <div class="box">
            <div class="appbox"></div>
        </div>

        <div class="bottom">
            <div class="cmd-box">
                <span class="bold-noaa">Custom command</span>
                <input class="w96-textbox custom-cmd">
            </div>
            <div class="remember-checkbox" style="margin-top: 1em"></div>
            <div class="dlg-buttons">
                <button class="w96-button ok">OK</button>
                <button class="w96-button cancel">Cancel</button>
            </div>
        </div>`;

        body.querySelector('.dlg-buttons>.cancel').addEventListener('click', ()=>this.terminate());
        body.querySelector('.dlg-buttons>.ok').addEventListener('click', async ()=>{
            const input = body.querySelector('.custom-cmd');

            if(input.value.trim() != "")
                await this.procCustomCmd(argv);
            else {
                if(this.selectedItem != null) {
                    try {
                        if (this.rememberChoice){
                            await this.setAssocs([this.selectedItem, []], fileExt, assocs);
                        };
                        execCmd(this.selectedItem, argv);
                    } catch(e) { console.error(e); }
                    this.terminate();
                }
            }
        });

        let rememberCb = new CheckBox({
            label: "",
            checked: false,
            onchange: ((e)=>{
                this.rememberChoice = e.checked;
            }).bind(this),
            displayAsBlock: true
        });
        let rememberCbElement = rememberCb.getElement();
        let rememberLabelElem = rememberCbElement.querySelector("span.text");
        if (!fileExt){
            rememberCbElement.querySelector("input[type=checkbox]").disabled = true;
            rememberLabelElem.style.textShadow = "1px 1px white";
            rememberLabelElem.style.color = "gray";
            rememberLabelElem.innerText = "Always use this application for these files.";
        }else rememberLabelElem.innerHTML = "Always use this application for "+
        "<span class=\"bold-noaa\">"+escapeHtml(fileExt)+"</span> files.";
        body.querySelector('.remember-checkbox').appendChild(rememberCbElement);

        body.querySelector('.custom-cmd').addEventListener('keydown', (e)=>{
            if(e.key == "Enter")
                this.procCustomCmd(argv);
        });

        const appbox = body.querySelector(".appbox");

        // Iterate through installed apps
        for(let app of getShellAppRegistry()) {
            if(hiddenApps.includes(app.exec))
                continue;

            const appItem = document.createElement('div');
            appItem.classList.add('item');

            // Create icon
            const icon = document.createElement('div');
            icon.classList.add('icon');
            icon.style.backgroundImage = `url(${await Theme.getIconUrl("mime/executable")})`
            appItem.appendChild(icon);

            // Create text;
            const text = document.createElement('div');
            text.classList.add('text');
            text.innerText = app.exec;
            appItem.appendChild(text);

            appItem.addEventListener('click', ()=>{
                body.querySelectorAll('.appbox>.item').forEach((v)=>v.classList.remove('selected'));
                appItem.classList.add('selected');
                this.selectedItem = app.exec;
            });

            appItem.addEventListener('dblclick', async()=>{
                try {
                    if (this.rememberChoice){
                        await this.setAssocs([this.selectedItem, []], fileExt, assocs);
                    };
                    execCmd(this.selectedItem, argv);
                } catch(e) { console.error(e) }
                this.terminate();
            });

            // Check for some metadata
            if(app.icon && app.name) {
                text.innerText = app.name;

                Theme.getIconUrl(app.icon, '32x32').then((v)=>{
                    icon.style.backgroundImage = `url(${v})`;
                });

                appbox.appendChild(appItem);
            }
        }

        mainwnd.show();
        mainwnd.center();
        this.mainwnd = mainwnd;
    }

    async procCustomCmd(argv) {
        const body = this.mainwnd.getBodyContainer();
        const input = body.querySelector('.custom-cmd');

        const pArgs = ArgParser.parse(input.value);
        this.terminate();
        try {
            if (this.rememberChoice){
                await this.setAssocs([pArgs[0], []], this.fileExt, this.assocs);
            }

            await execCmd(pArgs[0], argv);
        } catch(e) {
            MsgBoxSimple.error("Error", String(e), "OK", (()=>execCmd("openwith", this.args)).bind(this));
        }
    }
}