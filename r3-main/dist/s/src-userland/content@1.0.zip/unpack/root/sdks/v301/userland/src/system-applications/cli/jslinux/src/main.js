/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const term = this.boxedEnv.term;

if(!term)
    return 1;

const { loader: Loader } = w96.sys;
const { Theme } = w96.ui;
const { ProgressBar, Spinner } = w96.util.cli;
const { argParser: ArgParser, requestTerminal } = w96.util;

/**
 * Terminal version of the older JS linux application.
 * All licensed code belongs to the original author.
 */

// Should this get moved to zbuild?
const ON_MAINSITE = (new URLSearchParams(location.search)).get('9lxetc') == "1" || location.hostname.endsWith("windows96.net");
const V86_USER_URL = ON_MAINSITE ? 'https://etc.windows96.net/9LX/' : '//localhost:8000/';
const NET_RELAY_URL = "wss://relay.widgetry.org/"
const LINUX_DIRECTORY = "C:/system/linux";
const ROOTFS_DIRECTORY_R = LINUX_DIRECTORY + "/rootfs";
const ROOTFS_VERSION = 1; // Perhaps get this from another file in the future.
const ROOTFS_DIRECTORY = ROOTFS_DIRECTORY_R + '/' + ROOTFS_VERSION;
const ROOTFS_URL = V86_USER_URL + 'rootfs.tar.gz'
const FT_PATH = ROOTFS_DIRECTORY + '.json';

if (!w96.wmem.linemulators) w96.wmem.linemulators = [];

let emulators = w96.wmem.linemulators;

function parseFile(file){
    let newObject = {
        mode: file.mode,
        mtime: file.mtime,
        type: file.type,
        uid: 0,
        gid: 0, // We are root anyway, no?
        link: null
    }
    if (newObject.type === "2") newObject.link = file.linkname;
    if (newObject.type === "L") return false;
    return newObject;
}

async function saveFT(data){
    return await FS.writestr(FT_PATH, JSON.stringify(data));
}

async function readFT(){
    return JSON.parse(await FS.readstr(FT_PATH));
}

/*
dbgln(`${op.toUpperCase()} ${path} ${op === 'read' ? p1 : ''} ${op === 'read' ? p2 : ''}`);
switch (op) {
    case 'read':
        // temp
        let s1 = await storage.read(path, p1, p2);
        if (s1) return s1;

        const localPath = ROOTFS_DIRECTORY + '/' + path;
        if (await FS.exists(localPath)) {
            let data = await FS.readbin(localPath);
            if (typeof p1 !== 'undefined' && p2 !== 'undefined') return data.subarray(p1, p1 + p2);
            return data;
        } else {
            let localPathDir = localPath.split('/');
            localPathDir.pop(); localPathDir = localPathDir.join('/');
            await FS.mkdir(localPathDir);
            let buf = new Uint8Array(await fetch(baseURL + path).then(s => s.arrayBuffer()));
            await storage.cache(path, buf);
            await FS.writebin(localPath, buf);
            if (typeof p1 !== 'undefined' && p2 !== 'undefined') return buf.subarray(p1, p1 + p2);
            return buf;
        }
        break;
    case 'cache':
        // temp
        return await storage.cache(path, p1);
        break;
    case 'uncache':
        // temp
        return storage.uncache(path)
        break;
}*/

class MappedUNFS{
    constructor(basePath, baseFT, dbgln){
        this.ft = baseFT;
        this.basePath = basePath;
        this.dbg = dbgln;
    }
    async _syncFT(){
        await saveFT(this.ft);
    }
    _getPath(path, slash = true){
        return this.basePath + (slash?'/':'') + path;
    }
    _getDirectory(path){
        let dirn = path.split('/').filter(s=>s);
        dirn.pop(); dirn = dirn.join('/');
        dirn = '/' + dirn + '/';
        if (dirn.startsWith('//')) dirn = dirn.substring(1);
        return dirn;
    }
    _getMode(type, oldMode){
        let mode = oldMode + "";
        // String mode -> st_mode
        if (type === "2"){ // Symlink
            // 0000644
            // 0120644
            mode = mode.replaceAt(1, "12");
        }else if(type === "5"){ // Directory
            mode = mode.replaceAt(2, "4");
        }else if(type === "0"){ // File
            mode = mode.replaceAt(1, "1")
        }else{
            return false; // Not sure what this is
        }
        return parseInt(mode, 8); // It's an octal
    }
    async getSize(path){
        this.dbg('GS ' + path);
        return (await FS.stat(this._getPath(path, false))).length
    }
    async read(path, offset, count){
        this.dbg('READ ' + path);
        return (await FS.readbin(this._getPath(path, false))).subarray(offset, offset + count)
    }
    async write(path, data){
        this.dbg('WRITE ' + path);
        await FS.mkdir(this._getPath(this._getDirectory(path), false));
        return (await FS.writebin(this._getPath(path, false), data));
    }
    uncache(path){
        // ?
        this.dbg('UNCACHE ' + path);
    }
}

class JSLinuxApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        argv.shift();
        let args = argv;

        if (!await FS.exists(ROOTFS_DIRECTORY) || !await FS.exists(FT_PATH)) {
            term.write("Your JSLinux root filesystem is outdated, corrupted or missing. \n" +
                "To continue, you must download a filesystem package (~83MB). \n" +
                "Please note that the extraction process may temporarily freeze your browser.")
            while (true) {
                let res = await term.prompt("Do you want to download it now? (yes/No): ", true);
                if (!res) return;
                res = res.toLowerCase();
                if (res == "n" || res == "no") return;
                if (res == "y" || res == "yes") break;
            }
            await FS.mkdir(LINUX_DIRECTORY + '/dists/');
            const tarPath = LINUX_DIRECTORY + `/dists/_rootfsv${ROOTFS_VERSION}.tar.gz`;
            if (!await FS.exists(tarPath)) {
                let progress = new ProgressBar(40, "Downloading", term);
                let res = await fetch(ROOTFS_URL);
                let reader = await res.body.getReader();
                let length = +res.headers.get('Content-Length');
                let chunks = [];
                let rLength = 0;
                let lengthMiB = (length/1024/1024).toFixed(2);
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    chunks.push(value);
                    rLength += value.length;
                    progress.setProgress(rLength/length*100, `${(rLength/1024/1024).toFixed(2)} MiB / ${lengthMiB} MiB`)
                }
                let fChunks = new Uint8Array(rLength);
                let pos = 0;
                for (let chunk of chunks){
                    fChunks.set(chunk, pos);
                    pos+=chunk.length;
                }
                await FS.writebin(tarPath, fChunks);
                progress.stop(`${lengthMiB} MiB / ${lengthMiB} MiB   `);
            } else {
                term.writeln('Using cached rootfs...');
            }
            let spinner = new Spinner('Extracting... ', term);
            spinner.start();
            await Loader.loadlibAsync("/system/libraries/extern/pako/pako_inflate.min.js");
            await Loader.loadlibAsync("/system/libraries/extern/js-untar/untar.js");
            // Like this for then chaining
            let files = await (new Promise(r=>r(FS.readbin(tarPath))))
                            .then(pako.inflate)
                            .then(a=>a.buffer)
                            .then(untar);
            spinner.stop(true);
            let f2 = {version: 1, ft: {}};
            let progress = new ProgressBar(40, "Extracting ", term);
            await FS.mkdir(ROOTFS_DIRECTORY);
            let filesToWrite = [];
            for (let i in files){
                progress.setProgress(i/files.length*100, `${i} / ${files.length}`);
                let file = files[i];
                let f3 = parseFile(file);
                if (!f3) continue;
                let path = file.name;
                if (path.startsWith('./')) path = path.substring(1);
                if (f3.type === "0"){
                    let localPathDir = path.split('/');
                    localPathDir.pop();
                    localPathDir = localPathDir.join('/');
                    await FS.mkdir(ROOTFS_DIRECTORY + localPathDir);
                    filesToWrite.push([ROOTFS_DIRECTORY + path, new Uint8Array(file.buffer)]);
                }
                if (f3.type === "5") await FS.mkdir(ROOTFS_DIRECTORY + path);
                f2.ft[path] = [f3.type, f3.mode, f3.mtime, f3.uid, f3.gid, f3.link||undefined];
                if (i%50===0) await new Promise(s=>setTimeout(s, 1));
            }
            progress.setProgress(100, `${files.length} / ${files.length}`);
            term.write('\n');
            files = null;
            progress.action = 'Writing    ';
            for (let i in filesToWrite){
                progress.setProgress(i/filesToWrite.length*100, `${i} / ${filesToWrite.length}`);
                let file = filesToWrite[i];
                if (await FS.exists(file[0]) && (await FS.stat(file[0])).length == file[1].length) continue; // Hash compare in the future might be useful
                await FS.writebin(file[0], file[1]);
                file[1] = null;
                //await new Promise(s=>setTimeout(s, 1));
            }
            progress.stop(`${filesToWrite.length} / ${filesToWrite.length}`);
            filesToWrite = null;
            let i2 = 0;
            for (let i of Object.keys(f2.ft)){
                f2.ft[i].push(i2); // Inode number
                i2 += 1;
            }
            f2.ic = i2;
            await saveFT(f2);
        }

        await Loader.loadlibAsync(V86_USER_URL + 'build/libv86.js');
        let completer = null;
        let emu = emulators[emulators.findIndex(s => s.count < 3)]; // ah, JS
        if (emu) {
            let emulator = emu.emulator;
            let count = Number(emu.count);
            let dbgln = emu.dbgln;
            dbgln('Attached ttyS' + count);
            emulator.add_listener(`serial${count}-output-char`, (char) => {
                term.write(char);
            });
            term.onData((c) => {
                emulator[`serial${count}_send`](c);
            });
            emulator[`serial${count}_send`]('\r');
            term.wnd.setTitle("ttyS" + count);
            emu.count += 1;
        } else {
            if (emulators[0] && !args.includes('--force')) {
                return term.writeln('over 4 instances are not supported. If you want this anyway, pass --force.')
            }
            let dbgln = () => { };
            let dbgl = () => { };
            if (args.includes("--debug")) {
                let res = await requestTerminal("jslinux-debug", await Theme.getIconUrl("apps/linux", "16x16"));
                let tem = res.terminal;
                dbgln = (...a) => tem.writeln(...a);
                dbgl = (...a) => tem.write(...a);
            }
            dbgln('Starting emulation...');
            await FS.mkdir(ROOTFS_DIRECTORY);
            let emulator = new V86Starter({
                wasm_path: V86_USER_URL + "build/v86.wasm",
                memory_size: 512 * 1024 * 1024,
                filesystem: {
                    class: new MappedUNFS(ROOTFS_DIRECTORY, await readFT(), dbgln)
                },
                cmdline: [
                    "rw loglevel=50 apm=off",
                    "root=host9p rootfstype=9p rootflags=trans=virtio,cache=loose",
                    "mitigations=off audit=0 edd=off",
                    "page_poison=on console=ttyS0",
                    "tsc=reliable nosmp maxcpus=0",
                    "random.trust_cpu=on",
                    "nowatchdog",
                    "net.ifnames=0 biosdevname=0 kernel.nmi_watchdog=0",
                ].join(" "),
                bzimage_initrd_from_filesystem: true,
                autostart: true,
                bios: {
                    url: V86_USER_URL + "bios/seabios.bin",
                },
                network_relay_url: NET_RELAY_URL,
                uart1: true,
                uart2: true,
                // uart3: true // uart3 doesn't work :(
            });
            emulator.add_listener("serial0-output-char", (char) => {
                term.write(char);
            });
            term.onData((c) => {
                emulator.serial0_send(c);
            });
            term.wnd.setTitle("ttyS0");
            emulators.push({ emulator, count: 1, dbgl, dbgln });
        }
        await new Promise(r => this.completer = r);
    }

    ontermination(){
        // clean up!

    }
}