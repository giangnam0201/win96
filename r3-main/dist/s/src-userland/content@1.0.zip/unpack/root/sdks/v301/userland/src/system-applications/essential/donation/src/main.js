/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme } = w96.ui;
const { TabControl } = w96.ui.components;
const { WindowParams } = w96;

const cryptoInfo = {
    btc: {
        title: "Bitcoin",
        address: "bc1qscpuz64p38lt30yngpdq3x9felrsgr6kuyh350",
        qr: "/system/resource/app/support/crypto-qr/btc.png"
    },
    eth: {
        title: "Ethereum",
        address: "0x3304D1f06E078DD7da99B2df7c2FE6044b071f42",
        qr: "/system/resource/app/support/crypto-qr/eth.png"
    },
    ltc: {
        title: "Litecoin",
        address: "ltc1qz0ymkdrvmp7quapptmungxa0hwfnxr9zq578cg",
        qr: "/system/resource/app/support/crypto-qr/ltc.png"
    },
    doge: {
        title: "Dogecoin",
        address: "DPbAeBA3uLyKqmWeRitgcukFFryUvcNbbq",
        qr: "/system/resource/app/support/crypto-qr/doge.png"
    }
}

class DonationUIApplication extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        const params = new WindowParams();
        params.resizable = false;
        params.title = "Support Us";
        params.initialWidth = 375;
        params.initialHeight = 350;
        params.mobResize = true;

        const mainwnd = this.createWindow(params, true);
        mainwnd.registerWindow();
        mainwnd.setWindowIcon(await Theme.getIconUrl("misc/coin", '16x16'));
        mainwnd.setControlBoxStyle('WS_CBX_CLOSE');
        mainwnd.setHtml(`
            
        `);

        const tc = new TabControl();

        const main = tc.addPage('Donate', (e)=>{
            e.innerHTML = `<div class="container">
                <div class="w96-panel p1">
                Windows 96 is a project developed by independent programmers.<br><br>
                If you like what we make, please consider donating to help us keep this thing alive.
                <br><br>
                All donations will go straight to the funding of costs (server costs, etc.) and the lives of the developers.<br><br>
                Many thanks!
                </div>
                <div class="e"></div>
            </div>`;

            const methods = new TabControl();

            methods.openPage(methods.addPage('Crypto (BTC, etc.)', (e2)=>{
                e2.innerHTML = `<div class="currency btc">
    <button class="w96-button"></button>
    <div class="title">Bitcoin</div>
</div>
<div class="currency eth">
    <button class="w96-button"></button>
    <div class="title">Ethereum</div>
</div>
<div class="currency ltc">
    <button class="w96-button"></button>
    <div class="title">Litecoin</div>
</div>
<div class="currency doge">
    <button class="w96-button"></button>
    <div class="title">Dogecoin</div>
</div>`;
                e2.querySelector(".currency.btc").onclick = ()=>this.showCryptoInfo('btc');
                e2.querySelector(".currency.eth").onclick = ()=>this.showCryptoInfo('eth');
                e2.querySelector(".currency.ltc").onclick = ()=>this.showCryptoInfo('ltc');
                e2.querySelector(".currency.doge").onclick = ()=>this.showCryptoInfo('doge');
                e2.classList.add('cryptos');
            }));

            methods.addPage('Patreon', (e2)=>{
                e2.innerHTML = '<span class="bold-noaa">Patreon: </span><a href="https://www.patreon.com/win96" target="_blank">https://www.patreon.com/win96</a>';
            });

            const mEl = methods.getElement();
            mEl.classList.add('p2');

            e.querySelector('.e').replaceWith(mEl);
        });

        tc.addPage('Supporters', (e)=>{
            e.innerHTML = `<iframe src="https://etc.windows96.net/supporters/supporters.html" target="_blank"></iframe>`;

            /** @type {HTMLIFrameElement} */
            const ifr = e.querySelector('iframe');
            ifr.onload = ()=>{
                // ifr.contentDocument.body.onclick = ()=>mainwnd.activate();
            }
        });

        const wcontainer = mainwnd.getBodyContainer();
        wcontainer.classList.add('support-us-ui');
        wcontainer.appendChild(tc.getElement());

        // Start the app
        mainwnd.show();
        mainwnd.center();
        tc.openPage(main);
    }

    showCryptoInfo(currency) {
        const cInfo = cryptoInfo[currency];

        if(cInfo == null)
            return;

        const params = new WindowParams();
        params.title = "Send " + cInfo.title;
        params.resizable = false;
        params.initialHeight = 390;
        params.initialWidth = 290;

        const infoWindow = this.createWindow(params, false);
        infoWindow.registerWindow();
        infoWindow.setControlBoxStyle('WS_CBX_CLOSE');

        const bc = infoWindow.getBodyContainer();
        bc.classList.add('crypto-info-dlg');
        bc.innerHTML = `<div class="qr" style="background-image: url(${cInfo.qr})"></div><div class="address">${cInfo.address}</div>`;
        
        infoWindow.show();
        infoWindow.center();
    }
}