Windows 96 Quick Launch shell extension.

Copyright (C) windows96.net 2021.