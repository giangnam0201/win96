/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { Theme, DialogCreator } = w96.ui;
const { CheckBox, GroupBox, TabControl } = w96.ui.components;
const { WindowSystem, sysConf: SCM } = w96;

/**
 * Window Manager Settings Manager
 * 
 * A tool to tweak Window Manager settings to your liking.
 */
class WMSMApp extends WApplication {
    constructor() {
        super();
        this.wmConfig = WindowSystem.getConfig();
    }

    /**
     * Synchronizes WM config with SCM.
     */
    async syncConfig() {
        await SCM.setAndSync("System/WndMan", this.wmConfig);
    }

    /**
     * WMSM Entry point.
     * @param {String[]} argv Arguments.
     */
    async main(argv) {
        super.main(argv);

        // Copy the configuration
        this.wmConfig = { ... WindowSystem.getConfig() };

        const mainwnd = this.createWindow({
            title: "96WM Settings Manager",
            initialWidth: 370,
            initialHeight: 443,
            resizable: false,
            controlBoxStyle: "WS_CBX_CLOSE",
            bodyClass: "wmsm-app",
            icon: await Theme.getIconUrl("apps/wm", '16x16'),
            body: `<div class="tabc"></div>
            <div class="buttons">
                <button class="w96-button apply" disabled>Apply</button>
                <button class="w96-button cancel">Cancel</button>
                <button class="w96-button ok">OK</button>
            </div>`,
            center: true,
            taskbar: true,
            mobResize: true
        }, true);

        const body = mainwnd.getBodyContainer();
        body.classList.add('applet-base');

        const tabControl = new TabControl();

        tabControl.openPage(tabControl.addPage("Basic", async (e)=>{
            e.style.padding = "10px";
            e.style.boxSizing = "border-box";
            e.innerHTML = `
                <div class="icon-box">
                    <div class="icon" style="background-image: url(${await Theme.getIconUrl("apps/wm")});"></div>
                    <div class="text">
                        Windows 96 includes a reasonable Window Manager (WM) which can be customized with this utility.<br><br>
                        <span class="bold-noaa">Important! </span>Themes can override some of these settings!
                    </div>
                </div>
                <div class="grpbx1"></div>
                <div class="grpbx2"></div>
            `;

            const grpbx1 = new GroupBox({
                title: "Window Dragging",
                body: ``
            });
            const grpbx2 = new GroupBox({
                title: "Appearence",
                body: ``
            });

            const gE1 = grpbx1.getElement().querySelector('.content');
            const gE2 = grpbx2.getElement().querySelector('.content');

            gE1.appendChild(new CheckBox({
                label: "Hide window contents on drag",
                checked: this.wmConfig.dragging.hideWindow,
                onchange: (e)=>this.wmConfig.dragging.hideWindow = e.checked,
                displayAsBlock: true
            }).getElement());

            gE1.appendChild(new CheckBox({
                label: "Allow window snapping on edge drag",
                checked: this.wmConfig.features.windowSnap,
                onchange: (e)=>this.wmConfig.features.windowSnap = e.checked,
                displayAsBlock: true
            }).getElement());

            gE2.appendChild(new CheckBox({
                label: "Enable ClearFix for sharper pixel fonts on the titlebar (experimental)",
                checked: this.wmConfig.features.enableClearFix,
                onchange: async (e)=>{
                    this.wmConfig.features.enableClearFix = e.checked;
                    // reload the desktop
                    // await Theme.reloadDesktop();
                    for (var wind in w96.WindowSystem.windows){
                        wind = w96.WindowSystem.windows[wind];
                        if (!wind) continue;

                        wind.setWindowIcon(wind.windowIcon);
                        wind.setTitle(wind.title);
                    }
                },
                displayAsBlock: true
            }).getElement());

            gE2.appendChild(new CheckBox({
                label: "Use 12 hour time instead of 24 hour time in the clock",
                checked: this.wmConfig.features.use12hTime,
                onchange: async (e)=>{
                    this.wmConfig.features.use12hTime = e.checked;
                    w96.wmem.clockUpdate();
                },
                displayAsBlock: true
            }).getElement());
            

            e.querySelector(".grpbx1").replaceWith(grpbx1.getElement());
            e.querySelector(".grpbx2").replaceWith(grpbx2.getElement());
        }));

        tabControl.addPage("Performance", async(e)=>{
            e.style.padding = "10px";
            e.style.boxSizing = "border-box";
            e.innerHTML = `
                <div class="icon-box">
                    <div class="icon" style="background-image: url(${await Theme.getIconUrl("devices/card")});"></div>
                    <div class="text">
                        You can modify the Window Manager to match your system performance below.
                    </div>
                </div>
                <div class="grpbx1"></div>
            `;

            const grpbx1 = new GroupBox({
                title: "Graphical Tweaks",
                body: ``
            });

            const gE1 = grpbx1.getElement().querySelector('.content');

            gE1.appendChild(new CheckBox({
                label: "Disable animations",
                checked: this.wmConfig.features.disableAllAnimations,
                onchange: (e)=>this.wmConfig.features.disableAllAnimations = e.checked,
                displayAsBlock: true
            }).getElement());

            gE1.appendChild(new CheckBox({
                label: "Use simple window dragging outline",
                checked: this.wmConfig.dragging.simpleDragBox,
                onchange: (e)=>this.wmConfig.dragging.simpleDragBox = e.checked,
                displayAsBlock: true
            }).getElement());

            e.querySelector(".grpbx1").replaceWith(grpbx1.getElement());
        });

        body.querySelector(".tabc").replaceWith(tabControl.getElement());
        body.querySelector("button.cancel").addEventListener('click', ()=>mainwnd.close());
        body.querySelector("button.ok").addEventListener('click', ()=>{
            this.applySettings();
            mainwnd.close();
        });

        mainwnd.show();

        if(!SCM.get("Software/WMSM/Started")) {
            DialogCreator.create({
                title: "WMSM",
                icon: "info",
                body: `This tool allows you to configure the window manager to your liking.<br><br>Please note that you can revert to the default settings by removing c:/system/config/wm.json`
            });

            await SCM.setAndSync("Software/WMSM/Started", true);
        }
    }

    /**
     * Applies the current WM settings.
     */
    async applySettings() {
        await this.syncConfig();
        WindowSystem.setConfig(this.wmConfig);
    }
}