// Ran upon package uninstallation
window.onbeforeunload = null;