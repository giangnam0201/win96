/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { WindowParams, mutex, sysConf: SCM } = w96;
const { Theme, DialogCreator } = w96.ui;
const { TabControl, GroupBox, ListBox, CheckBox } = w96.ui.components;
const { loadlibAsync } = w96.sys.loader;

// Startup flags
const XPRA_STARTUP_FLAGS = {
    /** Client to connect to on startup. */
    startupClient: {
        address: null,
        port: null
    }
}

$$Include("./settings.js")
$$Include("./start-menu.js")
$$Include("./cli.js")
$$Include("./tabs/about.js")
$$Include("./tabs/clients.js")
$$Include("./tabs/control.js")
$$Include("./tabs/settings.js")

// Location of xpra files
const X11_PREFIX = '/system/libraries/extern/xpra/';

// Libraries we must load
const X11_LIBS = [
    'lib/brotli_decode',
    'lib/detect-zoom',
    'lib/jquery.ba-throttle-debounce',
    'lib/lz4',
    'Utilities',
    'Keycodes',
    'Protocol',
    'Window',
    'Constants',
    'MediaSourceUtil',
    'OffscreenDecodeWorkerHelper',
    'Client'
];

/**
 * Xpra Client main class.
 */
class X11Application extends WApplication {
    constructor() {
        super();
        this.mutex = null;
        this.eq = null;
        this.activeClients = [];
    }

    /**
     * Load all XPRA libraries into the current window.
     */
    async loadLibs() {
        if(typeof XpraClient !== 'undefined')
            return; // We do not need to load libraries

        // Show some progress
        const progressDlg = DialogCreator.progress("Loading libraries...");
        progressDlg.setProgress(0);

        let loadedLibs = 0;

        for (let lib of X11_LIBS) {
            await loadlibAsync(X11_PREFIX + lib + '.js');
            loadedLibs++;
            progressDlg.setProgress((loadedLibs / X11_LIBS.length) * 100);
        }

        progressDlg.close();
    }

    /**
     * Creates a new Xpra session.
     * @param {string} host The host to connect to.
     * @param {number} port The port to use.
     * @returns The Xpra client.
     */
    createXpraSession(host, port) {
        const client = new XpraClient("maingfx");
        client.host = host;
        client.port = `${port}`;
        client.init();

        const address = `${host}:${port}`;

        // Check for existing mutex
        if(mutex.find(`xpra::${address}`) != null)
            throw new Error("Connection is already active!"); // Complain that connection exists.

        const session = {
            client,
            mtx: mutex.create(`xpra::${address}`),
            address,
            time: Date.now()
        };

        this.activeClients.push(session);
        client.on_xdg_menu = ()=>updateXdgStartMenu(this);
        client.on_connect = ()=> {
            alert("Connection successful!", { icon: "info", title: "X11/Xpra Client" });
        }

        client.connect();

        return;
    }

    /**
     * Disconnects a client.
     * @param {*} client The client to disconnect.
     */
    disconnect(client) {
        mutex.release(client.mtx);
        client.client.reconnect = false;
        client.client.close();
        this.activeClients.splice(this.activeClients.indexOf(client), 1);
        updateXdgStartMenu(this);
    }

    /**
     * Disconnects all clients.
     */
    disconnectAll() {
        for(let c of this.activeClients) {
            try {
                this.disconnect(c);
            } catch(e) {
                console.error("Could not properly close client " + c.address);
                console.error(e);
            }
        }

        this.activeClients = [];
        updateXdgStartMenu(this);
    }

    /**
     * Validates the address and provides UI feedback with it.
     * @param {string} address Address to check.
     * @param {number} port Port to check.
     */
    uiValidateAddress(address, port) {
        // Check if port is real
        if ((Number.isNaN(port)) || (port < 0) || (port > 65535)) {
            alert("Cannot connect to host: invalid port.", { title: "X11/Xpra Client" });
            return false;
        }

        // Check if address is valid
        if((address == "")) {
            alert("Cannot connect to host: invalid address.", { title: "X11/Xpra Client" });
            return false;
        }

        // Check if a mutex for this address exists.
        if(mutex.find(`xpra::${address}:${port}`) != null) {
            alert("Cannot connect to host: a connection already exists for this address.", { title: "X11/Xpra Client" });
            return false;
        }

        return true;
    }

    /**
     * Shows the client window.
     */
    async showClientWindow() {
        const wnd = this.createWindow({
            title: "X11/Xpra Client",
            initialHeight: 415,
            initialWidth: 400,
            controlBoxStyle: "WS_CBX_MINCLOSE",
            resizable: false,
            center: true,
            icon: await Theme.getIconUrl("apps/x11", '16x16'),
            body: `
            <div class="banner"></div>
            <div class="tabc"></div>`,
            bodyClass: "app-x11",
            taskbar: true
        }, true);

        const body = wnd.getBodyContainer();

        // Create tab box
        const tabc = new TabControl();

        // Create the tabs
        createControlTab(tabc, this);
        createClientsTab(tabc, this);
        createSettingsTab(tabc, this);
        createAboutTab(tabc, this);

        // Place item
        body.querySelector(".tabc").replaceWith(tabc.getElement());

        wnd.show();
    }

    /**
     * Sets up inter-process communication.
     */
    async setupIPC() {
        this.eq.on("connect", (address, port) => {
            if((typeof address !== 'string') && (typeof port !== 'number')) {
                alert("IPC request failed: invalid argument.", { title: "X11/Xpra Client" });
                return;
            }

            // Validate address
            if(!this.uiValidateAddress(address, port))
                return;

            // Create the session
            this.createXpraSession(address, port);
        });
    }

    /**
     * Program entry point.
     * @param {string[]} argv Program arguments.
     */
    async main(argv) {
        super.main(argv);

        // Process CLI arguments
        if((await processCLICommands(argv, this)) == CLI_PROC_RESULT.EXIT)
            return void this.terminate();

        // Check for existing mutex
        if(mutex.find("xpra::app") != null) {
            alert("Only one Xpra client GUI may be running at once!", { title: "X11/Xpra Client" });
            this.terminate();
            return;
        } else {
            this.eq = this.registerIpcEQ("xpra")
            this.mutex = mutex.create("xpra::app");
        }

        // Load client settings
        await loadSettings();

        // Load libraries
        await this.loadLibs();

        // Setup IPC
        await this.setupIPC();

        // Create client window
        await this.showClientWindow();

        // Check for startup client
        if(XPRA_STARTUP_FLAGS.startupClient.address != null)
            if(this.uiValidateAddress(XPRA_STARTUP_FLAGS.startupClient.address, XPRA_STARTUP_FLAGS.startupClient.port))
                this.createXpraSession(XPRA_STARTUP_FLAGS.startupClient.address, XPRA_STARTUP_FLAGS.startupClient.port)
    }

    /**
     * On close handler.
     */
    async ontermination() {
        console.log("Shutting down...");
        await super.ontermination();
        
        // Cleanup tasks
        this.disconnectAll();

        // We must be the primary active client to restore the original main menu.
        // This can cause a lot of problems otherwise.
        if(this.mutex) {
            restoreOriginalMenu();
            mutex.release(this.mutex);
        }

        // Synchronize settings to SCM if needed
        if(CL_SETTINGS_MODIFIED)
            syncSettings();

        // Free
        this.eq = null;
        this.activeClients = null;
        console.log("Goodbye.");
    }
}