/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/*
 * Volume lister.
 *
 * Copyright (C) windows96.net 2023.
 */

if(!env.term)
    return 1;

const term = env.term;

const volumes = w96.FS.list();

for(let vol of volumes) {
    const volObj = w96.FS.get(vol);
    term.println(term.color`{cyan ${volObj.prefix}} (${volObj.volumeLabel})=[{magenta ${volObj.features}}] -> {yellow ${volObj.driverName}}`);
}