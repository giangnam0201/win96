/*
Windows 96 Userland Source Code.
Copyright (C) 2023 Windows96.net

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

const { fixPath } = w96.FSUtil;
const { getMimetypeFromPath } = w96.util;

// Terminal reference
let term = this.boxedEnv.term;

class IFSCKApplication extends WApplication {
    constructor() {
        super();
    }

    /**
     * Main entry point.
     * @param {String[]} argv The arguments to pass.
     */
    async main(argv) {
        await super.main(argv);

        if(!term)
            return;

        term.writeln('\u001b[36mIndexed File System Checker');
        term.writeln('Copyright (C) SYS36.NET 2023.');
        term.writeln('\u001b[0m');

        argv.shift();

        // Check if a valid drive is specified
        if(argv[0] == null) {
            term.writeln('\u001b[31mError: No drive specified to check.\u001b[0m');
            return 1;
        }

        // Parse prefix
        let prefix = argv[0];

        if(prefix.length > 2)
            prefix = prefix.substring(0, 2);

        // Read file system object

        const fso = FS.get(prefix);

        if(!fso) {
            term.writeln('\u001b[31mError: The specified drive cannot be found.\u001b[0m');
            return 1;
        }

        // We must only operate on idbfs based file systems.
        if(fso.driverName !== 'idbfs') {
            term.writeln('\u001b[31mError: The target drive is not utilizing the IndexedDB FileSystem driver.\u001b[0m');
            return 1;
        }

        await this.checkFilesystem(fso);
    }

    /**
     * Checks the file system.
     * @param {import('../../../../../../source/src/sys/fs/filesystems/fs-indexed').IndexedFileSystem} fso The IDB file system object.
     */
    async checkFilesystem(fso) {
        term.println(`A drive scan & repair will be initiated for "${fso.prefix}". Please do NOT quit your session, or you may lose your data!\n`);

        // Check all records in ftable
        let ftblRecords = Object.keys(fso._fileTable);
        let rcc = 0; // Record counter
        let rcf = 0; // Fixed record counter

        // Step 1. Fix broken record paths
        term.println("\u001b[34mStage #1: Find and repair broken path keys\u001b[0m");

        for(let k of ftblRecords) {
            // Fix trailing paths
            // Do check to only commit to broken paths
            if((k.length > 1) && (k.includes("//") || k.endsWith("/"))) {
                const fixedPath = fixPath(k);
                term.println(`Fixing key ${rcc} [${k}] -> ${fixedPath}...`);

                const fEntry = {...fso._fileTable[k]};
                delete fso._fileTable[k];
                fso._fileTable[fixedPath] = fEntry;
                rcf++;
            }

            rcc++;
        }

        // Sync changes
        if(rcf > 0) {
            term.println(`Committing channges to FS...`);
            await fso._sync();
            term.print('\n');
        }
        else
            term.println(`No broken path keys to fix.\n`);

        // Step 2. Check file records and check if the IndexedDB item type is of Uint8array
        // If so, convert to blob.
        let brc = 0; // Broken record counter
        term.println("\u001b[34mStage #2: Checking FS record data...\u001b[0m");

        // Reassign file table items with fixed versions
        // _sync removes empty keys
        ftblRecords = Object.keys(fso._fileTable);

        for(let k of ftblRecords) {
            try {
                // Check if item is a file
                const ftrc = fso._fileTable[k];

                if(ftrc.type == 1)
                    continue; // Ignore dirs

                let data = await fso._getItem(ftrc.recordId);

                // Data type error - we must fix!
                // This does not apply for zero length items, since there is no possible way for there to be data in IDB.
                if((!(data instanceof Blob)) && (ftrc.length != 0)) {
                    brc++;

                    // If data is not uint8array (old fs ver style record data), the item is probably corrupted and not recoverable.
                    // But we should delete the broken record to avoid further FS complications
                    if(!(data instanceof Uint8Array)) {
                        term.println(`\u001b[31mrecord ${ftrc.recordId} (belonging to ${k}) is corrupted ... deleting.\u001b[0m`);
                        await localStorageDB.removeItem(ftrc.recordId);
                        delete fso._fileTable[k];
                        continue;
                    } else {
                        // Fix old record data
                        term.println(`\u001b[33mrecord ${ftrc.recordId} (belonging to ${k}) has wrong data type, fixing...\u001b[0m`);

                        try {
                            /** @type {Uint8Array} */
                            let data = await fso._getItem(ftrc.recordId);
                            await fso._setItem(ftrc.recordId, new Blob([data], { type: getMimetypeFromPath(fso.prefix + k) }));
                            data = null;
                            term.println(`\u001b[32mrecord ${ftrc.recordId} (belonging to ${k}) has been fixed!\u001b[0m`);
                        } catch(e) {
                            term.println(`\u001b[31mrecord ${ftrc.recordId} (belonging to ${k}) has NOT been fixed: ${e}\u001b[0m`);
                        }
                    }
                }
            } catch(e) {
                term.println(`\u001b[31mcannot fix ${ftrc.recordId} (belonging to ${k}): ${e}\u001b[0m`);
            }
        }

        // Commit file table changes
        if(brc > 0) {
            term.println(`Committing channges to FS...`);
            await fso._sync();
            term.print('\n');
        }
        else
            term.println("All record data is OK.\n");

        term.println("All done!");
    }
}